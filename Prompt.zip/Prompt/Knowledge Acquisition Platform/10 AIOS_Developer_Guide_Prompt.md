# AIOS Engineering Specification

# Prompt: Create `AIOS_Developer_Guide.md`

> **Document Type:** Developer Guide & Contribution Handbook

------------------------------------------------------------------------

# Objective

Create a permanent document named:

``` text
AIOS_Developer_Guide.md
```

This guide is the official onboarding and development handbook for AIOS
contributors.

It complements:

-   AIOS_Architecture_Guide.md
-   AIOS_Architecture_Governance.md
-   AIOS_Data_Model_Guide.md
-   AIOS_API_Reference.md

It explains **how to build, extend, test, document, and release AIOS**.

------------------------------------------------------------------------

# Mandatory Rules

-   Documentation only.
-   No implementation.
-   Cross-reference the Architecture, Data Model, API, and Governance
    guides.
-   Distinguish current implementation from future guidance.
-   Include diagrams, checklists, and examples.

------------------------------------------------------------------------

# Required Sections

1.  Executive Summary
2.  Project Structure
3.  Local Development Environment
4.  Repository Layout
5.  Coding Standards
6.  Branching & Git Workflow
7.  Creating a New Pipeline Stage
8.  Creating a New Plugin
9.  Creating a New Connector
10. Using the Runtime SDK
11. Defining Data Contracts
12. Exposing New APIs
13. Updating Configuration
14. Testing Standards
15. Regression Test Strategy
16. Documentation Standards
17. Architecture Compliance Checklist
18. Security Best Practices
19. Performance Guidelines
20. Logging & Observability
21. Pull Request Checklist
22. Release Process
23. Troubleshooting Guide
24. Frequently Asked Questions
25. Glossary

For each development workflow include:

-   Purpose
-   Step-by-step instructions
-   Example folder layout
-   Common mistakes
-   Best practices
-   Validation checklist

------------------------------------------------------------------------

# Documentation Portal

Add a dedicated section named:

## Documentation Portal

Design the documentation to be published as a static documentation
website.

Recommend a structure such as:

``` text
https://docs.aios.local/

Home
Architecture
Governance
Developer Guide
Data Model
API Reference
Specifications
Walkthroughs
ADR
Release Notes
```

Document requirements:

-   Every guide has a permanent URL.
-   Every document cross-links to related guides.
-   Breadcrumb navigation.
-   Search support.
-   Version selector (future).
-   Last updated timestamp.
-   "Edit this page" link (future).

Recommend generating the site using one of:

-   MkDocs Material
-   Docusaurus
-   GitHub Pages
-   Read the Docs

Include a navigation tree and URL mapping similar to:

``` text
/
/architecture/
/governance/
/developer-guide/
/data-model/
/api-reference/
/specifications/
/walkthroughs/
/adr/
```

Also recommend adding:

-   sitemap.xml
-   robots.txt
-   search index
-   PDF export (future)

------------------------------------------------------------------------

# Deliverables

The output must only be:

``` text
AIOS_Developer_Guide.md
```

The guide should become the official contributor handbook and define how
engineers extend AIOS while remaining compliant with the platform
architecture.
