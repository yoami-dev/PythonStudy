# AIOS Engineering Specification

# Phase 2 -- Resource Validation & Classification Engine

> **Target Output:** Implement the Resource Validation & Classification
> Engine and produce a complete implementation walkthrough.

------------------------------------------------------------------------

# Objective

Implement **Phase 2 -- Resource Validation & Classification Engine** in
full compliance with:

-   AIOS_Architecture_Guide.md
-   AIOS_Architecture_Governance.md
-   AIOS_Data_Model_Guide.md
-   AIOS_API_Reference.md
-   AIOS_Developer_Guide.md

This phase must become the first generic validation stage of the
Knowledge Acquisition pipeline.

This stage **does NOT clean, parse, chunk, embed, or perform LLM
inference.**

Its sole responsibility is to validate and classify acquired resources
and produce a canonical `ResourceDescriptor`.

------------------------------------------------------------------------

# Pre-Implementation Requirements

Before implementing:

1.  Review all architecture documents.
2.  Verify compliance with Section 23 Architecture Governance.
3.  Reuse existing runtime, SDK, connectors, event bus, validation
    engine, artifact manager and audit manager.
4.  Do not duplicate existing functionality.

If architecture changes are required:

-   Update AIOS_Architecture_Guide.md
-   Include an Architecture Change Summary in the walkthrough.

------------------------------------------------------------------------

# Scope

## Input

Accept artifacts produced by Phase 1 Website Fetcher.

Supported initial resource types:

-   HTML
-   PDF
-   DOCX
-   TXT
-   Markdown

Future-ready placeholders only (no implementation):

-   PPTX
-   XLSX
-   Images
-   Audio
-   Video

------------------------------------------------------------------------

## Responsibilities

The stage shall:

-   Validate resource existence
-   Validate MIME type
-   Validate file size
-   Validate checksum
-   Detect duplicate resources
-   Detect content encoding
-   Detect language (if available)
-   Detect content category
-   Classify resource type
-   Generate metadata
-   Produce canonical ResourceDescriptor
-   Store validation artifacts
-   Emit runtime events
-   Record audit entries
-   Publish runtime metrics

The stage shall NOT:

-   Parse HTML
-   Clean text
-   Extract semantic content
-   Chunk documents
-   Generate embeddings
-   Invoke LLMs

------------------------------------------------------------------------

# Runtime Integration

Implement as:

-   ResourceValidationPlugin
-   subclass of PipelinePlugin

Use:

-   PipelineRuntimeSDK
-   ValidationEngine
-   ArtifactManager
-   AuditManager
-   RecoveryManager
-   RuntimeMetrics
-   PipelineEventBus

No direct file writes.

No direct HTTP.

No singleton bypass.

------------------------------------------------------------------------

# Data Contracts

Reuse canonical contracts.

Produce:

-   ResourceDescriptor
-   ValidationResult
-   ClassificationResult

Do not redefine existing contracts.

------------------------------------------------------------------------

# Artifacts

Persist:

-   validation_report.json
-   resource_descriptor.json
-   classification_report.json

All artifacts shall be SHA-256 content addressed.

------------------------------------------------------------------------

# Events

Emit:

-   validation.started
-   validation.completed
-   validation.failed
-   classification.completed

------------------------------------------------------------------------

# APIs

Expose:

POST /api/v1/knowledge-acquisition/runtime/validate-resource

The endpoint must delegate to:

POST /runtime/execute

No business logic in controllers.

Update API reference only if new stable endpoint is introduced.

------------------------------------------------------------------------

# Metrics

Capture:

-   validation duration
-   success/failure count
-   duplicate detection
-   resource types
-   language distribution
-   validation errors

------------------------------------------------------------------------

# Testing

Create:

-   Unit tests
-   Runtime integration tests
-   API tests
-   Failure tests
-   Duplicate detection tests
-   Validation rule tests

All previous regression tests must continue to pass.

------------------------------------------------------------------------

# Documentation Updates

If necessary update:

-   AIOS_Architecture_Guide.md
-   AIOS_Data_Model_Guide.md
-   AIOS_API_Reference.md

Only if implementation requires it.

------------------------------------------------------------------------

# Deliverables

Implementation

-   Runtime plugin
-   APIs
-   Tests
-   Metrics
-   Validation artifacts
-   Documentation updates

Documentation

Produce a Walkthrough.md containing:

1.  Executive Summary
2.  Architecture Compliance
3.  Architecture Change Summary
4.  Runtime Interaction Diagram
5.  Files Created
6.  Files Modified
7.  API Summary
8.  Regression Tests
9.  Manual Validation Checklist
10. Known Limitations
11. Explicit Scope Confirmation

------------------------------------------------------------------------

# Acceptance Criteria

The implementation is accepted only if:

-   100% compliant with architecture
-   No architectural drift
-   Uses canonical data contracts
-   Uses PipelineRuntimeSDK
-   Uses generic runtime execution
-   Produces ResourceDescriptor
-   Produces validation artifacts
-   Emits runtime events
-   Publishes runtime metrics
-   Regression tests pass
-   Walkthrough demonstrates compliance
-   No parsing, cleaning, chunking, embedding or LLM processing is
    implemented in this phase.
