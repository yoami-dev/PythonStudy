# AIOS Engineering Specification

# Prompt: Create `AIOS_Data_Model_Guide.md`

> **Document Type:** Canonical Data Model Reference

## Objective

Create a permanent document named `AIOS_Data_Model_Guide.md` that
defines every canonical object exchanged throughout the AIOS platform.
This is the authoritative reference for data contracts and must align
with `AIOS_Architecture_Guide.md`.

## Mandatory Rules

-   Do not implement code.
-   Do not invent unsupported runtime features.
-   Clearly distinguish **Implemented**, **Planned**, and **Future**
    models.
-   Every model must include:
    -   Purpose
    -   Owner
    -   Producer
    -   Consumer(s)
    -   Lifecycle
    -   Versioning
    -   Validation rules
    -   Example JSON
    -   JSON Schema (conceptual)
    -   Backward compatibility notes

## Required Sections

1.  Executive Summary
2.  Data Modeling Principles
3.  Naming & Versioning Strategy
4.  Runtime Models
    -   PipelineDefinition
    -   PipelineContext
    -   StageContract
    -   ExecutionContext
    -   PluginManifest
    -   RuntimeMetrics
5.  Resource Models
    -   ResourceDescriptor (Phase 2 output)
    -   ValidationResult
    -   ClassificationResult
6.  Artifact Models
    -   Artifact
    -   ArtifactMetadata
    -   ArtifactLifecycle
7.  Processing Models
    -   CleanDocument (planned)
    -   StructuredDocument (planned)
    -   Chunk
    -   ChunkCollection
    -   Embedding
    -   EmbeddingCollection
8.  Retrieval Models
    -   RetrievalRequest
    -   RetrievalResult
    -   GroundedContext
9.  LLM Models
    -   PromptPackage
    -   LLMResponse
10. Response Models
11. Metadata Models
12. Serialization Rules
13. Validation Rules
14. Evolution & Backward Compatibility
15. Complete Object Relationship Diagram
16. Glossary

## Deliverables

Include: - Mermaid class diagrams - Object relationship diagrams -
Lifecycle diagrams - Example payloads - Cross references to
AIOS_Architecture_Guide.md

## Acceptance Criteria

The document becomes the single source of truth for every data contract
used by AIOS.
