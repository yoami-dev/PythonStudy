# AIOS Enterprise Knowledge Acquisition Platform

# Phase 1.5 -- Runtime Execution Standardization & Connector Foundation

> **Version:** 1.0\
> **Purpose:** Harden the Website Fetcher implementation and establish
> reusable execution standards before implementing Document Validation
> (Phase 2).

------------------------------------------------------------------------

# Objective

Phase 1 successfully introduced the first runtime-native stage.

Phase 1.5 standardizes how **all future pipeline stages and connectors**
execute.

No new Knowledge Acquisition functionality shall be implemented.

This phase focuses on **runtime consistency, SDK abstraction, connector
architecture, execution APIs, artifact identity, metrics, and retry
integration.**

------------------------------------------------------------------------

# Background

The current runtime is mature and the Website Fetcher is operational.

However, several architectural improvements should be completed before
additional stages are added to avoid technical debt.

This phase creates reusable enterprise building blocks for every future
stage.

------------------------------------------------------------------------

# In Scope

-   Runtime SDK
-   Generic Runtime Execution API
-   Connector Abstraction
-   Network Provider Abstraction
-   Artifact Content Addressing
-   Runtime Metrics Model
-   Runtime Context Enhancements
-   Recovery Policy Integration
-   Plugin Manifest Standard
-   Stage Naming Standard

------------------------------------------------------------------------

# Out of Scope

Do NOT implement:

-   HTML Validation
-   Content Cleaning
-   Extraction
-   Chunking
-   Embeddings
-   Retrieval
-   LLM
-   New Knowledge Acquisition functionality

------------------------------------------------------------------------

# Design Principles

-   Runtime First
-   SDK Driven
-   Provider Based
-   Configuration Driven
-   Connector Independent
-   Zero UI Changes
-   Backward Compatible

------------------------------------------------------------------------

# Target Architecture

``` text
Pipeline Runtime
      │
      ▼
Pipeline Runtime SDK
      │
      ├── Validation
      ├── Events
      ├── Artifact Manager
      ├── Audit
      ├── Metrics
      ├── Context
      └── Recovery
             │
             ▼
Connector
      │
      ▼
Network Provider
      │
      ▼
Website Fetcher
```

------------------------------------------------------------------------

# Runtime SDK

Create a single Runtime SDK to be used by every stage.

The SDK should expose reusable methods such as:

-   start_stage()
-   complete_stage()
-   fail_stage()
-   publish_event()
-   validate()
-   store_artifact()
-   update_context()
-   record_audit()
-   record_metrics()

Pipeline stages should no longer communicate directly with individual
runtime services.

------------------------------------------------------------------------

# Generic Runtime Execution API

Replace stage-specific execution endpoints with a generic runtime API.

Example:

POST /runtime/execute

Request includes:

-   pipeline
-   stage
-   execution context
-   input payload

The existing execute-fetch endpoint should remain temporarily for
backward compatibility and internally delegate to the generic execution
framework.

------------------------------------------------------------------------

# Connector Abstraction

Separate transport from business logic.

Introduce:

-   Connector Interface
-   Website Connector
-   Future connectors:
    -   PDF
    -   SharePoint
    -   GitHub
    -   Confluence
    -   REST API

Website Fetcher should consume a Connector instead of embedding
transport concerns.

------------------------------------------------------------------------

# Network Provider

Create a provider abstraction.

Responsibilities:

-   HTTP client
-   Proxy
-   Authentication
-   Cookies
-   Redirect handling
-   SSL
-   Timeout

The Website Fetcher must use the provider instead of directly using the
HTTP client library.

------------------------------------------------------------------------

# Plugin Manifest

Each plugin must expose:

-   Plugin ID
-   Version
-   Author
-   Description
-   Capabilities
-   Dependencies
-   Configuration Schema
-   Supported Runtime Version

------------------------------------------------------------------------

# Artifact Identity

Use content addressing.

Each artifact should include:

-   SHA256 checksum
-   ETag (if available)
-   Last Modified (if available)
-   Artifact Version
-   Storage Identifier

Artifact filenames should not be the primary identity.

------------------------------------------------------------------------

# Runtime Context

Extend runtime context with:

-   Current URL
-   Redirect Count
-   Retry Count
-   Download Size
-   MIME Type
-   Character Encoding
-   Checksum
-   Execution Policy

------------------------------------------------------------------------

# Runtime Metrics

Define a common metrics schema.

Include:

-   Total Duration
-   DNS Time
-   SSL Time
-   Transfer Time
-   Bytes Downloaded
-   Retry Count
-   Validation Duration
-   Artifact Count
-   Warning Count
-   Error Count

Collection of all metrics is not mandatory; the schema must exist.

------------------------------------------------------------------------

# Recovery Integration

The Website Fetcher must consume Recovery Manager policies.

Support:

-   Retry
-   Resume
-   Cancel

Policies must come from runtime configuration.

------------------------------------------------------------------------

# Stage Naming Standard

Replace numeric stage identifiers with semantic names.

Examples:

-   website-fetch
-   document-validation
-   content-cleaning
-   extraction
-   semantic-analysis
-   chunk-generation
-   embedding
-   retrieval

Numeric aliases may remain for backward compatibility.

------------------------------------------------------------------------

# Runtime APIs

Provide:

-   POST /runtime/execute
-   GET /runtime/metrics-schema
-   GET /runtime/plugin-manifests

Maintain backward compatibility with existing APIs.

------------------------------------------------------------------------

# Inspector Integration

No UI redesign.

Inspector should consume:

-   Runtime SDK execution
-   Semantic stage names
-   Artifact checksums
-   Metrics schema
-   Plugin manifest summary

------------------------------------------------------------------------

# Deliverables

-   Runtime SDK
-   Generic Execution API
-   Connector Framework
-   Network Provider
-   Plugin Manifest
-   Artifact Identity Enhancement
-   Runtime Context Enhancement
-   Metrics Schema
-   Recovery Integration
-   Updated Documentation

------------------------------------------------------------------------

# Regression Tests

Verify:

-   Existing Phase 1 functionality unchanged
-   Generic execution API works
-   Legacy execution endpoint still works
-   Runtime SDK delegates correctly
-   Connector abstraction works
-   Artifact checksum generated
-   Recovery policies honored
-   Plugin manifests available

------------------------------------------------------------------------

# Manual Validation

Confirm:

-   Website Fetcher operates through Runtime SDK
-   Connector abstraction active
-   Generic execution endpoint operational
-   Runtime context enriched
-   Metrics schema exposed
-   No HTML parsing performed
-   No Phase 2 functionality introduced

------------------------------------------------------------------------

# Acceptance Criteria

-   Runtime SDK adopted by Website Fetcher.
-   Generic execution API operational.
-   Connector and provider abstractions implemented.
-   Artifact content addressing available.
-   Runtime metrics schema defined.
-   Recovery policies integrated.
-   Backward compatibility preserved.
-   Phase 2 has not started.

------------------------------------------------------------------------

# Mandatory Rules

1.  Implement only Phase 1.5.
2.  Do not implement Document Validation.
3.  Preserve existing Inspector UI.
4.  Preserve backward compatibility.
5.  Do not introduce HTML parsing.
6.  Keep runtime configuration-driven.
7.  Provide:
    -   Updated architecture diagram
    -   Runtime sequence diagram
    -   Files created/modified
    -   API summary
    -   Regression results
    -   Manual validation checklist
    -   Known limitations
    -   Confirmation that Phase 2 has NOT started.
