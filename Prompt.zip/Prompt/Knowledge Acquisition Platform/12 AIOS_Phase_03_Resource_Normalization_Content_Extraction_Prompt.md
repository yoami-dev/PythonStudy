# AIOS Engineering Specification

# Phase 3 -- Resource Normalization & Content Extraction

> **Target Output:** Implement Phase 3 and produce a complete
> `Walkthrough.md`.

------------------------------------------------------------------------

# Objective

Implement **Phase 3 -- Resource Normalization & Content Extraction** in
full compliance with:

-   AIOS_Architecture_Guide.md
-   AIOS_Architecture_Governance.md
-   AIOS_Data_Model_Guide.md
-   AIOS_API_Reference.md
-   AIOS_Developer_Guide.md

This phase converts validated resources into clean, canonical documents
suitable for downstream processing.

**This phase does NOT perform chunking, embeddings, vector indexing,
retrieval, prompt construction, or LLM inference.**

------------------------------------------------------------------------

# Pre-Implementation Requirements

Before implementation:

1.  Review all architecture and governance documents.
2.  Reuse existing runtime services.
3.  Reuse canonical data contracts.
4.  Do not introduce architectural drift.

If architecture changes are required:

-   Update the Architecture Guide.
-   Include an Architecture Change Summary in the walkthrough.

------------------------------------------------------------------------

# Inputs

Consume the outputs from Phase 2:

-   ResourceDescriptor
-   ValidationResult
-   ClassificationResult
-   Raw resource artifact

Supported resource types:

-   HTML
-   PDF
-   DOCX
-   TXT
-   Markdown

Future placeholders only:

-   PPTX
-   XLSX
-   Images
-   Audio
-   Video

------------------------------------------------------------------------

# Responsibilities

Implement a runtime-native plugin that:

-   Extracts text from supported formats
-   Removes binary wrappers
-   Normalizes character encoding to UTF-8
-   Removes HTML boilerplate (scripts, styles, navigation, ads)
-   Preserves semantic text
-   Detects title
-   Detects author (when available)
-   Detects publish date (when available)
-   Preserves headings
-   Preserves hyperlinks as metadata
-   Preserves tables as structured placeholders
-   Preserves image references as metadata
-   Calculates extracted text statistics
-   Produces canonical CleanDocument

The stage shall NOT:

-   Chunk documents
-   Generate embeddings
-   Perform OCR
-   Summarize
-   Invoke LLMs
-   Rank content

------------------------------------------------------------------------

# Runtime Integration

Implement:

-   ResourceNormalizationPlugin

Subclass:

-   PipelinePlugin

Use:

-   PipelineRuntimeSDK
-   ArtifactManager
-   ValidationEngine
-   AuditManager
-   RecoveryManager
-   RuntimeMetrics
-   PipelineEventBus

------------------------------------------------------------------------

# Data Contracts

Reuse existing contracts.

Produce:

-   CleanDocument
-   ExtractionMetadata

Do not redefine canonical contracts.

------------------------------------------------------------------------

# Artifacts

Persist:

-   clean_document.json
-   extraction_metadata.json
-   extraction_report.json

All artifacts must use SHA-256 content addressing.

------------------------------------------------------------------------

# Events

Emit:

-   extraction.started
-   extraction.completed
-   extraction.failed

------------------------------------------------------------------------

# APIs

Expose:

POST /api/v1/knowledge-acquisition/runtime/normalize-resource

Delegate execution through:

POST /runtime/execute

No business logic inside controllers.

------------------------------------------------------------------------

# Metrics

Capture:

-   extraction duration
-   extraction success/failure
-   extracted character count
-   extracted word count
-   extraction warnings
-   content size reduction
-   supported resource distribution

------------------------------------------------------------------------

# Testing

Create:

-   Unit tests
-   Runtime integration tests
-   API tests
-   HTML extraction tests
-   PDF extraction tests
-   DOCX extraction tests
-   Markdown extraction tests
-   Failure tests

Run all previous regression suites.

------------------------------------------------------------------------

# Documentation Updates

Update documentation only if required:

-   AIOS_Architecture_Guide.md
-   AIOS_Data_Model_Guide.md
-   AIOS_API_Reference.md
-   AIOS_Developer_Guide.md

Mark Phase 3 as IMPLEMENTED if completed.

------------------------------------------------------------------------

# Deliverables

Implementation:

-   Runtime plugin
-   REST endpoint
-   Tests
-   Runtime metrics
-   Content-addressed artifacts

Documentation:

Produce Walkthrough.md with:

1.  Executive Summary
2.  Architecture Compliance
3.  Architecture Change Summary
4.  Runtime Interaction Diagram
5.  Files Created
6.  Files Modified
7.  API Summary
8.  Regression Tests
9.  Manual Validation Checklist
10. Known Limitations
11. Explicit Scope Confirmation

------------------------------------------------------------------------

# Acceptance Criteria

Implementation is accepted only if:

-   Fully architecture compliant
-   Uses PipelineRuntimeSDK
-   Uses canonical data contracts
-   Produces CleanDocument
-   Preserves metadata
-   Stores SHA-256 artifacts
-   Emits runtime events
-   Publishes runtime metrics
-   All regression tests pass
-   No chunking
-   No embeddings
-   No OCR
-   No retrieval
-   No LLM processing
