# AIOS Engineering Specification

# Prompt: Architecture Governance & Guide Maintenance Standard

> **Purpose:** Ensure every future implementation phase remains aligned
> with `AIOS_Architecture_Guide.md`.

------------------------------------------------------------------------

# Mandatory Pre-Implementation Step

Before implementing any new phase:

1.  Read and review `AIOS_Architecture_Guide.md`.
2.  Treat it as the authoritative architecture reference.
3.  Do not redefine architecture already documented.
4.  Implement only the requested phase.
5.  Preserve backward compatibility unless explicitly instructed
    otherwise.

------------------------------------------------------------------------

# Architecture Compliance

Every implementation must comply with:

-   Runtime First
-   SDK First
-   Plugin Architecture
-   Connector Framework
-   Configuration Driven Design
-   Event Driven Execution
-   Artifact Lifecycle
-   Content Addressing
-   Runtime APIs
-   Runtime Metrics
-   Pipeline Context
-   Validation Engine
-   Recovery Framework
-   Audit Framework

No implementation may bypass these architectural principles.

------------------------------------------------------------------------

# Architecture Change Rules

If implementation requires any architectural change:

-   Update `AIOS_Architecture_Guide.md`.
-   Do not silently introduce new architecture.
-   Clearly identify:
    -   New components
    -   Modified components
    -   Removed components
    -   Updated diagrams
    -   API changes
    -   Data contract changes
    -   Runtime changes

------------------------------------------------------------------------

# Architecture Change Summary

Every walkthrough must include a section:

## Architecture Change Summary

If no architectural changes occurred:

``` text
Architecture Change Summary

No architectural changes.

Implementation is fully compliant with AIOS_Architecture_Guide.md.
```

If changes occurred, include:

-   Reason
-   Impact
-   Updated sections
-   Backward compatibility assessment
-   Migration requirements (if any)

------------------------------------------------------------------------

# Required Walkthrough Sections

Every future walkthrough must include:

1.  Executive Summary
2.  Architecture Compliance
3.  Architecture Change Summary
4.  Runtime Interaction Diagram
5.  Files Created
6.  Files Modified
7.  API Summary
8.  Regression Tests
9.  Manual Validation
10. Known Limitations
11. Explicit Scope Confirmation

------------------------------------------------------------------------

# Documentation Rules

If architecture changes:

Update:

-   Component diagrams
-   Sequence diagrams
-   State diagrams
-   API documentation
-   Data contracts
-   Runtime model
-   Plugin model
-   Connector model
-   Roadmap (if affected)

Do not duplicate architecture already documented unless modified.

------------------------------------------------------------------------

# Engineering Standards

Future phases must:

-   Reuse Runtime SDK.
-   Use generic runtime execution.
-   Register plugins through Stage Registry.
-   Use Validation Engine.
-   Publish EventBus events.
-   Store artifacts only through Artifact Manager.
-   Record Audit entries.
-   Update Runtime Context.
-   Respect Pipeline Definition and Dependency Graph.

------------------------------------------------------------------------

# Explicit Restrictions

Do NOT:

-   Rewrite existing architecture without justification.
-   Introduce undocumented runtime services.
-   Bypass documented APIs.
-   Modify completed phases unless required for compatibility.
-   Start future phases outside the requested scope.

------------------------------------------------------------------------

# Acceptance Criteria

A phase is considered complete only if:

-   It complies with `AIOS_Architecture_Guide.md`.
-   Any architecture changes are documented.
-   Walkthrough contains an Architecture Change Summary.
-   Regression tests pass.
-   Scope boundaries are respected.

This governance prompt should be included or referenced in every future
engineering phase specification.
