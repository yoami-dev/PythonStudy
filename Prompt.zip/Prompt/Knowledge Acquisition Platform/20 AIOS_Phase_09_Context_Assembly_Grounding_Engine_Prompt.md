# AIOS Engineering Specification

# Phase 9 -- Context Assembly & Grounding Engine

> **Target Output:** Implement the enterprise Context Assembly &
> Grounding Engine and produce a complete `Walkthrough.md`.

------------------------------------------------------------------------

# Objective

Implement **Phase 9 -- Context Assembly & Grounding Engine**.

This phase consumes the canonical `RetrievalResult` produced in Phase 8
and constructs a grounded, citation-aware, token-budgeted context for
downstream LLM orchestration.

This phase SHALL NOT:

-   Invoke any LLM
-   Perform reasoning
-   Execute tool calling
-   Generate user responses

------------------------------------------------------------------------

# Compliance

Implementation must comply with:

-   AIOS_Architecture_Guide.md
-   AIOS_Architecture_Governance.md
-   AIOS_Data_Model_Guide.md
-   AIOS_API_Reference.md
-   AIOS_Developer_Guide.md

------------------------------------------------------------------------

# Inputs

Consume:

-   RetrievalResult
-   RetrievalStatistics
-   RetrievalValidationReport
-   RetrievalPolicy
-   TokenBudgetPolicy

------------------------------------------------------------------------

# Responsibilities

Implement:

-   ContextAssemblyPlugin
-   ContextAssemblyEngine
-   ContextBuilder
-   ContextBudgetManager
-   ContextOrderingEngine
-   ChunkOverlapResolver
-   GroundingEngine
-   CitationManager
-   ContextOptimizer
-   ContextValidator

------------------------------------------------------------------------

# Runtime Architecture

ContextAssemblyPlugin -\> ContextAssemblyEngine -\> ContextBuilder -\>
ContextOrderingEngine -\> ChunkOverlapResolver -\> ContextBudgetManager
-\> GroundingEngine -\> CitationManager -\> ContextOptimizer -\>
ContextValidator

------------------------------------------------------------------------

# Runtime Integration

Use:

-   PipelineRuntimeSDK
-   ArtifactManager
-   RuntimeMetrics
-   AuditManager
-   RecoveryManager
-   PipelineEventBus

------------------------------------------------------------------------

# Canonical Data Contracts

Create:

-   GroundedContext
-   ContextSection
-   ContextWindow
-   Citation
-   CitationCollection
-   ContextBudget
-   ContextAssemblyStatistics
-   ContextValidationReport
-   GroundingReport

Each ContextSection should include:

-   section_id
-   chunk_id
-   document_id
-   resource_id
-   ordered_position
-   token_count
-   relevance_score
-   citation_ids
-   provenance

------------------------------------------------------------------------

# Features

Support:

-   token budgeting
-   chunk ordering
-   overlap removal
-   duplicate suppression
-   document grouping
-   citation generation
-   grounding verification
-   configurable context policies
-   context optimization
-   namespace awareness

------------------------------------------------------------------------

# Artifacts

Persist:

-   grounded_context.json
-   context_statistics.json
-   context_validation_report.json
-   grounding_report.json
-   context_assembly_report.json

All artifacts must be SHA-256 content addressed.

------------------------------------------------------------------------

# Events

Emit:

-   context.assembly.started
-   context.ordering.completed
-   context.grounding.completed
-   context.validation.completed
-   context.assembly.completed
-   context.assembly.failed

------------------------------------------------------------------------

# API

Expose:

POST /api/v1/knowledge-acquisition/runtime/assemble-context

Business logic must execute through:

PipelineRuntimeEngine.execute_generic_stage()

------------------------------------------------------------------------

# Metrics

Capture:

-   context size
-   token utilization
-   token budget usage
-   chunks selected
-   chunks discarded
-   duplicate ratio
-   citation count
-   grounding duration
-   optimization duration

------------------------------------------------------------------------

# Testing

Create:

-   Context builder tests
-   Budget manager tests
-   Ordering tests
-   Overlap resolution tests
-   Citation tests
-   Grounding tests
-   Runtime integration tests
-   API tests
-   Full regression tests

------------------------------------------------------------------------

# Documentation

Update:

AIOS_Architecture_Guide.md

Mark:

Phase 9 -- Context Assembly & Grounding Engine

as IMPLEMENTED.

Update:

AIOS_API_Reference.md

Add:

POST /runtime/assemble-context

------------------------------------------------------------------------

# Deliverables

Implementation:

-   Runtime plugin
-   Context assembly engine
-   Budget manager
-   Ordering engine
-   Overlap resolver
-   Grounding engine
-   Citation manager
-   Context optimizer
-   Validator
-   REST endpoint
-   Metrics
-   Tests
-   Content-addressed artifacts

Documentation:

Produce Walkthrough.md containing:

1.  Executive Summary
2.  Architecture Compliance
3.  Architecture Change Summary
4.  Runtime Interaction Diagram
5.  Files Created
6.  Files Modified
7.  API Summary
8.  Regression Tests
9.  Manual Validation Checklist
10. Known Limitations
11. Explicit Scope Confirmation

------------------------------------------------------------------------

# Acceptance Criteria

Implementation is accepted only if:

-   Fully architecture compliant
-   Consumes RetrievalResult
-   Produces canonical GroundedContext
-   Supports configurable token budgets
-   Generates citations
-   Resolves overlapping chunks
-   Preserves provenance
-   Emits runtime events
-   Produces SHA-256 content-addressed artifacts
-   Regression tests pass
-   No prompt generation
-   No LLM invocation
-   No reasoning
-   No response generation
