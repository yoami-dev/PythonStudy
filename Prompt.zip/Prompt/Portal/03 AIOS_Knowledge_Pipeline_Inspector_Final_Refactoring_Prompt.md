# AIOS Knowledge Pipeline Inspector Refactoring (Final Correction)

## Objective

Refactor the Knowledge Pipeline Inspector into a true Runtime Execution
Console.

### Critical Rules

-   Pipeline Inspector belongs ONLY to Runtime Stages 0.5--12.
-   Remove ALL Product Capability cards (P1--P5) from this page.
-   Do not modify backend logic.

## Runtime Stages

0.5 Framework 0.6 Hardening 1 Acquisition 2 Validation 3 Normalization 4
Structuring 4.5 Chunking 5 Intelligent Chunking 6 Embedding Strategy 6.5
Embedding Generation 7 Vector Catalog 8 Retrieval 9 Context Assembly 10
LLM Orchestration 11 Response Generation 12 Enterprise Governance

## Every Stage Must Include

-   Overview
-   Execution
-   Configuration
-   Output
-   Diagnostics

## Execution Controls

-   Execute Stage
-   Run From Here
-   Run Pipeline (0.5--12)
-   Pause
-   Resume
-   Retry
-   Stop
-   Clear Output

## Global Toolbar

-   Run Pipeline
-   Pause
-   Resume
-   Stop
-   Export Runtime Snapshot
-   Live Metrics

## Remove

Remove Agent Studio, HITL, Workflow Studio, Marketplace and all P1--P5
cards from Pipeline Inspector.

## Engineering Portal

Pipeline Inspector is the Runtime Debug Console.

## Admin Portal

Business modules only.

## Reference

Implement the UI to match the supplied mockup: - Horizontal stage
selector - Runtime execution toolbar - Tabs (Overview, Execution,
Configuration, Output, Diagnostics) - Runtime artifacts and logs - No
dumping-zone cards

## Acceptance Criteria

-   Only Runtime stages 0.5--12 are visible.
-   Every stage is executable independently.
-   Full pipeline execution supported.
-   Product modules moved to their dedicated pages.
-   Walkthrough.md documents all corrections.
