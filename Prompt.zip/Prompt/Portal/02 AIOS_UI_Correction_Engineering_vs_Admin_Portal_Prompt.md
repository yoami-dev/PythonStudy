# AIOS UI Refactoring Correction Prompt

# Phase: Engineering Portal & Admin Portal UX Separation (Correction)

## Objective

Correct the current frontend implementation.

The previous implementation only changed the URL and header. The
Engineering Portal and Admin Portal still render almost identical pages
and reuse the same navigation and content.

This is **NOT** acceptable.

The purpose of this task is to create **two different user
experiences**, not merely two routes.

------------------------------------------------------------------------

# Critical Problems To Fix

## Problem 1

Admin Portal still displays engineering implementation phases such as:

-   Phase P3 Agent Studio
-   Phase P3.1 Agent Intelligence
-   Phase P3.2 HITL
-   Phase P3.3 Multi-Agent
-   Phase P4 Workflow Studio
-   Phase P5 Marketplace

These MUST NOT appear anywhere in the Admin Portal.

Replace them with business modules:

-   Agent Catalog
-   Agent Designer
-   AI Teams
-   Workflow Studio
-   Marketplace
-   etc.

Never show "P3", "P4", "Phase", "Platform Capability", "Product
Capability".

------------------------------------------------------------------------

## Problem 2

Pipeline Inspector still contains cards for:

-   Agent Studio
-   HITL
-   Workflow Studio
-   Marketplace

Remove them completely.

Pipeline Inspector is ONLY for Runtime phases (0.5-12).

It must inspect:

-   Acquisition
-   Validation
-   Normalization
-   Structuring
-   Chunking
-   Embeddings
-   Vector Store
-   Retrieval
-   Context Assembly
-   LLM
-   Response
-   Governance

Nothing else.

------------------------------------------------------------------------

## Problem 3

Admin Portal menu still mirrors Engineering navigation.

Replace with:

Dashboard

Knowledge - Sources - Crawlers - Uploads - Documents - Collections -
Search

Agents - Catalog - Designer - Intelligence - Teams - Deployments -
Statistics

Automation - Workflow Studio - Templates - Scheduler - Executions -
Analytics

Marketplace - Browse Packages - Installed Extensions - SDK Center -
Publishers - Certification

Administration - Users - Roles - Identity - Directory - Audit - Settings

Monitoring - Runtime - Pipelines - Agents - Workflows - Marketplace

------------------------------------------------------------------------

## Problem 4

Each module must become its own page.

Examples:

/admin/agents/catalog

/admin/agents/designer

/admin/agents/intelligence

/admin/agents/teams

/admin/workflows

/admin/marketplace

/admin/administration

Do NOT place everything on one dashboard.

------------------------------------------------------------------------

## Problem 5

Engineering Portal remains engineering-oriented.

Engineering pages should expose:

-   APIs
-   Logs
-   Events
-   Service Registry
-   Architecture
-   Metrics
-   Diagnostics
-   Runtime

Admin pages should expose:

-   Dashboards
-   Tables
-   Wizards
-   Forms
-   Business KPIs
-   Operations

------------------------------------------------------------------------

# Dashboard Requirements

Engineering Dashboard

-   Runtime Status
-   Pipeline Health
-   Service Health
-   Event Bus
-   API Status
-   Test Status
-   Build Version

Admin Dashboard

-   Total Documents
-   Total Agents
-   Active Workflows
-   Marketplace Packages
-   Active Users
-   Recent Alerts
-   Storage Usage
-   System Health

These dashboards must be completely different.

------------------------------------------------------------------------

# UI Requirements

Create different layouts.

Engineering

-   Technical
-   Diagnostic
-   Dense
-   Developer focused

Admin

-   Business
-   Executive
-   KPI cards
-   Charts
-   Operations

------------------------------------------------------------------------

# Remove

Remove every occurrence of:

"Phase"

"P3"

"P4"

"P5"

"Platform Capability"

"Product Capability"

from Admin Portal.

------------------------------------------------------------------------

# Validation Checklist

-   Admin Portal contains zero engineering phase labels.
-   Pipeline Inspector contains only runtime pipeline stages.
-   Every major capability has its own page.
-   Engineering and Admin dashboards are visually different.
-   Navigation differs between portals.
-   No backend changes.

Generate Walkthrough.md documenting all UI corrections.
