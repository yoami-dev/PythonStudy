# AIOS Product Suite

# Engineering Portal & Admin Portal Separation Prompt

## Objective

Refactor the AIOS frontend into **two independent portals** that consume
the **same backend services**.

This phase is a **UI/UX and navigation refactoring only**.

Do **NOT** redesign, modify, or duplicate any backend logic, APIs,
database schemas, services, workflows, orchestration, runtime
components, or platform capabilities.

------------------------------------------------------------------------

# Goals

Create two distinct experiences:

1.  **Engineering Portal**
    -   Used by AIOS developers, architects, QA, DevOps and platform
        engineers.
    -   Exposes implementation phases and engineering tooling.
2.  **Admin Portal**
    -   Used by enterprise administrators and operations teams.
    -   Exposes business capabilities instead of implementation phases.

Both portals must call the same REST APIs and backend services.

------------------------------------------------------------------------

# Architecture

                     AIOS Backend
                            │
            ┌───────────────┴───────────────┐
            │                               │
    Engineering Portal              Admin Portal

No duplicated business logic.

------------------------------------------------------------------------

# Engineering Portal

Keep the phase-oriented navigation.

## Runtime Platform

-   Phase 0.5 Framework
-   Phase 0.6 Hardening
-   Phase 1 Knowledge Acquisition
-   Phase 2 Resource Validation
-   Phase 3 Resource Normalization
-   Phase 4 Document Structuring
-   Phase 4.5 Chunking
-   Phase 5 Intelligent Chunk Generation
-   Phase 6 Embeddings
-   Phase 6.5 Embedding Generation
-   Phase 7 Vector Catalog
-   Phase 8 Retrieval
-   Phase 9 Context Assembly
-   Phase 10 LLM Orchestration
-   Phase 11 Response Presentation
-   Phase 12 Enterprise Governance

## Platform

-   P1 Enterprise Identity
-   P1.1 Enterprise Directory
-   P2 Enterprise Foundation
-   P2.1 Platform Kernel

## Agent Platform

-   P3 Agent Studio
-   P3.1 Agent Intelligence
-   P3.2 Human-in-the-Loop
-   P3.3 Native Multi-Agent Collaboration

## Automation

-   P4 Workflow Studio

## Ecosystem

-   P5 Marketplace & Developer SDK

## Engineering Tools

-   Pipeline Inspector
-   API Explorer
-   Event Viewer
-   Runtime Explorer
-   Service Registry
-   Logs
-   Metrics
-   Distributed Tracing
-   Test Suites
-   Feature Flags
-   Configuration
-   Health Dashboard

Each engineering page should expose diagnostics, logs, runtime events,
architecture diagrams, API endpoints, and developer documentation.

------------------------------------------------------------------------

# Admin Portal

Do NOT display phase numbers.

## Dashboard

-   Overview
-   Alerts
-   Usage
-   Health
-   Recent Activity

## Knowledge

-   Sources
-   Website Crawlers
-   Uploads
-   Documents
-   Collections
-   Embeddings
-   Vector Store
-   Search

## Agents

-   Catalog
-   Designer
-   Intelligence
-   Teams
-   Deployments
-   Statistics

## Automation

-   Workflow Studio
-   Scheduler
-   Events
-   Templates
-   Executions
-   Analytics

## Marketplace

-   Packages
-   Installed Extensions
-   SDK
-   CLI
-   Publishers
-   Certification

## Administration

-   Identity
-   Directory
-   Users
-   Roles
-   Audit
-   System Health
-   Logs
-   Settings

## Monitoring

-   Runtime
-   Pipelines
-   Agents
-   Workflows
-   Marketplace
-   Dashboards

------------------------------------------------------------------------

# Navigation Rules

Engineering Portal - Phase-based navigation - Technical terminology -
Debugging tools - Internal diagnostics

Admin Portal - Business terminology - Task-oriented navigation -
Operational dashboards - No implementation phases

------------------------------------------------------------------------

# UI Requirements

-   Shared design system
-   Shared authentication
-   Shared API layer
-   Shared RBAC
-   Shared notification framework
-   Responsive layouts
-   Breadcrumbs
-   Search
-   Favorites
-   Recently used
-   Global command palette

------------------------------------------------------------------------

# Routing

Example:

/engineering /engineering/runtime /engineering/p3-agent-studio
/engineering/pipeline-inspector

/admin /admin/dashboard /admin/knowledge /admin/agents /admin/workflows
/admin/marketplace

------------------------------------------------------------------------

# Migration

Move existing screens into the appropriate portal without changing
functionality.

Pipeline Inspector belongs only in Engineering Portal.

Workflow Studio, Marketplace, Agent Studio, HITL, and Multi-Agent become
standalone pages in the Admin Portal.

------------------------------------------------------------------------

# Documentation

Update:

-   AIOS_Architecture_Guide.md
-   AIOS_UI_Guide.md
-   AIOS_Developer_Guide.md

Create:

-   Engineering_Portal_Guide.md
-   Admin_Portal_Guide.md
-   Navigation_Guide.md

------------------------------------------------------------------------

# Walkthrough.md

Include:

1.  Executive Summary
2.  Portal Architecture
3.  Engineering Portal Navigation
4.  Admin Portal Navigation
5.  Routing Changes
6.  Shared Components
7.  Files Created
8.  Files Modified
9.  UI Screens
10. Security
11. Testing
12. Validation Checklist
13. Scope Confirmation

------------------------------------------------------------------------

# Acceptance Criteria

-   Engineering Portal and Admin Portal are independent frontends.
-   Both consume the same backend.
-   No backend redesign.
-   Pipeline Inspector exists only in Engineering Portal.
-   Admin Portal uses business-oriented navigation.
-   Engineering Portal retains phase-oriented navigation.
-   Existing capabilities are relocated without functional regression.
