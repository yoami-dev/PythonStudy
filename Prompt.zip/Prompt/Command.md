vailable Subcommands & Usage Examples:
  1. List Catalog Models:
  2. List Installed Models:
  3. Detailed Model Information:
  4. Install a Model:
  5. Remove a Model:
  6. Verify Model Integrity:
  7. Update Model Weights:
  8. Repair Corrupted Model:
  9. Search Catalog Models:

http://localhost:8000/api/v1/knowledge-mgmt/manage


Verified Endpoints:
📜 Swagger UI API Specs: http://localhost:8000/docs (HTTP 200 OK)
📋 Raw OpenAPI Schema: http://localhost:8000/api/v1/openapi.json (HTTP 200 OK, 298.9 KB JSON)
📖 ReDoc Explorer: http://localhost:8000/redoc (HTTP 200 OK)





[STATUS] Active Services & Endpoints
Enterprise AI Assistant: http://localhost:5173
FastAPI Application Health: http://localhost:8000/health
Interactive OpenAPI (Swagger) Documentation: http://localhost:8000/docs
OpenAPI Schema JSON: http://localhost:8000/api/v1/openapi.json
Enterprise RAG Document Upload Vault: http://localhost:8000/api/v1/knowledge-mgmt/upload


Admin Portal Main	http://localhost:5173/#admin/dashboard	Primary Admin Control Console & System Overview
AI Troubleshooting Console	http://localhost:5173/#admin/ai-troubleshooting	Real-time inspection of Organization Entity Detection, Knowledge Source Validation, Query Intent, and Hybrid Vector Scores
RAG Interactive Playground	http://localhost:5173/#admin/rag-playground	Interactive testing for vector search, context generation, and LLM reasoning



. Web Portal URLs (Frontend App)
Portal Section	URL	Description
Admin Portal Main	http://localhost:5173/#admin/dashboard	Primary Admin Control Console & System Overview
AI Troubleshooting Console	http://localhost:5173/#admin/ai-troubleshooting	Real-time inspection of Organization Entity Detection, Knowledge Source Validation, Query Intent, and Hybrid Vector Scores
RAG Interactive Playground	http://localhost:5173/#admin/rag-playground	Interactive testing for vector search, context generation, and LLM reasoning
(Note: If your local dev server port changed to 5176, access via http://localhost:5176/#admin/dashboard and http://localhost:5176/#admin/ai-troubleshooting).

2. Backend Server & Admin Endpoints (FastAPI)
Endpoint	URL	Description
Backend Admin Dashboard	http://localhost:8000/api/v1/auth/dashboard	Built-in FastAPI Admin Management Page
Interactive OpenAPI Docs	http://localhost:8000/docs	Swagger Interactive API Documentation
RAG Question Diagnostic API	POST http://localhost:8000/api/v1/knowledge-platform/question	Returns troubleshooting_console diagnostics breakdown


http://localhost:5173/#admin/pipeline-inspector
=========================================================
AIOS Platform Service Scripts Optimization Summary
Updated all platform startup, shutdown, and restart control scripts (.ps1, .bat, and .sh) across Windows and Linux/macOS environments to smoothly manage both the Frontend Web Server (Port 5173) and Backend Runtime Server (Port 8000).

1. Updated Scripts & Enhancements
PowerShell Scripts (scripts/bat/):



stop.ps1
: Terminates FastAPI Backend processes (Port 8000) and Frontend HTTP server processes (Port 5173) cleanly before checking containers.


start.ps1
: Starts the Frontend web server on Port 5173 (python -m http.server 5173 --directory apps/frontend) in a background window, then starts the FastAPI Backend on Port 8000 (uvicorn app.main:app). Displays formatted URLs for both services.


restart.ps1
: Executes stop.ps1, pauses 2 seconds to release port locks, then executes start.ps1.


start.bat
, 

stop.bat
, 

restart.bat
: Batch wrappers updated to pass execution policy bypass smoothly to PowerShell scripts.
Bash Scripts (scripts/shell/):



stop.sh
: Added pkill -f "http.server 5173" and pkill -f "uvicorn app.main:app".


start.sh
: Launches frontend server on port 5173 in the background (nohup $PYTHON_BIN -m http.server 5173 --directory "$FRONTEND_DIR") and backend on port 8000 (nohup $PYTHON_BIN -m uvicorn app.main:app).


restart.sh
: Executes stop.sh followed by start.sh.
2. Verification Results
Running .\scripts\bat\restart.bat produces:

=====================================================================
         STOPPING ENTERPRISE AIOS PLATFORM SERVICES...                
=====================================================================
[1/3] Terminating FastAPI Backend Processes (Port 8000)...
[2/3] Terminating Frontend HTTP Server Processes (Port 5173)...
[3/3] Checking Container Services...
✅ Enterprise AIOS Platform Services Stopped Successfully.
=====================================================================
         STARTING ENTERPRISE AIOS PLATFORM SERVICES...                
=====================================================================
[1/3] Checking Local Python Environment...
[2/3] Starting Frontend Web Server (Port 5173)...
[3/3] Starting FastAPI Backend Runtime Server (Port 8000)...
✅ Enterprise AIOS Platform Started Successfully!
  • Frontend UI: http://localhost:5173
  • Backend API: http://localhost:8000
  • OpenAPI Docs: http://localhost:8000/docs
  • Health Check: http://localhost:8000/health
Frontend Verification: http://localhost:5173/ $\rightarrow$ HTTP 200 OK
Backend Verification: http://localhost:8000/health $\rightarrow$ HTTP 200 OK ("healthy")
For full details, view 
walkthrough.md
.


.\scripts\bat\backup.bat project


Verified Access URLs
Admin Portal: http://localhost:5173/admin 
or 
http://localhost:5173/?portal=admin


Engineering Portal: http://localhost:5173/engineering 
or 
http://localhost:5173/?portal=engineering



Access Verification
All platform URLs are active and responding with 200 OK:

Frontend UI: http://localhost:5173
Admin Portal: http://localhost:5173/admin or http://localhost:5173/?portal=admin
Engineering Portal: http://localhost:5173/engineering or http://localhost:5173/?portal=engineering
Backend API & Health: http://localhost:8000/health and http://localhost:8000/portal