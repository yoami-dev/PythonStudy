# AIOS Approval Workflow Engine - Guide

**Document Status:** Production Baseline  
**Version:** 3.2.0 (Phase P3.2)  
**Scope:** Reusable approval patterns, multi-stage policies, and reviewer assignment rules.

---

## 1. Supported Approval Workflow Patterns
- **Single Approval**: Requires one reviewer approval to pass stage.
- **Multi Approval**: Requires multiple designated reviewers.
- **Sequential Approval**: Enforces ordered stage-by-stage progression.
- **Parallel Approval**: Evaluates all approval stages concurrently.
- **Consensus Approval**: Requires 100% unanimous approval from reviewer group.
- **Majority Approval**: Requires simple majority (>50%) of reviewer group.
- **Conditional Approval**: Evaluates approval rules based on request context variables.
- **Emergency Approval**: Bypasses standard multi-stage review with emergency administrative override.

---

## 2. Approval Request API
```python
from app.control_plane.human_loop_service import human_loop_service_instance

req = human_loop_service_instance.create_approval_request(
    agent_id="agt-rag-assistant-01",
    requester_id="usr-dev-001",
    title="Production Promotion Approval",
    description="Promoting agent to production environment."
)
dec = human_loop_service_instance.approve_request(req.request_id, "usr-admin-001", "Readiness checks passed.")
```
