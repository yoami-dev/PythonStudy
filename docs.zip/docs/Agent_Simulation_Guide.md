# AIOS Agent Simulator & Stress Testing - Guide

**Document Status:** Production Baseline  
**Version:** 3.1.0 (Phase P3.1)  
**Scope:** Multi-scenario simulation suite (`NORMAL`, `STRESS`, `TOOL_FAILURE`, `MEMORY_OVERFLOW`, `MISSING_KNOWLEDGE`, `ADVERSARIAL`, `HALLUCINATION`).

---

## 1. Simulation Scenarios
- `NORMAL`: Standard conversation evaluation.
- `STRESS`: High-throughput concurrent prompt evaluation.
- `TOOL_FAILURE`: Simulation of downstream API/tool outages.
- `MEMORY_OVERFLOW`: Evaluation of long-running conversation history bounds.
- `MISSING_KNOWLEDGE`: Verification of fallback behavior when RAG sources lack context.
- `ADVERSARIAL`: Prompt injection and jailbreak defense testing.
- `HALLUCINATION`: Hallucination detection and accuracy verification.

---

## 2. Simulation Execution API
```python
sim_res = agent_intelligence_service_instance.run_simulation("agt-rag-assistant-01", "STRESS")
```
