# AIOS Agent Orchestration Engine & Routing - Guide

**Document Status:** Production Baseline  
**Version:** 3.3.0 (Phase P3.3)  
**Scope:** Standardized Agent Contracts, capability-based dynamic routing, and Task DAG decomposition.

---

## 1. Standard Agent Contract
Every agent in AIOS exposes a standardized contract:
- **Identity & Persona**: `agent_id`, `version`, `persona_id`, `goals`.
- **Capabilities & Skills**: Reusable skills from Phase P3.1 (`skl-search`, `skl-rag`, `skl-codegen`, `skl-python`).
- **Input & Output Schemas**: Strictly typed JSON schemas for task input/output contracts.
- **Execution & Security Policies**: `AUTONOMOUS`, `HUMAN_APPROVAL`, `SANDBOX`.

---

## 2. Orchestration API
```python
from app.control_plane.agent_orchestrator import agent_orchestrator_instance

agents = agent_orchestrator_instance.discover_agents()
graph = agent_orchestrator_instance.decompose_task("Autonomous Refactoring System")
sess = agent_orchestrator_instance.start_collaboration("team-dev-squad", "Refactor Core Architecture")
```
