# AIOS Portal Navigation & Cross-Routing Specification

**Document Status:** Production Baseline  
**Version:** 5.0.0  
**Scope:** Portal Switcher navigation, cross-routing between `/engineering` and `/admin`, shared design system, and RBAC authorization.

---

## 1. Portal Switcher Standards
- **Header Switcher**: Top navbar header provides one-click switching between `[ 🛠️ Engineering Portal ]` (`/engineering`) and `[ 🏢 Admin Portal ]` (`/admin`).
- **Shared API Layer**: Both portals call the same FastAPI backend (`http://localhost:8000/api/v1/*`).
- **Zero Backend Modification**: UI refactoring only; no backend endpoints or data models are duplicated.
