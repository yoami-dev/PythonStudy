# AIOS Shared Context, Memory & Inter-Agent Messaging - Guide

**Document Status:** Production Baseline  
**Version:** 3.3.0 (Phase P3.3)  
**Scope:** Session context, team memory, reasoning artifacts, and inter-agent communication bus.

---

## 1. Inter-Agent Communication Modes
- **Event-Based Messaging**: Asynchronous event dispatch.
- **Request / Response**: Direct agent-to-agent command invocation.
- **Broadcast**: System-wide notifications to all team members.
- **Publish / Subscribe**: Topic-based channel subscriptions.
- **Streaming Updates**: Real-time streaming of partial reasoning artifacts.
