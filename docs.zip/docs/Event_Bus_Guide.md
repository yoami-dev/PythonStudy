# AIOS Platform Event Bus - Architecture Guide

**Document Status:** Production Baseline  
**Version:** 2.1.0 (Phase P2.1)  
**Scope:** Event routing, Pub/Sub, event persistence, Dead-Letter Queue (DLQ), and filtering.

---

## 1. Supported Event Topics
- **Runtime Events**: `kernel.started`, `service.registered`, `plugin.loaded`
- **Identity Events**: `identity.user.created`, `identity.login.success`
- **Notification Events**: `notification.sent`
- **License & Feature Events**: `license.validated`, `feature.resolved`
- **File Events**: `file.uploaded`

---

## 2. Pub/Sub API Usage
```python
# Subscribe to topic
platform_kernel_instance.event_bus.subscribe("file.uploaded", callback_function)

# Publish event
platform_kernel_instance.event_bus.publish("file.uploaded", {"file_id": "file-123"})
```
