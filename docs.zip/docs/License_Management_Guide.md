# AIOS License Management & Feature Control - Guide

**Document Status:** Production Baseline  
**Version:** 2.1.0 (Phase P2.1)  
**Scope:** License tier verification, seat limit enforcement, feature entitlement resolution, and hierarchical feature toggles.

---

## 1. Supported License Tiers
- **Community**: Basic open-source tier (5 seats limit).
- **Professional**: Business tier (50 seats limit).
- **Enterprise**: Complete enterprise platform tier (1000+ seats limit).
- **Developer**: Developer sandbox license.
- **Education**: Academic & research tier.

---

## 2. Hierarchical Feature Toggle Evaluation
Features are resolved hierarchically across:
1. License Tier
2. Tenant ID
3. Organization ID
4. Workspace ID
5. User Role
6. Environment (`local`, `docker`, `kubernetes`)
7. Region
