# AIOS Platform Kernel - Architecture & Operational Guide

**Document Status:** Production Baseline  
**Version:** 2.1.0 (Phase P2.1)  
**Scope:** Service discovery, dependency injection container, plugin framework, Platform Event Bus, notifications, licenses, hierarchical features, file management, and API gateway framework.

---

## 1. Executive Summary
The **Platform Kernel** serves as the central coordination layer sitting above the Enterprise Platform Foundation (P2) and below all business capabilities. It provides common runtime services that every future Product Suite module (Agent Studio, Workflow Studio, Marketplace, Billing, Customer Portal) consumes without modifying or redesigning the Knowledge Acquisition Runtime (Phases 0.5-12), Identity Platform (P1), Directory Platform (P1.1), or Platform Foundation (P2).

---

## 2. Platform Kernel Architecture

```
                               ┌────────────────────────────────────────────────┐
                               │       REST API Gateway (/api/v1/kernel/*)      │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │                 PlatformKernel                 │
                               └───────────────────────┬────────────────────────┘
                                                       │
         ┌───────────────────────┬─────────────────────┼───────────────────────┬──────────────────────┐
         ▼                       ▼                     ▼                       ▼                      ▼
┌─────────────────┐     ┌─────────────────┐   ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
│ ServiceRegistry │     │ PluginFramework │   │ Platform        │     │ Notifications   │    │ Licensing       │
│ & DI Container  │     │ & Lifecycle     │   │ Event Bus       │     │ & Multi-Channel │    │ & Feature Toggles│
└─────────────────┘     └─────────────────┘   └─────────────────┘     └─────────────────┘    └─────────────────┘
```

---

## 3. Subsystem Overview
- **ServiceRegistry & DI Container**: Central service discovery, versioning, metadata, and Dependency Injection container (`Singleton`, `Transient`, `Scoped`, `Factory`).
- **PluginFramework**: Dynamic plugin loading, dependency resolution, lifecycle management, and permissions for Marketplace, Workflow, Search, and AI Agents.
- **PlatformEventBus**: Pub/Sub event bus supporting event persistence, subscriber dispatch, filtering, and Dead-Letter Queues.
- **NotificationPlatform**: Multi-channel notification engine (Email, SMS, Slack, Teams, Discord, Webhooks, Push) with template rendering and retry mechanisms.
- **LicenseManager & FeatureManager**: Enterprise license tier verification (`Community`, `Professional`, `Enterprise`, `Developer`, `Education`), seat limit checks, and hierarchical feature toggles.
- **FileManager**: Managed file lifecycle (upload, download, metadata, versioning, virus scanning hooks) backed by P2 `ObjectStorageManager`.
- **APIGatewayFramework**: Auth integration, rate limiting, quota enforcement, and request/response transformations.
