# AIOS Agent Team Design & Topologies - Guide

**Document Status:** Production Baseline  
**Version:** 3.3.0 (Phase P3.3)  
**Scope:** Team topology patterns (`SUPERVISOR_WORKER`, `PLANNER_EXECUTOR`, `HIERARCHICAL`, `SWARM`, `COMMITTEE`, `PIPELINE`, `DYNAMIC`).

---

## 1. Supported Team Topologies
- **Supervisor / Worker**: Supervisor orchestrates subtask assignments to worker agents.
- **Planner / Executor**: Planner agent generates plan graph; executor agents execute subtasks.
- **Hierarchical Teams**: Multi-level management tree for enterprise projects.
- **Swarm Teams**: Decentralized autonomous agents collaborating on dynamic tasks.
- **Committee Teams**: Voting body evaluating consensus proposals.
- **Pipeline Teams**: Sequential data processing pipeline of specialized agents.
- **Dynamic Teams**: Runtime auto-scaling team composition based on task complexity.
