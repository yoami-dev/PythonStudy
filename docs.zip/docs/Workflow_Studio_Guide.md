# AIOS Workflow Studio & Business Process Automation - Architecture Guide

**Document Status:** Production Baseline  
**Version:** 4.0.0 (Phase P4)  
**Scope:** Low-code/no-code Workflow Studio, visual node canvas palette, pre-packaged business process templates, version publishing, long-running workflow checkpoints, step tracing, and operational analytics across AIOS.

---

## 1. Executive Summary
**Workflow Studio** serves as the enterprise business process composition layer of AIOS. It composes Humans, AI Agent Teams, Enterprise Systems, Connectors, APIs, Events, Documents, Rules, and Schedules into versioned, long-running workflow graphs. It consumes existing platform capabilities (Agent Studio P3, Agent Intelligence P3.1, HITL P3.2, Multi-Agent Collaboration P3.3, Platform Kernel P2.1, Foundation P2, Identity P1/P1.1, and Runtime 0.5-12) without duplicating execution logic.

---

## 2. System Architecture

```
                               ┌────────────────────────────────────────────────┐
                               │        REST API Gateway (/api/v1/*)           │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │             WorkflowStudioService              │
                               └───────────────────────┬────────────────────────┘
                                                       │
         ┌───────────────────────┬─────────────────────┼───────────────────────┬──────────────────────┐
         ▼                       ▼                     ▼                       ▼                      ▼
┌─────────────────┐     ┌─────────────────┐   ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
│ WorkflowDesigner│     │ Template &      │   │ WorkflowEngine  │     │ RuleEngine &    │    │ Analytics &     │
│ & Node Palette  │     │ Version Manager │   │ & Checkpoints   │     │ Expression Eval │    │ Step Tracing    │
└─────────────────┘     └─────────────────┘   └─────────────────┘     └─────────────────┘    └─────────────────┘
```

---

## 3. Subsystem Overview
- **WorkflowDesigner & Node Palette**: Visual drag-and-drop node graph canvas supporting 4 node categories (`HUMAN`, `AI`, `ENTERPRISE`, `LOGIC`).
- **WorkflowTemplateManager & WorkflowVersionManager**: Manages pre-packaged business process templates and immutable version publishing (`v1.0.0`, `v1.1.0`).
- **WorkflowEngine & WorkflowRuntime**: Executes workflow graphs with support for long-running checkpoints and state persistence.
- **WorkflowRuleEngine & WorkflowValidator**: Expression evaluation (`If/Else`, `Switch`, `Loop`) and node connection validation.
- **WorkflowExecutionManager & WorkflowAnalyticsManager**: Step-by-step execution tracing, variable inspection, failure visualization, and operational analytics.
