# AIOS Engineering Portal - Architecture & Navigation Guide

**Document Status:** Production Baseline  
**Version:** 5.0.0  
**Scope:** Engineering Portal (`/engineering/*`), Phase-oriented navigation (Phases 0.5-12, P1, P1.1, P2, P2.1, P3, P3.1, P3.2, P3.3, P4, P5), Pipeline Inspector, API Explorer, Event Viewer, Service Registry, Distributed Tracing, and Health Probes.

---

## 1. Executive Summary
The **Engineering Portal** is designed specifically for AIOS platform developers, architects, QA, DevOps, and platform engineers. It exposes implementation phases and technical engineering tooling with deep diagnostics, runtime events, logs, metrics, distributed tracing, and architectural diagrams.

---

## 2. Navigation Architecture

```
Engineering Portal (/engineering/*)
 ├── Engineering Tools (Pipeline Inspector, API Explorer, Event Viewer, Service Registry, Tracing)
 ├── Runtime Platform (Phases 0.5 - 12)
 ├── Platform Kernel & Foundation (P1, P1.1, P2, P2.1)
 ├── Agent Platform & Automation (P3, P3.1, P3.2, P3.3, P4)
 └── Ecosystem (P5 Marketplace & Developer SDK)
```

---

## 3. Key Subsystems & Tools
- **Pipeline Inspector**: Deep inspection of stage contracts, input/output validation, and execution timelines.
- **API Explorer & Event Viewer**: Interactive OpenAPI docs (`/docs`) and real-time `PlatformEventBus` telemetry stream.
- **Service Registry & Tracing**: Microservice registry inspects container services, version numbers, and dependencies.
