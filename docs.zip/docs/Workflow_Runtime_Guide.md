# AIOS Workflow Runtime & Long-Running Execution - Guide

**Document Status:** Production Baseline  
**Version:** 4.0.0 (Phase P4)  
**Scope:** Graph execution engine, long-running workflow checkpoints, and resume after restart.

---

## 1. Execution Modes & Checkpoint Persistence
- **Synchronous & Asynchronous Execution**: Real-time or background task execution.
- **Event-Driven & Scheduled Triggers**: Triggered by system events or cron schedules.
- **Long-Running Checkpoints**: Persists variable states and current node position into `WorkflowCheckpointTable` to allow resuming after restart.

---

## 2. Workflow Execution API
```python
from app.control_plane.workflow_studio_service import workflow_studio_service_instance

wf = workflow_studio_service_instance.get_workflow("wf-code-audit-01")
execution = workflow_studio_service_instance.execute_workflow(wf.workflow_id, {"env": "production"})
```
