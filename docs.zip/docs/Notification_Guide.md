# AIOS Notification Platform - Provider & Router Guide

**Document Status:** Production Baseline  
**Version:** 2.1.0 (Phase P2.1)  
**Scope:** Provider abstraction, multi-channel routing, notification templates, and retry handling.

---

## 1. Supported Notification Channels
- `email`: Enterprise SMTP email mailer.
- `sms`: Twilio / SMS provider.
- `slack`: Slack bot webhooks.
- `teams`: Microsoft Teams webhooks.
- `discord`: Discord bot webhooks.
- `webhook`: Generic HTTP POST webhooks.
- `push`: Mobile APNS / FCM push notifications.

---

## 2. Notification Dispatch API
```python
res = platform_kernel_instance.send_notification(
    channel="slack",
    recipient="#dev-alerts",
    message="AIOS Kernel backup snapshot created successfully."
)
```
