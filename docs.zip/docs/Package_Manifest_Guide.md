# AIOS Package Manifest Schema & Dependency Resolution - Guide

**Document Status:** Production Baseline  
**Version:** 5.0.0 (Phase P5)  
**Scope:** `PackageManifest` JSON schema specification, dependency tree resolution, and version range matching.

---

## 1. Package Manifest Schema Fields
- **Name & ID**: Unique package identifier (`pkg-sap-erp-connector`) and display name.
- **Version & Category**: Version tag (`1.0.0`) and package category (`Agent`, `Agent Team`, `Workflow`, `Connector`, `Skill`, `Template`, `Plugin`).
- **Publisher**: Verified publisher details (`name`, `email`, `verified`).
- **Dependencies**: List of required extension packages with version ranges (`>=1.0.0`).
- **Min AIOS Version & Permissions**: Core engine compatibility (`min_aios_version`) and namespaced permissions required.
- **Digital Signature**: RSA/ECDSA digital signature string for package integrity verification.
