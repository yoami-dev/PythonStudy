# AIOS Agent Deployment, Versioning & Rollback - Operational Guide

**Document Status:** Production Baseline  
**Version:** 3.0.0 (Phase P3)  
**Scope:** Multi-environment deployments (`draft`, `testing`, `staging`, `production`), immutable version tags, promotion rules, and automated rollback.

---

## 1. Supported Deployment Environments
- `draft`: Development environment for agent design and iteration.
- `testing`: Isolated sandbox environment for automated test suites.
- `staging`: Pre-production environment for integration testing.
- `production`: High-availability production environment.

---

## 2. Automated Versioning & Rollback Workflow

```python
from app.control_plane.agent_studio_service import agent_studio_service_instance

# Update Agent profile (automatically creates v1.1.0 version tag)
agent = agent_studio_service_instance.update_agent("agt-rag-assistant-01", name="Enhanced RAG Assistant")

# Deploy to Production
deployment = agent_studio_service_instance.deploy_agent("agt-rag-assistant-01", "production")

# Rollback to v1.0.0
version = agent_studio_service_instance.rollback_agent("agt-rag-assistant-01", "v1.0.0")
```
