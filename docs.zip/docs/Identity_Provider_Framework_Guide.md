# AIOS Identity Provider Framework - Technical Guide

**Document Status:** Production Baseline  
**Version:** 1.1.0 (Phase P1.1)  
**Scope:** Provider abstraction, Local, OAuth2, OIDC, and enterprise IdP integrations (Microsoft Entra ID, Keycloak, Okta, Auth0, SAML 2.0).

---

## 1. Overview
The **Identity Provider Framework** decouples application services from authentication implementations through `IdentityProviderInterface`.

---

## 2. Supported Provider Types
- **Local Identity (`local`)**: Local username/password authentication using Bcrypt password hashing.
- **OpenID Connect (`oidc`)**: Standard OIDC token validation & claim mapping.
- **OAuth 2.0 (`oauth2`)**: OAuth2 authorization code flow & access token verification.
- **Enterprise Extensions**: Microsoft Entra ID, Keycloak, Okta, Auth0, SAML 2.0, and LDAP adapters.

---

## 3. Provider Registration API

```http
POST /api/v1/identity/providers
Content-Type: application/json

{
  "provider_id": "idp-okta-prod",
  "provider_type": "okta",
  "name": "Okta Enterprise Workforce",
  "config": {
    "client_id": "0oae12345678",
    "issuer_url": "https://enterprise.okta.com"
  }
}
```
