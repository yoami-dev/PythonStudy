# AIOS Command Line Interface (CLI) - Reference Guide

**Document Status:** Production Baseline  
**Version:** 5.0.0 (Phase P5)  
**Scope:** AIOS CLI command-line tool (`aios init`, `aios build`, `aios package`, `aios validate`, `aios publish`, `aios install`, `aios upgrade`, `aios uninstall`, `aios login`, `aios marketplace search`).

---

## 1. Supported CLI Commands
- `aios init <project_name>`: Scaffolds a new AIOS extension project.
- `aios build`: Compiles extension source code.
- `aios package`: Bundles extension manifest and artifacts into a `.aiospkg` zip package.
- `aios validate`: Runs local manifest schema validation and dependency checks.
- `aios publish`: Submits package to AIOS Marketplace certification pipeline.
- `aios install <package_id>`: Downloads and installs an extension package.
- `aios upgrade <package_id>`: Upgrades an installed extension to the latest version.
- `aios uninstall <package_id>`: Uninstalls an installed extension.
- `aios login`: Authenticates CLI user credentials against Phase P1 Identity Engine.
- `aios marketplace search <query>`: Queries Marketplace catalog packages.
