# AIOS Extension Certification Pipeline & Digital Signatures - Guide

**Document Status:** Production Baseline  
**Version:** 5.0.0 (Phase P5)  
**Scope:** Certification review states (`Draft`, `Submitted`, `Security Review`, `Compliance Review`, `Certified`, `Published`, `Deprecated`, `Archived`) and digital signature verification.

---

## 1. Certification Review Pipeline
- **Draft / Submitted**: Extension developer packages and submits extension.
- **Security & Compliance Review**: Automated static code analysis, vulnerability scanning, and permission validation.
- **Certified & Published**: Approved extension is assigned a digital certificate and indexed into Marketplace catalog.
