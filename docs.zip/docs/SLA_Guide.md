# AIOS SLA Tracking & Escalation - Guide

**Document Status:** Production Baseline  
**Version:** 3.2.0 (Phase P3.2)  
**Scope:** Service level agreement profiles, escalation rules, and breach notifications.

---

## 1. SLA Profiles & Escalation Rules
- **SLA Profiles**: Defines resolution target hours and warning thresholds per task priority (`CRITICAL`: 2h target, `HIGH`: 8h target, `MEDIUM`: 24h target).
- **Time-Based Escalation**: Automatically reassigns overdue tasks to escalation groups (`grp-compliance-lead`).
- **Role-Based Escalation**: Escalates tasks to higher-tier roles upon initial reviewer inaction.

---

## 2. SLA Check API
```python
sla_status = human_loop_service_instance.sla_service.check_sla(task)
```
