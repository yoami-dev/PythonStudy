# AIOS Visual Workflow Designer & Node Palette - Guide

**Document Status:** Production Baseline  
**Version:** 4.0.0 (Phase P4)  
**Scope:** Reusable node palette (`HUMAN`, `AI`, `ENTERPRISE`, `LOGIC`), canvas graph building, and validation rules.

---

## 1. Reusable Node Categories
- **Human Nodes**: `Approval`, `Review`, `Manual Task`, `Escalation`, `Notification` (consumes HITL P3.2).
- **AI Nodes**: `Single Agent`, `Agent Team`, `Agent Collaboration`, `Planner`, `Supervisor` (consumes Agent Studio P3 & Multi-Agent P3.3).
- **Enterprise Nodes**: `REST API`, `Database`, `Queue`, `File`, `Email`, `Webhook`, `Connector`, `ERP`, `CRM` (consumes Platform Kernel P2.1).
- **Logic Nodes**: `Decision`, `Switch`, `If/Else`, `Loop`, `Parallel`, `Merge`, `Split`, `Retry`, `Delay`, `Timer`.
