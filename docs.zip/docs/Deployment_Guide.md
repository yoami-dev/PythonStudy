# AIOS Cloud-Native Deployment Guide

**Document Status:** Production Baseline  
**Version:** 2.0.0 (Phase P2)  
**Scope:** Twelve-Factor App principles, Docker Compose, Kubernetes, Health & Liveness probes.

---

## 1. Twelve-Factor App Compliance
1. **Codebase**: Tracked in single Git repository (`aios`).
2. **Dependencies**: Explicitly declared in `requirements.txt` / `pyproject.toml`.
3. **Config**: Environment variables stored in environment profiles.
4. **Backing Services**: PostgreSQL, Redis, MinIO treated as attached resources.
5. **Build, Release, Run**: Strict separation of build and runtime stages.
6. **Processes**: Stateless FastAPI backend workers.
7. **Port Binding**: Self-contained services bound to ports `8000` (Backend) and `5173` (Frontend).
8. **Concurrency**: Scale out via stateless process model.
9. **Disposability**: Fast startup and graceful shutdown.
10. **Dev/Prod Parity**: Identical service stack across environments.
11. **Logs**: Streamed to stdout and captured by Enterprise Governance.
12. **Admin Processes**: One-off management scripts in `scripts/`.
