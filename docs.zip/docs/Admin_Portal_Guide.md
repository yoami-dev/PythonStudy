# AIOS Admin Portal - Architecture & Navigation Guide

**Document Status:** Production Baseline  
**Version:** 5.0.0  
**Scope:** Admin Portal (`/admin/*`), Business-oriented task navigation (Dashboard, Knowledge, Agents, Automation, Marketplace, Administration, Monitoring), and Operational Management.

---

## 1. Executive Summary
The **Admin Portal** is designed for enterprise administrators and operations teams. It presents business capabilities cleanly using task-based navigation and **displays NO phase numbers**. It exposes standalone business modules calling the same backend REST APIs (`/api/v1/*`).

---

## 2. Navigation Architecture

```
Admin Portal (/admin/*)
 ├── Dashboard (Overview, Alerts, Usage, Health, Activity)
 ├── Knowledge (Sources, Crawlers, Uploads, Documents, Collections, Search)
 ├── Agents (Catalog, Designer, Intelligence, Teams, Deployments, Statistics)
 ├── Automation (Workflow Studio, Scheduler, Events, Templates, Executions, Analytics)
 ├── Marketplace (Packages, Installed Extensions, SDK, CLI, Certification)
 ├── Administration (Identity, Directory, Users, Roles, Audit, Settings)
 └── Monitoring (Runtime, Pipelines, Agents, Workflows, Marketplace)
```

---

## 3. Business Capabilities
- **Knowledge Vault**: Enterprise document ingestion, website crawlers, vector index management, and RAG search.
- **Agents & Multi-Agent Teams**: Agent Studio, skills catalog, team topologies, and collaboration sessions.
- **Workflow Studio**: Visual process composition, version publishing, long-running checkpoints, and step tracing.
- **Marketplace**: Extension package installation, developer SDK projects, CLI command execution, and certification.
- **Identity & Governance**: RBAC permissions, directory catalog, user management, and immutable audit logs.
