# AIOS Enterprise Directory Platform - Architecture & Operational Guide

**Document Status:** Production Baseline  
**Version:** 1.1.0 (Phase P1.1)  
**Scope:** Architecture, data contracts, search index cataloging, device/session management, and API reference for the AIOS Enterprise Directory Platform.

---

## 1. Executive Summary
The **Enterprise Directory Platform** acts as the single authoritative identity catalog across the AIOS Product Suite. All identity resolution, permission evaluation, device tracking, and session lookups resolve through `EnterpriseDirectory`.

---

## 2. Directory Architecture

```
                               ┌────────────────────────────────────────────────┐
                               │       Client / REST API Gateway (/identity)    │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │           EnterpriseDirectory Catalog          │
                               └───────────────────────┬────────────────────────┘
                                                       │
         ┌───────────────────────┬─────────────────────┼───────────────────────┬──────────────────────┐
         ▼                       ▼                     ▼                       ▼                      ▼
┌─────────────────┐     ┌─────────────────┐   ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
│     Users       │     │  Organizations  │   │   Workspaces    │     │ User Devices    │    │ Active Sessions │
│   & Tenants     │     │   & Groups      │   │  & Projects     │     │ & Trust Scores  │    │ & Revocations   │
└─────────────────┘     └─────────────────┘   └─────────────────┘     └─────────────────┘    └─────────────────┘
```

---

## 3. Core Capabilities
- **Single Catalog Lookup**: `query_directory(search_term)` aggregates matches across users, orgs, workspaces, groups, roles, permissions, and devices.
- **Device Management**: Device registration, browser/OS fingerprinting, trust scoring, and remote device revocation.
- **Session Governance**: Multi-device session tracking, IP geolocation context, and active session termination.
- **Telemetry Event Logging**: Real-time capturing of identity events (`user.locked`, `mfa.enabled`, `device.registered`, `session.revoked`) with automatic forwarding to Enterprise Governance (Phase 12).
