# AIOS Developer SDK & Extension Platform - Guide

**Document Status:** Production Baseline  
**Version:** 5.0.0 (Phase P5)  
**Scope:** AIOS Extension SDK, Agent SDK, Workflow SDK, Connector SDK, Plugin SDK, and local project scaffolding.

---

## 1. SDK Project Scaffolding API
```python
from app.control_plane.marketplace_service import marketplace_service_instance

proj = marketplace_service_instance.create_sdk_project("Custom FinTech Risk Agent SDK", "agent", "./plugins/risk_agent")
projects = marketplace_service_instance.list_sdk_projects()
```
