# AIOS Agent Studio - Architecture & Operational Guide

**Document Status:** Production Baseline  
**Version:** 3.0.0 (Phase P3)  
**Scope:** Agent design, blueprint catalog, archetype templates, multi-environment deployments, versioning, automated rollback, and execution policy governance.

---

## 1. Executive Summary
**Agent Studio** is the first customer-facing AIOS Product Suite capability. It enables enterprises to design, deploy, govern, test, and operate AI agents. Agent Studio consumes the underlying platform—Knowledge Acquisition Runtime (0.5-12), Enterprise Identity Platform (P1), Enterprise Directory (P1.1), Enterprise Platform Foundation (P2), and Platform Kernel (P2.1)—without duplicating or redesigning platform infrastructure.

---

## 2. Agent Studio Architecture

```
                               ┌────────────────────────────────────────────────┐
                               │        REST API Gateway (/api/v1/agents*)      │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │               AgentStudioService               │
                               └───────────────────────┬────────────────────────┘
                                                       │
         ┌───────────────────────┬─────────────────────┼───────────────────────┬──────────────────────┐
         ▼                       ▼                     ▼                       ▼                      ▼
┌─────────────────┐     ┌─────────────────┐   ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
│ AgentDesigner   │     │ AgentCatalog    │   │ Deployment &    │     │ ExecutionPolicy │    │ Platform Kernel │
│ & Profiles      │     │ & Templates     │   │ Version Manager │     │ Governance      │    │ Integration     │
└─────────────────┘     └─────────────────┘   └─────────────────┘     └─────────────────┘    └─────────────────┘
```

---

## 3. Subsystem Overview
- **AgentDesigner & AgentCatalog**: Visual composition engine and agent blueprint catalog (`create_agent`, `update_agent`, `list_agents`).
- **AgentTemplateManager**: Template library containing pre-configured agent archetypes (Enterprise RAG Assistant, Code Refactoring Bot, Customer Support Agent).
- **AgentDeploymentManager & AgentVersionManager**: Multi-environment deployment (`draft`, `testing`, `staging`, `production`), immutable version snapshotting (`v1.0.0`, `v1.1.0`), and automated version rollback.
- **AgentExecutionPolicyManager**: Execution policy governance (`HUMAN_APPROVAL`, `AUTONOMOUS`, `READ_ONLY`, `RESTRICTED`, `SANDBOX`).
- **Platform Integration**: Registers with `PlatformKernel.service_registry`, dispatches events to `PlatformEventBus` (`agent.created`, `agent.updated`, `agent.deployed`, `agent.rollback`, `agent.executed`, `agent.failed`, `agent.deleted`), and forwards audit logs to Enterprise Governance via `PipelineRuntimeSDK`.
