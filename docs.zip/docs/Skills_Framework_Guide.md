# AIOS Reusable Skills Framework & Capability Registry - Guide

**Document Status:** Production Baseline  
**Version:** 3.1.0 (Phase P3.1)  
**Scope:** Reusable skill categories, versioning, capability discovery, and dependency resolution.

---

## 1. Supported Skill Categories
- `search`: Web search query execution.
- `rag`: Vector database retrieval.
- `sql`: Read-only SQL query execution.
- `python`: Sandboxed Python code evaluation.
- `email`: SMTP mail dispatch.
- `calendar`: Calendar event synchronization.
- `crm`: Salesforce / HubSpot CRM integration.
- `erp`: SAP / NetSuite ERP integration.
- `vision`: OCR image text extraction.
- `speech`: Audio TTS & STT processing.
- `code_gen`: Code synthesis.
- `doc_processing`: PDF and Word document parsing.

---

## 2. Reusable Skill API
```python
from app.control_plane.agent_intelligence_service import agent_intelligence_service_instance

skills = agent_intelligence_service_instance.list_skills()
capabilities = agent_intelligence_service_instance.list_capabilities()
```
