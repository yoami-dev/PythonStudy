# AIOS Enterprise Identity Platform - Architecture Guide

**Document Status:** Production Baseline  
**Version:** 1.0.0 (Phase P1)  
**Scope:** Architecture, data models, authentication mechanisms, authorization engines, RBAC/ABAC models, tenant isolation, and API surfaces for the AIOS Enterprise Identity Platform.

---

## 1. Executive Summary
The **AIOS Enterprise Identity Platform** provides production-grade multi-tenant identity, authentication, authorization, RBAC, and governance integration for the AIOS Product Suite. Built on persistent SQLAlchemy database models, Bcrypt password hashing, JWT access/refresh token rotation, API keys, and service accounts, it consumes the underlying `PipelineRuntimeSDK` and forwards audit events to Enterprise Governance (Phase 12) without modifying the core Knowledge Acquisition Runtime (Phases 0.5-12).

---

## 2. System Architecture

```
                               ┌────────────────────────────────────────────────┐
                               │  REST API Gateway (/api/v1/auth & /identity)   │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │          IdentityService Facade                │
                               └───────────────────────┬────────────────────────┘
                                                       │
         ┌───────────────────────┬─────────────────────┼───────────────────────┬──────────────────────┐
         ▼                       ▼                     ▼                       ▼                      ▼
┌─────────────────┐     ┌─────────────────┐   ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
│ Authentication  │     │ Authorization   │   │  RBAC Engine    │     │  ABAC Engine    │    │ Tenant & Org    │
│ Engine (Bcrypt) │     │ Engine          │   │ (Roles & Perms) │     │ (Attributes)    │    │ Managers        │
└────────┬────────┘     └────────┬────────┘   └────────┬────────┘     └────────┬────────┘    └────────┬────────┘
         │                       │                     │                       │                      │
         └───────────────────────┴─────────────────────┼───────────────────────┴──────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │      SQLAlchemy Persistent Identity Models     │
                               │  (Users, Tenants, Orgs, Workspaces, Roles)     │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │     PipelineRuntimeSDK & Enterprise Governance  │
                               └────────────────────────────────────────────────┘
```

---

## 3. Core Subsystems

### 3.1 AuthenticationEngine
- **Passwords**: Bcrypt password hashing and validation.
- **JWT Tokens**: Signed access tokens (60 min expiry) and refresh tokens (7 day expiry).
- **API Keys**: Prefix-hashed API key pairs (`aios_sk_...`) with scope enforcement.
- **Service Accounts**: Client ID & Client Secret authentication for background automation.
- **Federation Abstractions**: Extensible adapters for OAuth2 and OpenID Connect.

### 3.2 AuthorizationEngine & RBAC/ABAC
- **RBAC**: Role hierarchy evaluation (`role-admin`, `role-org-admin`, `role-member`) with wildcards (`*`, `workspace:*`, `workspace:read`).
- **ABAC**: Attribute-based contextual decision rules (e.g. user status, access window).
- **Multi-Tenant Isolation**: Enforces tenant boundary checks (`user.tenant_id == target_tenant_id`).

### 3.3 IdentityService & Runtime Integration
- Emits runtime events (`identity.login`, `user.created`, `role.created`, `organization.created`, `workspace.created`) to `EventBus`.
- Forwards immutable audit records (`USER_AUTHENTICATED`, `USER_ACCOUNT_CREATED`) to Enterprise Governance `AuditManager`.

---

## 4. API Endpoints

- `POST /api/v1/auth/login`: User login returning JWT access & refresh tokens.
- `POST /api/v1/auth/register`: Register new user account.
- `GET /api/v1/identity/users`: List registered users.
- `POST /api/v1/identity/users`: Provision new user.
- `GET /api/v1/identity/organizations`: List organizations.
- `POST /api/v1/identity/organizations`: Provision organization.
- `GET /api/v1/identity/workspaces`: List workspace environments.
- `POST /api/v1/identity/workspaces`: Provision workspace.
- `GET /api/v1/identity/roles`: List RBAC role catalog.
- `POST /api/v1/identity/roles`: Create new RBAC role.
- `GET /api/v1/identity/permissions`: List permissions catalog.
- `POST /api/v1/identity/api-keys`: Issue API key.
- `GET /api/v1/identity/service-accounts`: List service accounts.
- `GET /api/v1/identity/statistics`: Aggregate identity statistics.
