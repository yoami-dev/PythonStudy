# AIOS Agent Playground & Interactive Testing - Guide

**Document Status:** Production Baseline  
**Version:** 3.1.0 (Phase P3.1)  
**Scope:** Interactive chat preview, tool execution preview, token usage tracking, latency inspection, and cost preview.

---

## 1. Playground Features
- **Chat Preview**: Interactive conversation testing prior to staging deployment.
- **Tool Execution Preview**: Real-time inspection of tools executed by the agent.
- **Token & Cost Inspection**: Precise tracking of prompt tokens, completion tokens, latency, and estimated cost per invocation.

---

## 2. Playground Session API
```python
session = agent_intelligence_service_instance.run_playground_session("agt-rag-assistant-01", "Summarize quarterly report.")
```
