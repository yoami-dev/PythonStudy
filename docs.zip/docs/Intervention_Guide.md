# AIOS Live Execution Intervention - Guide

**Document Status:** Production Baseline  
**Version:** 3.2.0 (Phase P3.2)  
**Scope:** Operator live intervention actions (`PAUSE`, `RESUME`, `REJECT`, `OVERRIDE_RESPONSE`, `OVERRIDE_TOOL`, `INJECT_CONTEXT`, `RESTART`, `CANCEL`).

---

## 1. Supported Intervention Actions
- `PAUSE`: Immediately freezes agent execution state.
- `RESUME`: Unfreezes paused agent execution.
- `REJECT`: Terminates execution with rejection status.
- `OVERRIDE_RESPONSE`: Replaces agent response with human operator input.
- `OVERRIDE_TOOL`: Modifies arguments passed to downstream tool calls.
- `INJECT_CONTEXT`: Injects context or instruction into active agent memory.
- `RESTART`: Re-runs agent task execution from initial state.
- `CANCEL`: Cancels task execution permanently.

---

## 2. Live Intervention API
```python
rec = human_loop_service_instance.create_intervention(
    agent_id="agt-rag-assistant-01",
    operator_id="usr-op-001",
    action="PAUSE",
    payload={"reason": "Operator requested pause for safety audit."}
)
```
