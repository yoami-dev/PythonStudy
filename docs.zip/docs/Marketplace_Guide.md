# AIOS Marketplace, Extension Platform & Developer SDK - Architecture Guide

**Document Status:** Production Baseline  
**Version:** 5.0.0 (Phase P5)  
**Scope:** Extensibility & Ecosystem layer, Package Manifest validation, Dependency resolution, Digital Signatures, Certification review workflows, Developer SDKs, AIOS CLI, Package Installation/Upgrade/Rollback/Uninstall, and Operational Analytics across AIOS.

---

## 1. Executive Summary
**Phase P5 (Marketplace & Extension Platform)** establishes the extensibility and ecosystem layer of AIOS. It enables organizations, partners, and developers to package, publish, discover, install, upgrade, govern, certify, digitally sign, and monetize AIOS extensions including Agents, Workflows, Connectors, Skills, Templates, and Plugins. It consumes existing platform capabilities (Workflow Studio P4, Multi-Agent Collaboration P3.3, HITL P3.2, Agent Intelligence P3.1, Agent Studio P3, Platform Kernel P2.1, Foundation P2, Directory P1.1, Identity P1, and Runtime 0.5-12) without duplicating runtime execution logic.

---

## 2. System Architecture

```
                               ┌────────────────────────────────────────────────┐
                               │        REST API Gateway (/api/v1/*)           │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │               MarketplaceService               │
                               └───────────────────────┬────────────────────────┘
                                                       │
         ┌───────────────────────┬─────────────────────┼───────────────────────┬──────────────────────┐
         ▼                       ▼                     ▼                       ▼                      ▼
┌─────────────────┐     ┌─────────────────┐   ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
│ PackageRegistry │     │ PackageInstaller│   │ Certification & │     │ SDKManager &    │    │ Analytics &     │
│ & Manifest Val  │     │ & DependencyRes │   │ Digital Sign    │     │ AIOS CLI        │    │ Package Metrics │
└─────────────────┘     └─────────────────┘   └─────────────────┘     └─────────────────┘    └─────────────────┘
```

---

## 3. Subsystem Overview
- **PackageRegistry & PackageManager**: Indexes extension packages by category (`Agent`, `Agent Team`, `Workflow`, `Connector`, `Skill`, `Template`, `Plugin`) and validates strict JSON manifest specifications.
- **PackageInstaller & DependencyResolver**: Resolves package dependency trees, enforces min AIOS version requirements, and manages installation, upgrade, rollback, and uninstallation.
- **CertificationManager & SignatureManager**: Manages certification review pipelines (`Draft`, `Submitted`, `Security Review`, `Compliance Review`, `Certified`, `Published`, `Deprecated`, `Archived`) and verifies asymmetric RSA/ECDSA digital signatures.
- **SDKManager & CLIManager**: Scaffolds local developer SDK projects and dispatches `aios` CLI commands (`init`, `build`, `package`, `validate`, `publish`, `install`, `upgrade`, `uninstall`, `login`, `search`).
- **MarketplaceAnalyticsManager**: Captures download counts, rating scores, installation telemetry, and marketplace statistics.
