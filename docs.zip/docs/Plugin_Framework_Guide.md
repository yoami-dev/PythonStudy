# AIOS Plugin Framework & Lifecycle - Management Guide

**Document Status:** Production Baseline  
**Version:** 2.1.0 (Phase P2.1)  
**Scope:** Dynamic plugin registration, discovery, loading, permissions, dependency resolution, and health tracking.

---

## 1. Supported Plugin Types
- `marketplace`: Package marketplace extension plugins.
- `workflow`: DAG workflow execution engines.
- `knowledge_graph`: Graph query and reasoning engines.
- `search`: Hybrid retrieval plugins.
- `agent`: AI Agent Studio execution engines.

---

## 2. Plugin Registration API
```python
plugin = platform_kernel_instance.register_plugin(
    name="AgentStudioPlugin",
    plugin_type="agent",
    version="1.0.0",
    permissions=["agent.deploy"]
)
```
