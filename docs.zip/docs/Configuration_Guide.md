# AIOS Configuration & Feature Flags - Management Guide

**Document Status:** Production Baseline  
**Version:** 2.0.0 (Phase P2)  
**Scope:** Environment profiles, dynamic configuration reloads, versioned runtime settings, and feature flags.

---

## 1. Environment Profiles
- **`local`**: Local development environment.
- **`docker`**: Containerized local deployment environment.
- **`kubernetes`**: Production Kubernetes cluster environment.

---

## 2. Active Feature Flags
- `enable_multi_agent`: Enables Multi-Agent Collaboration Engine.
- `enable_workflow_automation`: Enables DAG Workflow Automation.
- `enable_marketplace`: Enables Extension Package Marketplace.
- `enable_rate_limiting`: Enforces API rate limiting.
- `enable_cost_governance`: Enables Phase 12 cost governance.
