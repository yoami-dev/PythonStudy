# AIOS Agent Design & Capability Composition - Guide

**Document Status:** Production Baseline  
**Version:** 3.0.0 (Phase P3)  
**Scope:** LLM selection, prompt engineering, memory profiles, vector knowledge sources, tool integrations, and safety policies.

---

## 1. Agent Profile Composition
An Agent Profile consists of six core building blocks:
1. **LLM Model**: Selection of model provider (`gpt-4o`, `claude-3-5-sonnet`, `bge`).
2. **Prompt Profile**: System prompt, user template, temperature, and max token bounds.
3. **Memory Profile**: Memory buffer type (`buffer`, `summary`, `vector`, `redis`), history depth, and TTL.
4. **Knowledge Profile**: Vector namespaces and top-k retrieval bounds.
5. **Tool Profile**: Allowed tools (`web_search`, `document_parser`) and connectors (`sharepoint`, `github`).
6. **Execution Policy**: Execution mode (`HUMAN_APPROVAL`, `AUTONOMOUS`, `READ_ONLY`, `RESTRICTED`, `SANDBOX`), cost limits, and timeouts.
