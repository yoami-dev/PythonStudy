# AIOS Service Registry & Dependency Injection - Guide

**Document Status:** Production Baseline  
**Version:** 2.1.0 (Phase P2.1)  
**Scope:** Service registration, discovery, versioning, metadata, health status, and dependency injection container lifetimes.

---

## 1. Service Registration & Discovery
All platform services register with `ServiceRegistry`:

```python
from app.control_plane.platform_kernel import platform_kernel_instance

svc = platform_kernel_instance.register_service(
    name="WorkflowStudioService",
    version="1.0.0",
    dependencies=["PipelineRuntimeEngine"]
)
```

---

## 2. Dependency Injection Container Lifetimes
- **Singleton**: Single shared instance across platform lifetime.
- **Transient**: New instance created upon every resolution request.
- **Scoped**: Single instance per request context.
- **Factory**: Resolved dynamically via custom factory function.
