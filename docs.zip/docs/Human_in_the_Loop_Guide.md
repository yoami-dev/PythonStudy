# AIOS Human-in-the-Loop (HITL) Platform - Architecture Guide

**Document Status:** Production Baseline  
**Version:** 3.2.0 (Phase P3.2)  
**Scope:** Reusable Human-in-the-Loop Platform, approval workflows, human task orchestration, live operator intervention, time/role escalations, SLA tracking, decision auditing, and feedback collection across AIOS products.

---

## 1. Executive Summary
The **Human-in-the-Loop (HITL) Platform** provides a reusable enterprise capability across all AIOS applications (Agent Studio, Multi-Agent Collaboration, Workflow Studio, Marketplace, Customer Portals, and Department AI Employees). It establishes human-first governance, policy-driven approval workflows, live operator intervention, time-based and role-based task escalations, SLA tracking, multi-channel notification dispatch, and immutable decision audit trails without redesigning underlying platform services.

---

## 2. System Architecture

```
                               ┌────────────────────────────────────────────────┐
                               │        REST API Gateway (/api/v1/*)           │
                               └───────────────────────┬────────────────────────┘
                                                       │
                                                       ▼
                               ┌────────────────────────────────────────────────┐
                               │              HumanLoopService                  │
                               └───────────────────────┬────────────────────────┘
                                                       │
         ┌───────────────────────┬─────────────────────┼───────────────────────┬──────────────────────┐
         ▼                       ▼                     ▼                       ▼                      ▼
┌─────────────────┐     ┌─────────────────┐   ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
│ HumanTaskManager│     │ ApprovalEngine  │   │ Intervention    │     │ Escalation &    │    │ DecisionAudit   │
│ (Task Inbox)    │     │ & Policy Mgr    │   │ Manager         │     │ SLA Service     │    │ & Feedback      │
└─────────────────┘     └─────────────────┘   └─────────────────┘     └─────────────────┘    └─────────────────┘
```

---

## 3. Subsystem Overview
- **HumanTaskManager**: Manages Personal and Team Inboxes, priority queues (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`), due dates, and task delegations.
- **ApprovalEngine & ApprovalPolicyManager**: Executes multi-pattern approval workflows (`SINGLE`, `MULTI`, `SEQUENTIAL`, `PARALLEL`, `CONSENSUS`, `MAJORITY`, `CONDITIONAL`, `EMERGENCY`).
- **InterventionManager & PauseResumeManager**: Provides live operator execution controls (`PAUSE`, `RESUME`, `REJECT`, `OVERRIDE_RESPONSE`, `OVERRIDE_TOOL`, `INJECT_CONTEXT`, `RESTART`, `CANCEL`).
- **EscalationManager & SLAService**: Manages time-based and role-based task escalations, SLA compliance monitoring, and breach notifications.
- **DecisionHistoryManager & NotificationCoordinator**: Captures immutable decision logs and dispatches notifications across email, SMS, Teams, Slack, web, and mobile push via Platform Kernel.
