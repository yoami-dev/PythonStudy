from pathlib import Path
from sqlalchemy import create_engine, text

db_path = Path(r"D:\Milind\MyTradingPlatform\smm_trading.db")

engine = create_engine(f"sqlite:///{db_path}")

query = text("""
    SELECT DISTINCT timeframe
    FROM market_candles
    ORDER BY timeframe
""")

with engine.connect() as conn:
    rows = conn.execute(query).fetchall()

print("Timeframes:")
for row in rows:
    print(row[0])