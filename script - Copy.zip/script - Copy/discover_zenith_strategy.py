"""
ZENITH Strategy Discovery & Multi-Instrument Backtester (R:R >= 1:2.0).

Evaluates the Zenith Institutional Breakout & Trend Continuation Engine across all Nifty 50 instruments.
Features:
- Configurable Risk:Reward ratio (Default: 1:2.0)
- Candle-by-candle evaluation from start date
- Exact 1-minute forward resolution tracking Target & Stop Loss hit timestamps in IST
- Interactive HTML report with filters and strategy manual
"""

import sys
import os
import argparse
import sqlite3
import shutil
import math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ProcessPoolExecutor, as_completed

# Configure UTF-8 encoding for Windows terminals
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.market_data.resampler.resampler import CandleResampler
from app.strategies.contracts import StrategyInputContext, StrategyResultStatus
from app.strategies.impl.zenith_strategy import ZenithStrategyEngine
from app.strategies.adapters.zenith_adapter import ZenithStrategyAdapter

IST_TZ = timezone(timedelta(hours=5, minutes=30))
DEFAULT_DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "script", "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)


def parse_db_timestamp(ts: Any) -> datetime:
    if isinstance(ts, datetime):
        if ts.tzinfo is None:
            return ts.replace(tzinfo=timezone.utc)
        return ts
    ts_str = str(ts).replace("Z", "+00:00")
    if "+" not in ts_str and "-" not in ts_str[10:]:
        ts_str += "+00:00"
    try:
        return datetime.fromisoformat(ts_str)
    except Exception:
        return datetime.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)


def format_to_ist(ts_raw: Any) -> Tuple[str, str]:
    if not ts_raw:
        return "-", "-"
    try:
        dt = parse_db_timestamp(ts_raw).astimezone(IST_TZ)
        return dt.strftime("%Y-%m-%d"), dt.strftime("%H:%M:%S IST")
    except Exception:
        return str(ts_raw)[:10], str(ts_raw)[11:19] + " IST"


def get_db_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def get_all_active_symbols(db_path: str) -> List[str]:
    conn = get_db_connection(db_path)
    c = conn.cursor()
    c.execute("SELECT symbol FROM instruments WHERE active = 1 ORDER BY symbol ASC")
    rows = c.fetchall()
    conn.close()
    return [r["symbol"].replace("NSE:", "").replace("-EQ", "") for r in rows]


def find_instrument(conn: sqlite3.Connection, symbol: str) -> Optional[Dict[str, Any]]:
    c = conn.cursor()
    sym_clean = symbol.upper().replace("NSE:", "").replace("-EQ", "").strip()
    c.execute(
        "SELECT id, symbol, display_name FROM instruments WHERE symbol LIKE ? OR display_name LIKE ? LIMIT 1",
        (f"%{sym_clean}%", f"%{sym_clean}%")
    )
    row = c.fetchone()
    return dict(row) if row else None


def normalize_timeframe_code(tf: str) -> str:
    t = tf.lower().strip()
    if t in ("1m", "5m", "15m", "30m", "1h", "4h", "1d"):
        return tf
    if t == "minute" or t == "1":
        return "1m"
    if t == "5" or t == "5min":
        return "5m"
    if t == "15" or t == "15min":
        return "15m"
    if t == "30" or t == "30min":
        return "30m"
    if t == "60" or t == "60min" or t == "hour":
        return "1h"
    if t == "day" or t == "daily":
        return "1D"
    return tf


def forward_resolve_trade(
    raw_1m_candles: List[Dict[str, Any]],
    entry_ts_utc: datetime,
    direction: str,
    entry_price: float,
    sl_price: float,
    tp_price: float,
    max_resolution_bars: int = 400
) -> Tuple[str, Optional[str], int]:
    import bisect
    raw_ts = [parse_db_timestamp(r["candle_timestamp"]) for r in raw_1m_candles]
    idx = bisect.bisect_right(raw_ts, entry_ts_utc)

    limit = min(len(raw_1m_candles), idx + max_resolution_bars)
    for i in range(idx, limit):
        c = raw_1m_candles[i]
        c_low = float(c["low"])
        c_high = float(c["high"])
        c_ts = c["candle_timestamp"]

        if direction == "LONG":
            if c_low <= sl_price:
                return "SL_HIT", c_ts, (i - idx)
            if c_high >= tp_price:
                return "TARGET_HIT", c_ts, (i - idx)
        elif direction == "SHORT":
            if c_high >= sl_price:
                return "SL_HIT", c_ts, (i - idx)
            if c_low <= tp_price:
                return "TARGET_HIT", c_ts, (i - idx)

    return "UNRESOLVED", None, (limit - idx)


def evaluate_symbol_zenith(
    symbol: str,
    timeframe: str,
    start_date: str,
    start_time: str,
    end_date: Optional[str],
    db_path: str,
    rr_ratio: float = 2.0,
    sl_atr_mult: float = 1.0,
    cached_1m_candles: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]:
    tf_clean = normalize_timeframe_code(timeframe)
    engine = ZenithStrategyEngine(
        risk_reward_ratio=rr_ratio,
        sl_atr_mult=sl_atr_mult,
        volume_multiplier=1.25,
        min_adx=20.0
    )
    adapter = ZenithStrategyAdapter(engine=engine)

    if cached_1m_candles is not None and len(cached_1m_candles) > 0:
        all_1m_rows = cached_1m_candles
        inst_key = f"NSE:{symbol.upper()}-EQ"
    else:
        conn = get_db_connection(db_path)
        inst_info = find_instrument(conn, symbol)
        if not inst_info:
            conn.close()
            return {"symbol": symbol, "total_trades": 0, "target_hits": 0, "sl_hits": 0, "unresolved": 0, "trades": [], "win_rate": 0.0}
        inst_id = inst_info["id"]
        inst_key = inst_info["symbol"]

        c = conn.cursor()
        c.execute(
            """
            SELECT candle_timestamp, open, high, low, close, volume
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = '1m'
            ORDER BY candle_timestamp ASC
            """,
            (inst_id,)
        )
        all_1m_rows = [dict(r) for r in c.fetchall()]
        conn.close()

    if not all_1m_rows:
        return {"symbol": symbol, "total_trades": 0, "target_hits": 0, "sl_hits": 0, "unresolved": 0, "trades": [], "win_rate": 0.0}

    resampled_exec = CandleResampler.resample_1m_candles(all_1m_rows, tf_clean)

    eff_start_date = start_date.strip() if start_date else "2026-09-01"
    eff_start_time = start_time.strip() if start_time else "09:30:00"
    if len(eff_start_time.split(":")) == 2:
        eff_start_time += ":00"
    eval_start_dt = datetime.fromisoformat(f"{eff_start_date}T{eff_start_time}+05:30").astimezone(timezone.utc)

    eval_end_dt = None
    if end_date and str(end_date).strip():
        eval_end_dt = datetime.fromisoformat(f"{str(end_date).strip()}T15:30:00+05:30").astimezone(timezone.utc)

    raw_1m_ts = [parse_db_timestamp(r["candle_timestamp"]) for r in all_1m_rows]
    import bisect

    trades = []
    cooldown_until_idx = -1

    for idx in range(30, len(resampled_exec)):
        cand = resampled_exec[idx]
        ts = parse_db_timestamp(cand["candle_timestamp"])

        if ts < eval_start_dt:
            continue
        if eval_end_dt and ts > eval_end_dt:
            break
        if idx < cooldown_until_idx:
            continue

        slice_start = max(0, idx - 400)
        ctx_candles = resampled_exec[slice_start : idx + 1]

        context = StrategyInputContext(
            instrument=inst_key,
            symbol=symbol,
            current_price=float(cand["close"]),
            candles=ctx_candles,
            timeframe=tf_clean,
            parameters={},
        )

        res = adapter.evaluate(context)

        if res.status == StrategyResultStatus.VALID and res.entry_price and res.stop_loss_price and res.target_price:
            entry_p = res.entry_price
            sl_p = res.stop_loss_price
            target_p = res.target_price
            direction = res.direction

            pos_1m = bisect.bisect_right(raw_1m_ts, ts)
            future_slice = all_1m_rows[pos_1m : pos_1m + 600]

            outcome = "UNRESOLVED"
            exit_price = None
            exit_ts = None
            bars_held = 0

            for fut_c in future_slice:
                bars_held += 1
                f_h = float(fut_c["high"])
                f_l = float(fut_c["low"])
                f_ts = fut_c["candle_timestamp"]

                if direction == "LONG":
                    if f_h >= target_p:
                        outcome = "TARGET_HIT"
                        exit_price = target_p
                        exit_ts = f_ts
                        break
                    elif f_l <= sl_p:
                        outcome = "SL_HIT"
                        exit_price = sl_p
                        exit_ts = f_ts
                        break
                elif direction == "SHORT":
                    if f_l <= target_p:
                        outcome = "TARGET_HIT"
                        exit_price = target_p
                        exit_ts = f_ts
                        break
                    elif f_h >= sl_p:
                        outcome = "SL_HIT"
                        exit_price = sl_p
                        exit_ts = f_ts
                        break

            entry_date_ist, entry_time_ist = format_to_ist(cand["candle_timestamp"])
            exit_date_ist, exit_time_ist = format_to_ist(exit_ts)

            risk_val = abs(entry_p - sl_p)
            reward_val = abs(target_p - entry_p)
            rr_computed = (reward_val / risk_val) if risk_val > 0 else rr_ratio

            trade_record = {
                "symbol": symbol,
                "direction": direction,
                "setup": res.evidence.get("setup", "ZENITH_BREAKOUT"),
                "entry_price": entry_p,
                "stop_loss_price": sl_p,
                "target_price": target_p,
                "risk_reward": rr_computed,
                "outcome": outcome,
                "candle_timestamp": cand["candle_timestamp"],
                "entry_date_ist": entry_date_ist,
                "entry_time_ist": entry_time_ist,
                "exit_timestamp": exit_ts,
                "exit_date_ist": exit_date_ist,
                "exit_time_ist": exit_time_ist,
                "bars_held": bars_held,
                "atr": res.evidence.get("atr", 0.0),
                "vwap": res.evidence.get("vwap", 0.0),
                "rsi": res.evidence.get("rsi", 0.0),
                "adx": res.evidence.get("adx", 0.0),
                "rvol": res.evidence.get("rvol", 0.0),
            }
            trades.append(trade_record)
            cooldown_until_idx = idx + 3

    resolved = [t for t in trades if t["outcome"] in ("TARGET_HIT", "SL_HIT")]
    t_hits = sum(1 for t in resolved if t["outcome"] == "TARGET_HIT")
    sl_hits = sum(1 for t in resolved if t["outcome"] == "SL_HIT")
    unresolved = sum(1 for t in trades if t["outcome"] == "UNRESOLVED")
    wr = (t_hits / len(resolved) * 100.0) if resolved else 0.0

    return {
        "symbol": symbol,
        "total_trades": len(trades),
        "target_hits": t_hits,
        "sl_hits": sl_hits,
        "unresolved": unresolved,
        "trades": trades,
        "win_rate": wr
    }


def generate_zenith_html_report(
    summary_data: Dict[str, Any],
    all_trades: List[Dict[str, Any]],
    symbol_results: List[Dict[str, Any]],
    eval_timeframe: str,
    period_start: str,
    rr_target: float,
    output_path: str
):
    total_trades = summary_data["total_trades"]
    target_hits = summary_data["target_hits"]
    sl_hits = summary_data["sl_hits"]
    unresolved = summary_data["unresolved"]
    win_rate = summary_data["win_rate"]
    net_r = summary_data["net_r"]
    profit_factor = summary_data["profit_factor"]
    expectancy = summary_data["expectancy"]

    perf_badge_color = "#06b6d4" if win_rate >= 50.0 else "#8b5cf6"
    perf_badge_text = f"ZENITH HIGH R:R MODEL (1:{rr_target:.1f})"

    symbol_rows_html = ""
    for sr in sorted(symbol_results, key=lambda x: (x["win_rate"], x["total_trades"]), reverse=True):
        wr = sr["win_rate"]
        wr_badge_class = "badge-target" if wr >= 50.0 else ("badge-warning" if wr >= 35.0 else "badge-sl")
        status_text = f"EXCELLENT (1:{rr_target:.1f})" if wr >= 50.0 else (f"PROFITABLE (1:{rr_target:.1f})" if wr >= 35.0 else "ACTIVE")
        symbol_rows_html += f"""
        <tr>
          <td><b>{sr['symbol']}</b></td>
          <td>{sr['total_trades']}</td>
          <td class="c-green"><b>{sr['target_hits']}</b></td>
          <td class="c-red"><b>{sr['sl_hits']}</b></td>
          <td>{sr['unresolved']}</td>
          <td><span class='badge {wr_badge_class}'>{wr:.1f}%</span></td>
          <td><b>{status_text}</b></td>
        </tr>
        """

    trade_rows_html = ""
    for t in all_trades:
        outcome = t["outcome"]
        badge_class = "badge-target" if outcome == "TARGET_HIT" else ("badge-sl" if outcome == "SL_HIT" else "badge-neutral")
        dir_class = "badge-long" if t["direction"] == "LONG" else "badge-short"

        entry_date_str = t["entry_date_ist"]
        entry_time_str = t["entry_time_ist"]
        exit_date_str = t["exit_date_ist"]
        exit_time_str = t["exit_time_ist"]

        if outcome == "TARGET_HIT":
            target_hit_html = f"<span class='c-green' style='font-family: \"JetBrains Mono\", monospace; font-size: 11.5px;'><b>{exit_date_str}</b> {exit_time_str}</span>"
            sl_hit_html = "<span style='color: #475569;'>-</span>"
        elif outcome == "SL_HIT":
            target_hit_html = "<span style='color: #475569;'>-</span>"
            sl_hit_html = f"<span class='c-red' style='font-family: \"JetBrains Mono\", monospace; font-size: 11.5px;'><b>{exit_date_str}</b> {exit_time_str}</span>"
        else:
            target_hit_html = "<span style='color: #94a3b8; font-style: italic;'>Active</span>"
            sl_hit_html = "<span style='color: #94a3b8; font-style: italic;'>Active</span>"

        trade_rows_html += f"""
        <tr data-outcome="{outcome}">
          <td style="font-family: 'JetBrains Mono', monospace; font-weight: 600; color: #93c5fd;">{entry_date_str}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: #cbd5e1;">{entry_time_str}</td>
          <td><b>{t['symbol']}</b></td>
          <td><span class="badge {dir_class}">{t['direction']}</span></td>
          <td style="font-size: 11px;">{t['setup'].replace('_', ' ')}</td>
          <td style="font-family: 'JetBrains Mono', monospace;">Rs.{t['entry_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: var(--accent-red); font-weight: 600;">Rs.{t['stop_loss_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: var(--accent-green); font-weight: 600;">Rs.{t['target_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #c084fc;">1:{t['risk_reward']:.2f}</td>
          <td><span class="badge {badge_class}">{outcome}</span></td>
          <td>{target_hit_html}</td>
          <td>{sl_hit_html}</td>
          <td style="text-align: center; font-family: 'JetBrains Mono', monospace;">{t.get('bars_held', 0)}</td>
        </tr>
        """

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ZENITH High Risk-Reward Strategy Discovery (R:R >= 1:2.0)</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    :root {{
      --bg-dark: #07090e;
      --card-bg: #0f131c;
      --card-border: #1e2638;
      --accent-cyan: #06b6d4;
      --accent-purple: #8b5cf6;
      --accent-green: #10b981;
      --accent-red: #ef4444;
      --accent-yellow: #f59e0b;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
    }}

    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: 'Outfit', sans-serif;
      background: var(--bg-dark);
      color: var(--text-main);
      padding: 32px 24px;
      line-height: 1.5;
    }}

    .container {{ max-width: 1440px; margin: 0 auto; }}

    .header-card {{
      background: linear-gradient(135deg, rgba(6, 182, 212, 0.15) 0%, rgba(139, 92, 246, 0.1) 100%);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 28px 32px;
      margin-bottom: 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
    }}

    .header-title h1 {{
      font-size: 28px;
      font-weight: 800;
      background: linear-gradient(90deg, #38bdf8, #818cf8, #c084fc);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 6px;
    }}
    .header-title p {{ color: var(--text-muted); font-size: 14px; }}

    .badge-grade {{
      background: {perf_badge_color}22;
      color: {perf_badge_color};
      border: 1px solid {perf_badge_color}66;
      padding: 8px 16px;
      border-radius: 9999px;
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 0.5px;
    }}

    .stats-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }}

    .stat-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 20px 16px;
      text-align: center;
    }}
    .stat-card .lbl {{
      font-size: 11.5px;
      font-weight: 600;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.8px;
      margin-bottom: 6px;
    }}
    .stat-card .val {{
      font-size: 24px;
      font-weight: 800;
      font-family: 'JetBrains Mono', monospace;
    }}
    .c-green {{ color: var(--accent-green); }}
    .c-red {{ color: var(--accent-red); }}
    .c-cyan {{ color: var(--accent-cyan); }}
    .c-purple {{ color: var(--accent-purple); }}

    .section-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 24px;
      margin-bottom: 24px;
    }}

    .section-title {{
      font-size: 18px;
      font-weight: 700;
      color: #fff;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      gap: 10px;
    }}

    .indicator-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 16px;
      margin-bottom: 20px;
    }}

    .indicator-card {{
      background: #090d16;
      border: 1px solid #1e2638;
      border-radius: 10px;
      padding: 16px;
    }}
    .indicator-card h4 {{
      font-size: 14px;
      font-weight: 700;
      color: var(--accent-cyan);
      margin-bottom: 6px;
    }}
    .indicator-card .formula {{
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      background: #04060a;
      padding: 4px 8px;
      border-radius: 4px;
      color: #93c5fd;
      margin: 6px 0;
      display: inline-block;
    }}
    .indicator-card p {{
      font-size: 12.5px;
      color: #94a3b8;
      line-height: 1.4;
    }}

    .rule-box {{
      background: #090d16;
      border-left: 4px solid var(--accent-cyan);
      padding: 16px;
      border-radius: 0 8px 8px 0;
      margin-bottom: 14px;
    }}
    .rule-box h4 {{ color: #38bdf8; margin-bottom: 6px; font-size: 14px; }}
    .rule-box p {{ font-size: 13px; color: #cbd5e1; margin-bottom: 4px; }}

    table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 12.5px;
    }}
    th, td {{
      padding: 10px 12px;
      text-align: left;
      border-bottom: 1px solid #1e2638;
    }}
    th {{
      background: #141b2d;
      color: #94a3b8;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.5px;
      position: sticky;
      top: 0;
    }}
    tr:hover {{ background: rgba(255, 255, 255, 0.03); }}

    .badge {{
      display: inline-block;
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      font-family: 'JetBrains Mono', monospace;
    }}
    .badge-target {{ background: rgba(16, 185, 129, 0.2); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.4); }}
    .badge-sl {{ background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.4); }}
    .badge-warning {{ background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4); }}
    .badge-neutral {{ background: rgba(148, 163, 184, 0.2); color: #94a3b8; }}
    .badge-long {{ background: rgba(59, 130, 246, 0.2); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.4); }}
    .badge-short {{ background: rgba(236, 72, 153, 0.2); color: #f472b6; border: 1px solid rgba(236, 72, 153, 0.4); }}

    .search-bar-container {{
      display: flex;
      gap: 12px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }}
    .search-input {{
      flex: 1;
      min-width: 250px;
      background: #090d16;
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 10px 14px;
      color: #fff;
      font-family: 'Outfit', sans-serif;
      font-size: 13px;
    }}
    .search-input:focus {{ outline: 1px solid var(--accent-cyan); border-color: var(--accent-cyan); }}

    .btn-filter {{
      background: #1e2638;
      border: 1px solid #334155;
      color: #cbd5e1;
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
    }}
    .btn-filter.active, .btn-filter:hover {{
      background: var(--accent-cyan);
      color: #07090e;
      border-color: var(--accent-cyan);
    }}
  </style>
</head>
<body>

<div class="container">
  
  <div class="header-card">
    <div class="header-title">
      <h1>⚡ ZENITH High Risk-Reward Strategy Discovery Report</h1>
      <p>Institutional Asymmetric Momentum Model (R:R &ge; 1:{rr_target:.1f}) | Timeframe: <b>{eval_timeframe}</b> | Period: <b>{period_start} to Present</b></p>
    </div>
    <div>
      <span class="badge-grade">{perf_badge_text}</span>
    </div>
  </div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="lbl">Total Trades</div>
      <div class="val">{total_trades}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Target Hits (Wins)</div>
      <div class="val c-green">{target_hits}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Stop Loss Hits</div>
      <div class="val c-red">{sl_hits}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Win Rate %</div>
      <div class="val c-cyan">{win_rate:.2f}%</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Target R:R Ratio</div>
      <div class="val c-purple">1:{rr_target:.2f}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Net R-Multiple</div>
      <div class="val c-cyan">{net_r:+.2f}R</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Profit Factor</div>
      <div class="val c-purple">{profit_factor:.2f}</div>
    </div>
  </div>

  <!-- Detailed Strategy & Risk:Reward Analysis Section -->
  <div class="section-card">
    <div class="section-title">⚖️ ZENITH Strategy Mechanics & Risk:Reward Architecture</div>
    <div class="rule-box" style="border-left-color: #10b981;">
      <h4>1. High Risk:Reward Geometry (1:{rr_target:.2f} Structure)</h4>
      <p>• <b>Target Sizing:</b> Fixed at <b>+{rr_target:.2f} &times; Risk</b> (<code>Entry &plusmn; ({rr_target:.2f} &times; ATR_14)</code>). Captures asymmetric continuation waves.</p>
      <p>• <b>Stop Loss Sizing:</b> Fixed at <b>1.00 &times; ATR(14)</b> from the entry price (below breakout base / pivot).</p>
      <p>• <b>Mathematical Expectancy:</b> With a 1:{rr_target:.1f} R:R, a strategy only requires a <b>&gt; 33.4% Win Rate</b> to achieve long-term institutional profitability. Each win delivers +{rr_target:.1f}R against -1.0R loss.</p>
    </div>

    <div class="rule-box">
      <h4>2. Long Setup Execution Rules (Bullish Breakout & Trend Continuation)</h4>
      <p>• <b>Entry Condition:</b> Triggered at candle close when <b>EMA 9 > EMA 21 > EMA 50</b> AND <b>Price > Session VWAP</b> AND <b>Price > Prior Candle High</b>.</p>
      <p>• <b>Trend Strength (ADX):</b> ADX(14) &ge; 20 with +DI > -DI.</p>
      <p>• <b>Volume Absorption Filter:</b> Current candle volume &ge; 1.25x of 20-period volume average (RVOL &ge; 1.25x).</p>
      <p>• <b>Entry Price:</b> Current candle close.</p>
      <p>• <b>Target Price:</b> <code>Entry Price + ({rr_target:.2f} × ATR_14)</code></p>
      <p>• <b>Stop Loss Price:</b> <code>Entry Price - (1.00 × ATR_14)</code></p>
    </div>

    <div class="rule-box" style="border-left-color: var(--accent-red);">
      <h4>3. Short Setup Execution Rules (Bearish Breakdown & Trend Continuation)</h4>
      <p>• <b>Entry Condition:</b> Triggered at candle close when <b>EMA 9 < EMA 21 < EMA 50</b> AND <b>Price < Session VWAP</b> AND <b>Price < Prior Candle Low</b>.</p>
      <p>• <b>Trend Strength (ADX):</b> ADX(14) &ge; 20 with -DI > +DI.</p>
      <p>• <b>Volume Absorption Filter:</b> Current candle volume &ge; 1.25x of 20-period volume average (RVOL &ge; 1.25x).</p>
      <p>• <b>Entry Price:</b> Current candle close.</p>
      <p>• <b>Target Price:</b> <code>Entry Price - ({rr_target:.2f} × ATR_14)</code></p>
      <p>• <b>Stop Loss Price:</b> <code>Entry Price + (1.00 × ATR_14)</code></p>
    </div>
  </div>

  <!-- Technical Indicators Manual -->
  <div class="section-card">
    <div class="section-title">📐 Technical Indicators & Institutional Formulas</div>
    <div class="indicator-grid">
      <div class="indicator-card">
        <h4>1. Multi-EMA Momentum Stack (9, 21, 50)</h4>
        <div class="formula">EMA_9 > EMA_21 > EMA_50 (Bullish) • EMA_9 < EMA_21 < EMA_50 (Bearish)</div>
        <p>Establishes pure directional velocity and dynamic support. Trades are strictly taken in the direction of expanding EMA separation, avoiding chop.</p>
      </div>
      <div class="indicator-card">
        <h4>2. Intraday Session VWAP Benchmark</h4>
        <div class="formula">VWAP = Σ(TypicalPrice × Volume) / Σ(Volume)</div>
        <p>Volume-Weighted Average Price resets at 09:15 AM IST. Long trades are strictly filtered above VWAP; Short trades are strictly filtered below VWAP.</p>
      </div>
      <div class="indicator-card">
        <h4>3. Average Directional Index (ADX 14)</h4>
        <div class="formula">ADX(14) ≥ 20.0 • +DI vs -DI Directional Polarity</div>
        <p>Quantifies non-directional trend strength. Guarantees that trades are taken only when an aggressive directional trend is active.</p>
      </div>
      <div class="indicator-card">
        <h4>4. Dynamic Volatility Geometry (ATR 14)</h4>
        <div class="formula">Target = Entry ± {rr_target:.2f} ATR • SL = Entry ∓ 1.00 ATR</div>
        <p>Enforces asymmetric 1:{rr_target:.1f} Risk-to-Reward ratio, positioning stop losses beyond the base and targets at key expansion targets.</p>
      </div>
      <div class="indicator-card">
        <h4>5. Relative Volume (RVOL) Absorption</h4>
        <div class="formula">RVOL = Volume / SMA_20(Volume) ≥ 1.25x</div>
        <p>Guarantees institutional liquidity participation on the trigger candle, ensuring aggressive follow-through momentum.</p>
      </div>
    </div>
  </div>

  <!-- Universe Breakdown -->
  <div class="section-card">
    <div class="section-title">📊 Universe Performance Matrix ({len(symbol_results)} Instruments)</div>
    <table>
      <thead>
        <tr>
          <th>Symbol</th>
          <th>Total Trades</th>
          <th>Wins (Target)</th>
          <th>Losses (SL)</th>
          <th>Unresolved</th>
          <th>Win Rate %</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {symbol_rows_html}
      </tbody>
    </table>
  </div>

  <!-- Complete Discovered Trade Logs -->
  <div class="section-card">
    <div class="section-title">📋 Complete ZENITH Trade Logs with Detailed Date & Time ({len(all_trades)} Records)</div>
    
    <div class="search-bar-container">
      <input type="text" id="tradeSearch" class="search-input" placeholder="Search by Symbol (e.g. INFY, HCLTECH, SUNPHARMA), Direction, Setup..." onkeyup="filterTrades()">
      <button class="btn-filter active" onclick="setFilter('ALL', this)">All Trades</button>
      <button class="btn-filter" onclick="setFilter('TARGET_HIT', this)">Target Hits (Wins)</button>
      <button class="btn-filter" onclick="setFilter('SL_HIT', this)">SL Hits (Losses)</button>
      <button class="btn-filter" onclick="setFilter('UNRESOLVED', this)">Active / Unresolved</button>
    </div>

    <table id="tradesTable">
      <thead>
        <tr>
          <th>Entry Date</th>
          <th>Entry Time (IST)</th>
          <th>Symbol</th>
          <th>Direction</th>
          <th>Setup Engine</th>
          <th>Entry Price</th>
          <th>Stop Loss</th>
          <th>Target</th>
          <th>R:R</th>
          <th>Outcome</th>
          <th>Target Achieved (Date & Time IST)</th>
          <th>Stop Loss Hit (Date & Time IST)</th>
          <th>Bars Held</th>
        </tr>
      </thead>
      <tbody>
        {trade_rows_html}
      </tbody>
    </table>
  </div>

</div>

<script>
  let currentOutcomeFilter = 'ALL';

  function setFilter(outcome, btn) {{
    currentOutcomeFilter = outcome;
    document.querySelectorAll('.btn-filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    filterTrades();
  }}

  function filterTrades() {{
    const searchVal = document.getElementById('tradeSearch').value.toUpperCase();
    const rows = document.querySelectorAll('#tradesTable tbody tr');
    
    rows.forEach(row => {{
      const outcome = row.getAttribute('data-outcome');
      const text = row.innerText.toUpperCase();
      
      const matchesSearch = text.includes(searchVal);
      const matchesOutcome = (currentOutcomeFilter === 'ALL') || (outcome === currentOutcomeFilter);
      
      if (matchesSearch && matchesOutcome) {{
        row.style.display = '';
      }} else {{
        row.style.display = 'none';
      }}
    }});
  }}
</script>

</body>
</html>
"""
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)


def main():
    parser = argparse.ArgumentParser(description="ZENITH Strategy Discovery & Backtester (R:R >= 1:2.0)")
    parser.add_argument("--symbol", type=str, default="ALL", help="Symbol or ALL")
    parser.add_argument("--timeframe", type=str, default="5m", help="Execution timeframe (e.g. 5m, 15m)")
    parser.add_argument("--start-date", type=str, default="2026-09-01", help="Start date (YYYY-MM-DD)")
    parser.add_argument("--start-time", type=str, default="09:30:00", help="Start time (HH:MM:SS)")
    parser.add_argument("--end-date", type=str, default=None, help="End date (YYYY-MM-DD)")
    parser.add_argument("--rr-ratio", type=float, default=2.0, help="Target Risk:Reward ratio (e.g. 2.0)")
    parser.add_argument("--sl-atr-mult", type=float, default=1.0, help="Stop Loss ATR multiplier")
    parser.add_argument("--db-path", type=str, default=DEFAULT_DB_PATH, help="Path to SQLite DB")
    parser.add_argument("--workers", type=int, default=4, help="Parallel worker threads")
    parser.add_argument("--no-html", action="store_true", help="Skip HTML report generation")
    parser.add_argument("--open", action="store_true", help="Auto open HTML report in browser")

    args = parser.parse_args()

    print(f"\nInitializing ZENITH Strategy Discovery & Backtest (R:R >= 1:{args.rr_ratio:.1f})...")
    print(f"  Timeframe: {args.timeframe} | Start: {args.start_date} {args.start_time} | R:R: 1:{args.rr_ratio:.2f}")

    if args.symbol.upper() == "ALL":
        symbols = get_all_active_symbols(args.db_path)
    else:
        symbols = [s.strip().upper() for s in args.symbol.split(",") if s.strip()]

    print(f"  Symbols ({len(symbols)}): {', '.join(symbols[:8])}{'...' if len(symbols) > 8 else ''}")

    # Preload candles into memory
    print(f"\n  Preloading historical 1m candles for {len(symbols)} symbols into RAM...")
    conn = get_db_connection(args.db_path)
    cur = conn.cursor()
    cached_candles = {}
    for sym in symbols:
        inst = find_instrument(conn, sym)
        if not inst:
            continue
        cur.execute(
            """
            SELECT candle_timestamp, open, high, low, close, volume
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= '2026-08-20 00:00:00'
            ORDER BY candle_timestamp ASC
            """,
            (inst["id"],)
        )
        cached_candles[sym] = [dict(r) for r in cur.fetchall()]
    conn.close()
    print("  [OK] Preload complete. Commencing discovery backtest...\n")

    symbol_results = []
    all_trades = []

    for i, sym in enumerate(symbols, 1):
        c_1m = cached_candles.get(sym, [])
        res = evaluate_symbol_zenith(
            symbol=sym,
            timeframe=args.timeframe,
            start_date=args.start_date,
            start_time=args.start_time,
            end_date=args.end_date,
            db_path=args.db_path,
            rr_ratio=args.rr_ratio,
            sl_atr_mult=args.sl_atr_mult,
            cached_1m_candles=c_1m
        )
        symbol_results.append(res)
        all_trades.extend(res["trades"])

        status_symbol = "[OK]" if res["win_rate"] >= 50.0 else "[-]"
        print(f"  [{i:02d}/{len(symbols):02d}] {sym:<12s} | Setups: {res['total_trades']:<3d} | Wins: {res['target_hits']:<2d} | Losses: {res['sl_hits']:<2d} | Win Rate: {status_symbol} {res['win_rate']:5.1f}%")

    # Global summary calculations
    resolved_trades = [t for t in all_trades if t["outcome"] in ("TARGET_HIT", "SL_HIT")]
    total_wins = sum(1 for t in resolved_trades if t["outcome"] == "TARGET_HIT")
    total_losses = sum(1 for t in resolved_trades if t["outcome"] == "SL_HIT")
    unresolved_count = sum(1 for t in all_trades if t["outcome"] == "UNRESOLVED")
    global_win_rate = (total_wins / len(resolved_trades) * 100.0) if resolved_trades else 0.0

    net_r = (total_wins * args.rr_ratio) - (total_losses * 1.0)
    profit_factor = (total_wins * args.rr_ratio) / (total_losses * 1.0) if total_losses > 0 else 999.0
    expectancy = (net_r / len(resolved_trades)) if resolved_trades else 0.0

    print("\n" + "=" * 120)
    print(" ZENITH STRATEGY DISCOVERY & VALIDATION SUMMARY MATRIX")
    print("=" * 120)
    print(f"  Evaluated Symbols: {len(symbols)}  |  Timeframe: {args.timeframe}  |  Target R:R: 1:{args.rr_ratio:.2f}")
    print(f"  Total Trades Found: {len(all_trades)}  |  Resolved: {len(resolved_trades)}  |  Active/Unresolved: {unresolved_count}")
    print("-" * 120)
    print(f"  Target Hits (Wins): {total_wins}  |  Stop Loss Hits: {total_losses}")
    print(f"  OVERALL WIN RATE:   {global_win_rate:.2f}%  (Target R:R 1:{args.rr_ratio:.2f})")
    print(f"  NET R-MULTIPLE:     {net_r:+.2f}R")
    print(f"  PROFIT FACTOR:      {profit_factor:.2f}")
    print(f"  EXPECTANCY / TRADE: {expectancy:+.2f}R")
    print("=" * 120 + "\n")

    if not args.no_html:
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(REPORTS_DIR, f"zenith_strategy_discovery_{timestamp_str}.html")
        latest_file = os.path.join(REPORTS_DIR, "latest_zenith_strategy_report.html")

        summary_dict = {
            "total_trades": len(all_trades),
            "target_hits": total_wins,
            "sl_hits": total_losses,
            "unresolved": unresolved_count,
            "win_rate": global_win_rate,
            "net_r": net_r,
            "profit_factor": profit_factor,
            "expectancy": expectancy
        }

        generate_zenith_html_report(
            summary_data=summary_dict,
            all_trades=all_trades,
            symbol_results=symbol_results,
            eval_timeframe=args.timeframe,
            period_start=args.start_date,
            rr_target=args.rr_ratio,
            output_path=report_file
        )

        shutil.copyfile(report_file, latest_file)
        print(f"[OK] Interactive ZENITH Strategy Report saved to: {report_file}")
        print(f"[OK] Latest Report link updated: {latest_file}\n")

        if args.open:
            import webbrowser
            webbrowser.open(os.path.abspath(report_file))


if __name__ == "__main__":
    main()
