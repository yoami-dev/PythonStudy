<#
===============================================================================
 PRIME TRADING STRATEGY — DISCOVERY & MULTI-INSTRUMENT BACKTEST RUNNER (PowerShell)
===============================================================================
 Usage Examples:
   .\research_prime.ps1 -Symbol INFY,TCS,RELIANCE,LT -Timeframe 5m -StartDate 2026-09-01 -Open
   .\research_prime.ps1 -Symbol ALL -Timeframe 5m -StartDate 2026-09-01
===============================================================================
#>

[CmdletBinding()]
param(
    [Alias("Symbols", "s")]
    [string]$Symbol = "INFY,TCS,RELIANCE,LT,BAJAJ-AUTO,BAJFINANCE,HDFCBANK,ICICIBANK,SBIN",

    [Alias("Timeframes", "t")]
    [string]$Timeframe = "5m",

    [Alias("sd", "start_date")]
    [string]$StartDate = "2026-09-01",

    [Alias("st", "start_time")]
    [string]$StartTime = "09:30:00",

    [Alias("ed", "end_date")]
    [string]$EndDate = $null,

    [Alias("db_path", "DbPath")]
    [string]$DbPath = "$PSScriptRoot\..\smm_trading.db",

    [Alias("w", "Workers")]
    [int]$Workers = 6,

    [Alias("no_html")]
    [switch]$NoHtml,

    [Alias("o")]
    [switch]$Open
)

$ProjectRoot = Resolve-Path "$PSScriptRoot\.."
$PythonExe = Join-Path $ProjectRoot "venv\Scripts\python.exe"
if (-not (Test-Path $PythonExe)) {
    $PythonExe = "python"
}

$ScriptPath = Join-Path $PSScriptRoot "discover_prime_strategy.py"

$ArgsList = @(
    "-u",
    "`"$ScriptPath`"",
    "--symbol", "`"$Symbol`"",
    "--timeframe", "`"$Timeframe`"",
    "--start-date", "`"$StartDate`"",
    "--start-time", "`"$StartTime`"",
    "--workers", "$Workers"
)

if ($EndDate) {
    $ArgsList += @("--end-date", "`"$EndDate`"")
}
if ($DbPath) {
    $ArgsList += @("--db-path", "`"$DbPath`"")
}
if ($NoHtml) {
    $ArgsList += "--no-html"
}
if ($Open) {
    $ArgsList += "--open"
}

& $PythonExe @ArgsList
