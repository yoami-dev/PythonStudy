@echo off
setlocal
cd /d "%~dp0"

echo ===============================================================================
echo  KRAKEN MOBILE DOWNLOAD SERVER (FOR TERMUX ON ANDROID)
echo ===============================================================================

set "PYTHON_EXE=..\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"

"%PYTHON_EXE%" -c "import sqlite3; conn=sqlite3.connect('..\smm_trading.db'); c=conn.cursor(); c.execute('SELECT access_token FROM fyers_tokens ORDER BY id DESC LIMIT 1'); r=c.fetchone(); open('fyers_token.txt','w').write(r[0]) if r else None" > nul 2>&1

echo.
echo [1] Find your PC's IP address below (look for IPv4 Address e.g. 192.168.1.XX):
ipconfig | findstr /i "IPv4"
echo.
echo [2] In Termux on your phone, download both the script and token:
echo     curl -O http://^<YOUR_PC_IP^>:8080/kraken_mobile_live.py
echo     curl -O http://^<YOUR_PC_IP^>:8080/fyers_token.txt
echo.
echo [3] Then run:
echo     python kraken_mobile_live.py --loop
echo.

echo ===============================================================================
echo  Server is running on port 8080. Press Ctrl+C to stop when download is done.
echo ===============================================================================
"%PYTHON_EXE%" -m http.server 8080
pause
