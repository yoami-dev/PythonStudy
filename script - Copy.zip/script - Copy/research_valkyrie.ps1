<#
.SYNOPSIS
    VALKYRIE High Risk-Reward Strategy Discovery & Multi-Instrument Backtester (PowerShell Runner).

.EXAMPLE
    .\research_valkyrie.ps1 -Symbol ALL -Timeframe 5m -StartDate 2026-09-01 -RR 3.0 -Open
#>

param(
    [string]$Symbol = "ALL",
    [string]$Timeframe = "5m",
    [string]$StartDate = "2026-09-01",
    [string]$StartTime = "09:30:00",
    [string]$EndDate = "",
    [float]$RR = 3.0,
    [float]$SL = 0.10,
    [switch]$Open
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
$venvPython = Join-Path $projectRoot "venv\Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    $venvPython = "python"
}

$env:PYTHONPATH = "$projectRoot;$env:PYTHONPATH"
$discoverScript = Join-Path $scriptDir "discover_valkyrie_strategy.py"

$argsList = @(
    $discoverScript,
    "--symbol", $Symbol,
    "--timeframe", $Timeframe,
    "--start-date", $StartDate,
    "--start-time", $StartTime,
    "--rr-ratio", $RR,
    "--sl-buffer-atr", $SL
)

if ($EndDate -ne "") {
    $argsList += @("--end-date", $EndDate)
}

if ($Open) {
    $argsList += "--open"
}

Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " VALKYRIE Asymmetric Strategy Discovery (R:R 1:$RR+)" -ForegroundColor Green
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host "  Symbol:     $Symbol"
Write-Host "  Timeframe:  $Timeframe"
Write-Host "  Start Date: $StartDate $StartTime"
Write-Host "  R:R Target: 1:$RR"
Write-Host "===============================================================================" -ForegroundColor Cyan

& $venvPython $argsList
