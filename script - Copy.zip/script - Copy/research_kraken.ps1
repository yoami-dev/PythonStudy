<#
.SYNOPSIS
    KRAKEN Two-Stage Asymmetric Strategy Discovery & Research Runner (PowerShell Runner).

.EXAMPLE
    .\research_kraken.ps1 -Symbol ALL -Timeframe 5m -StartDate 2026-09-01 -RR 3.0 -T1 1.2 -Open
#>

param(
    [string]$Symbol = "ALL",
    [string]$Timeframe = "5m",
    [string]$StartDate = "2026-09-01",
    [string]$StartTime = "09:30:00",
    [string]$EndDate = "",
    [float]$RR = 3.0,
    [float]$T1 = 1.2,
    [float]$SL = 0.08,
    [switch]$Open
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
$venvPython = Join-Path $projectRoot "venv\Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    $venvPython = "python"
}

$env:PYTHONPATH = "$projectRoot;$env:PYTHONPATH"
$discoverScript = Join-Path $scriptDir "discover_kraken_strategy.py"

$argsList = @(
    "-u",
    $discoverScript,
    "--symbol", $Symbol,
    "--timeframe", $Timeframe,
    "--start-date", $StartDate,
    "--start-time", $StartTime,
    "--rr-ratio", $RR,
    "--t1-rr", $T1,
    "--sl-buffer-atr", $SL
)

if ($EndDate -ne "") {
    $argsList += @("--end-date", $EndDate)
}

if ($Open) {
    $argsList += "--open"
}

Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " KRAKEN Two-Stage Asymmetric Strategy Discovery (T1: +$($T1)R | T2: +$($RR)R)" -ForegroundColor Green
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host "  Symbol:     $Symbol"
Write-Host "  Timeframe:  $Timeframe"
Write-Host "  Start Date: $StartDate $StartTime"
Write-Host "  T1 Lock:    +$($T1)R"
Write-Host "  T2 Runner:  +$($RR)R"
Write-Host "===============================================================================" -ForegroundColor Cyan

& $venvPython $argsList
