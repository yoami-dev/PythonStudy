@echo off
setlocal

:: ============================================================================
:: SMM Trading Platform - Application Restart Script
:: Location: D:\Milind\MyTradingPlatform\script\restart_app.bat
:: ============================================================================

set "SCRIPT_DIR=%~dp0"

echo ============================================================================
echo   Restarting SMM Trading Platform
echo ============================================================================

call "%SCRIPT_DIR%stop_app.bat"

echo Waiting 2 seconds before restart...
ping 127.0.0.1 -n 3 >nul

call "%SCRIPT_DIR%start_app.bat"

endlocal
