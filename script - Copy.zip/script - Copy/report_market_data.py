#!/usr/bin/env python3
"""
================================================================================
SMM Trading Platform - Market Data Inventory & Coverage Report Generator
Location: E:\\Milind\\MyTradingPlatform\\script\\report_market_data.py
================================================================================

Inspects 'smm_trading.db' and generates comprehensive inventory reports in:
- Interactive HTML Dashboard (Tabular, Searchable, Sortable, Heatmap Matrix)
- Formatted Console Tables
- CSV Spreadsheet
- Markdown Report

States for every instrument and timeframe:
- Instrument Name (Symbol & FYERS Symbol)
- Start Year & Start Month
- End Year & End Month
- Start Date & End Date
- Timeframe data available
- Candle counts & Status

Helps identify exact data gaps to fetch only missing data instead of running
full historical ingestion for the entire Nifty 50 universe.
"""

import os
import sys
import csv
import json
import time
import sqlite3
import argparse
import webbrowser
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor

# Ensure safe UTF-8 output encoding for Windows terminal
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

DEFAULT_DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")
DEFAULT_WATCHLIST_PATH = os.path.join(PROJECT_ROOT, "Prompts", "Watchlist_Nifty 50_2026-08-24.csv")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "script", "reports")

# Native supported FYERS timeframes
ALL_TIMEFRAMES = [
    "5S", "10S", "1m", "2m", "3m", "5m", "10m", "15m", "20m", "30m", "1h", "2h", "4h", "1D"
]


def load_nifty50_watchlist(watchlist_path: str) -> List[str]:
    """Parse Nifty 50 symbols from watchlist CSV file."""
    if not os.path.exists(watchlist_path):
        return []
    try:
        with open(watchlist_path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            symbols = [s.strip() for s in content.replace("\n", ",").split(",") if s.strip()]
            return symbols
    except Exception as e:
        print(f"[WARNING] Could not read watchlist file '{watchlist_path}': {e}", file=sys.stderr)
        return []


def get_db_connection(db_path: str) -> sqlite3.Connection:
    """Connect to SQLite in read-only mode for speed and safety."""
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database file not found at: {db_path}")
    conn = sqlite3.connect(f"file:{os.path.abspath(db_path)}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def get_instruments(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """Retrieve all instruments recorded in the instruments table."""
    c = conn.cursor()
    c.execute("SELECT id, symbol, display_name, exchange, fyers_symbol, active FROM instruments ORDER BY id ASC")
    rows = c.fetchall()
    return [dict(r) for r in rows]


def _query_single_summary(task: Tuple[str, int, str, str, str, str]) -> Dict[str, Any]:
    """Worker task to query summary for 1 instrument + timeframe combination using index lookup."""
    db_path, inst_id, sym, disp_name, fyers_sym, tf = task
    t_conn = sqlite3.connect(f"file:{os.path.abspath(db_path)}?mode=ro", uri=True)
    t_c = t_conn.cursor()

    try:
        t_c.execute(
            "SELECT candle_timestamp FROM market_candles WHERE instrument_id = ? AND timeframe = ? ORDER BY candle_timestamp ASC LIMIT 1",
            (inst_id, tf)
        )
        first_row = t_c.fetchone()
        if not first_row:
            return {
                "instrument_id": inst_id,
                "symbol": sym,
                "display_name": disp_name,
                "fyers_symbol": fyers_sym,
                "timeframe": tf,
                "candle_count": 0,
                "start_year": "-",
                "start_month": "-",
                "start_date": "-",
                "end_year": "-",
                "end_month": "-",
                "end_date": "-",
                "status": "EMPTY",
                "raw_start_ts": None,
                "raw_end_ts": None,
            }

        min_ts = first_row[0]

        t_c.execute(
            "SELECT candle_timestamp FROM market_candles WHERE instrument_id = ? AND timeframe = ? ORDER BY candle_timestamp DESC LIMIT 1",
            (inst_id, tf)
        )
        last_row = t_c.fetchone()
        max_ts = last_row[0] if last_row else min_ts

        t_c.execute(
            "SELECT COUNT(*) FROM market_candles WHERE instrument_id = ? AND timeframe = ?",
            (inst_id, tf)
        )
        cnt = t_c.fetchone()[0]

        start_date = min_ts[:10] if min_ts else "-"
        end_date = max_ts[:10] if max_ts else "-"
        start_year = min_ts[:4] if min_ts and len(min_ts) >= 4 else "-"
        start_month = min_ts[5:7] if min_ts and len(min_ts) >= 7 else "-"
        end_year = max_ts[:4] if max_ts and len(max_ts) >= 4 else "-"
        end_month = max_ts[5:7] if max_ts and len(max_ts) >= 7 else "-"

        return {
            "instrument_id": inst_id,
            "symbol": sym,
            "display_name": disp_name,
            "fyers_symbol": fyers_sym,
            "timeframe": tf,
            "candle_count": cnt,
            "start_year": start_year,
            "start_month": start_month,
            "start_date": start_date,
            "end_year": end_year,
            "end_month": end_month,
            "end_date": end_date,
            "status": "AVAILABLE" if cnt > 0 else "EMPTY",
            "raw_start_ts": min_ts,
            "raw_end_ts": max_ts,
        }
    finally:
        t_conn.close()


def query_summary_coverage_fast(
    db_path: str,
    instruments: List[Dict[str, Any]],
    timeframes: List[str],
    max_workers: int = 16
) -> List[Dict[str, Any]]:
    """Multithreaded query for summary coverage across all instrument-timeframe pairs."""
    tasks = []
    for inst in instruments:
        for tf in timeframes:
            tasks.append((
                db_path,
                inst["id"],
                inst["symbol"],
                inst.get("display_name", inst["symbol"]),
                inst.get("fyers_symbol", inst["symbol"]),
                tf
            ))

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(_query_single_summary, tasks))

    return results


def _query_single_monthly(task: Tuple[str, int, str, str, str]) -> List[Dict[str, Any]]:
    """Worker task to query monthly breakdown for 1 instrument + timeframe combination."""
    db_path, inst_id, sym, fyers_sym, tf = task
    t_conn = sqlite3.connect(f"file:{os.path.abspath(db_path)}?mode=ro", uri=True)
    t_c = t_conn.cursor()
    out = []

    try:
        t_c.execute("""
            SELECT 
                strftime('%Y', candle_timestamp) as yr,
                strftime('%m', candle_timestamp) as mo,
                MIN(date(candle_timestamp)) as start_dt,
                MAX(date(candle_timestamp)) as end_dt,
                COUNT(*) as cnt
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = ?
            GROUP BY yr, mo
            ORDER BY yr ASC, mo ASC
        """, (inst_id, tf))
        rows = t_c.fetchall()
        for r in rows:
            if r[0] and r[1]:
                out.append({
                    "instrument_id": inst_id,
                    "symbol": sym,
                    "fyers_symbol": fyers_sym,
                    "timeframe": tf,
                    "year": r[0],
                    "month": r[1],
                    "year_month": f"{r[0]}-{r[1]}",
                    "start_date": r[2],
                    "end_date": r[3],
                    "candle_count": r[4],
                })
    finally:
        t_conn.close()

    return out


def query_monthly_coverage_fast(
    db_path: str,
    active_summary_records: List[Dict[str, Any]],
    max_workers: int = 16
) -> List[Dict[str, Any]]:
    """Multithreaded query for monthly breakdown only on combinations with existing data."""
    tasks = []
    for rec in active_summary_records:
        if rec["candle_count"] > 0:
            tasks.append((
                db_path,
                rec["instrument_id"],
                rec["symbol"],
                rec["fyers_symbol"],
                rec["timeframe"]
            ))

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        nested = list(executor.map(_query_single_monthly, tasks))

    results = []
    for sublist in nested:
        results.extend(sublist)
    return results


def _query_single_yearly(task: Tuple[str, int, str, str, str]) -> List[Dict[str, Any]]:
    """Worker task to query yearly breakdown for 1 instrument + timeframe combination."""
    db_path, inst_id, sym, fyers_sym, tf = task
    t_conn = sqlite3.connect(f"file:{os.path.abspath(db_path)}?mode=ro", uri=True)
    t_c = t_conn.cursor()
    out = []

    try:
        t_c.execute("""
            SELECT 
                strftime('%Y', candle_timestamp) as yr,
                MIN(date(candle_timestamp)) as start_dt,
                MAX(date(candle_timestamp)) as end_dt,
                COUNT(*) as cnt
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = ?
            GROUP BY yr
            ORDER BY yr ASC
        """, (inst_id, tf))
        rows = t_c.fetchall()
        for r in rows:
            if r[0]:
                out.append({
                    "instrument_id": inst_id,
                    "symbol": sym,
                    "fyers_symbol": fyers_sym,
                    "timeframe": tf,
                    "year": r[0],
                    "start_date": r[1],
                    "end_date": r[2],
                    "candle_count": r[3],
                })
    finally:
        t_conn.close()

    return out


def query_yearly_coverage_fast(
    db_path: str,
    active_summary_records: List[Dict[str, Any]],
    max_workers: int = 16
) -> List[Dict[str, Any]]:
    """Multithreaded query for yearly breakdown on active combinations."""
    tasks = []
    for rec in active_summary_records:
        if rec["candle_count"] > 0:
            tasks.append((
                db_path,
                rec["instrument_id"],
                rec["symbol"],
                rec["fyers_symbol"],
                rec["timeframe"]
            ))

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        nested = list(executor.map(_query_single_yearly, tasks))

    results = []
    for sublist in nested:
        results.extend(sublist)
    return results


def format_table(headers: List[str], rows: List[List[str]], alignments: Optional[List[str]] = None) -> str:
    """Format an ASCII table with neat column widths and alignments."""
    if not rows:
        return "No data available."

    num_cols = len(headers)
    if not alignments:
        alignments = ["<"] * num_cols

    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, val in enumerate(row):
            if i < num_cols:
                col_widths[i] = max(col_widths[i], len(str(val)))

    sep_line = "+" + "+".join(["-" * (w + 2) for w in col_widths]) + "+"
    header_str = "|" + "|".join([
        f" {headers[i].ljust(col_widths[i]) if alignments[i] == '<' else headers[i].rjust(col_widths[i])} "
        for i in range(num_cols)
    ]) + "|"

    row_strs = []
    for row in rows:
        r_str = "|" + "|".join([
            f" {str(row[i]).ljust(col_widths[i]) if alignments[i] == '<' else str(row[i]).rjust(col_widths[i])} "
            for i in range(num_cols)
        ]) + "|"
        row_strs.append(r_str)

    return "\n".join([sep_line, header_str, sep_line] + row_strs + [sep_line])


def print_summary_view(summary_records: List[Dict[str, Any]], filter_empty: bool = True):
    """Print clean summary table stating instrument, year, month, start date, end date, and timeframe."""
    headers = [
        "Symbol", "FYERS Symbol", "TF", "Start Year", "Start Month", "Start Date",
        "End Year", "End Month", "End Date", "Candles", "Status"
    ]
    alignments = ["<", "<", "<", "<", "<", "<", "<", "<", "<", ">", "<"]
    

    rows = []
    total_candles = 0

    for r in summary_records:
        cnt = r["candle_count"]
        if filter_empty and cnt == 0:
            continue
        total_candles += cnt
        rows.append([
            r["symbol"],
            r["fyers_symbol"],
            r["timeframe"],
            r["start_year"],
            r["start_month"],
            r["start_date"],
            r["end_year"],
            r["end_month"],
            r["end_date"],
            f"{cnt:,}",
            r["status"]
        ])

    print("\n" + "=" * 120)
    print("  MARKET DATA INVENTORY REPORT - INSTRUMENT, DATE RANGE & TIMEFRAMES AVAILABLE")
    print("=" * 120)
    if rows:
        print(format_table(headers, rows, alignments))
        print(f"\nSummary: {len(rows)} instrument-timeframe combinations displayed | Total Persisted Candles: {total_candles:,}")
    else:
        print("No market candles found matching the specified criteria.")


def print_monthly_view(monthly_records: List[Dict[str, Any]]):
    """Print granular month-by-month table."""
    headers = ["Symbol", "FYERS Symbol", "TF", "Year", "Month", "Start Date", "End Date", "Candles"]
    alignments = ["<", "<", "<", "<", "<", "<", "<", ">"]

    rows = []
    total_candles = 0
    for r in monthly_records:
        total_candles += r["candle_count"]
        rows.append([
            r["symbol"],
            r["fyers_symbol"],
            r["timeframe"],
            r["year"],
            r["month"],
            r["start_date"],
            r["end_date"],
            f"{r['candle_count']:,}"
        ])

    print("\n" + "=" * 110)
    print("  MARKET DATA COVERAGE - YEAR & MONTH DETAILED BREAKDOWN")
    print("=" * 110)
    if rows:
        print(format_table(headers, rows, alignments))
        print(f"\nMonthly Records: {len(rows)} | Total Candles: {total_candles:,}")
    else:
        print("No monthly market data found matching criteria.")


def print_yearly_view(yearly_records: List[Dict[str, Any]]):
    """Print yearly breakdown table."""
    headers = ["Symbol", "FYERS Symbol", "TF", "Year", "Start Date", "End Date", "Candles"]
    alignments = ["<", "<", "<", "<", "<", "<", ">"]

    rows = []
    total_candles = 0
    for r in yearly_records:
        total_candles += r["candle_count"]
        rows.append([
            r["symbol"],
            r["fyers_symbol"],
            r["timeframe"],
            r["year"],
            r["start_date"],
            r["end_date"],
            f"{r['candle_count']:,}"
        ])

    print("\n" + "=" * 100)
    print("  MARKET DATA COVERAGE - YEARLY BREAKDOWN")
    print("=" * 100)
    if rows:
        print(format_table(headers, rows, alignments))
        print(f"\nYearly Records: {len(rows)} | Total Candles: {total_candles:,}")
    else:
        print("No yearly market data found matching criteria.")


def print_matrix_view(
    instruments: List[Dict[str, Any]],
    summary_records: List[Dict[str, Any]],
    timeframes: List[str]
):
    """Print a grid / matrix showing coverage across all timeframes for each instrument."""
    data_map: Dict[Tuple[str, str], int] = {}
    for r in summary_records:
        data_map[(r["symbol"], r["timeframe"])] = r["candle_count"]

    headers = ["#", "Symbol"] + timeframes + ["Total Candles"]
    alignments = [">", "<"] + [">"] * len(timeframes) + [">"]

    rows = []
    grand_total = 0

    for idx, inst in enumerate(instruments, 1):
        sym = inst["symbol"]
        row = [str(idx), sym]
        sym_total = 0

        for tf in timeframes:
            cnt = data_map.get((sym, tf), 0)
            sym_total += cnt
            if cnt > 0:
                if cnt >= 1_000_000:
                    val_str = f"{cnt/1_000_000:.1f}M"
                elif cnt >= 10_000:
                    val_str = f"{cnt/1_000:.0f}k"
                elif cnt >= 1_000:
                    val_str = f"{cnt/1_000:.1f}k"
                else:
                    val_str = str(cnt)
            else:
                val_str = "-"
            row.append(val_str)

        grand_total += sym_total
        row.append(f"{sym_total:,}")
        rows.append(row)

    print("\n" + "=" * 125)
    print("  NIFTY 50 UNIVERSE TIMEFRAME COVERAGE MATRIX")
    print("=" * 125)
    print(format_table(headers, rows, alignments))
    print(f"\nTotal Instruments: {len(instruments)} | Grand Total Persisted Candles: {grand_total:,}")


def analyze_missing_data(
    watchlist_symbols: List[str],
    instruments: List[Dict[str, Any]],
    summary_records: List[Dict[str, Any]],
    timeframes: List[str],
    target_start_date: str = "2017-07-03"
) -> Dict[str, Any]:
    """
    Compare database state against watchlist and target timeframes/dates.
    Generate actionable fetch commands and return structured gap details.
    """
    db_symbols = {inst["symbol"]: inst for inst in instruments}
    db_fyers = {inst.get("fyers_symbol", ""): inst for inst in instruments}

    completely_missing_symbols = []
    for ws_sym in watchlist_symbols:
        clean_sym = ws_sym.replace("NSE:", "").replace("-EQ", "").replace("-INDEX", "")
        if clean_sym not in db_symbols and ws_sym not in db_fyers:
            completely_missing_symbols.append(ws_sym)

    data_map: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for r in summary_records:
        data_map[(r["symbol"], r["timeframe"])] = r

    missing_timeframe_items = []
    partial_date_items = []

    for inst in instruments:
        sym = inst["symbol"]
        fyers_sym = inst.get("fyers_symbol", sym)

        for tf in timeframes:
            rec = data_map.get((sym, tf))
            if not rec or rec["candle_count"] == 0:
                missing_timeframe_items.append({
                    "symbol": sym,
                    "fyers_symbol": fyers_sym,
                    "timeframe": tf
                })
            else:
                if tf in ["1D", "1m"] and rec["start_date"] > target_start_date:
                    partial_date_items.append({
                        "symbol": sym,
                        "fyers_symbol": fyers_sym,
                        "timeframe": tf,
                        "current_start": rec["start_date"],
                        "target_start": target_start_date
                    })

    # Recommended commands list
    recommended_commands = []
    if completely_missing_symbols:
        sym_arg = ",".join(completely_missing_symbols)
        tf_arg = ",".join(timeframes)
        recommended_commands.append({
            "title": "Fetch Completely Missing Instruments",
            "cmd": f'script\\fetch_data_background.bat -Symbols "{sym_arg}" -Timeframes "{tf_arg}" -StartDate {target_start_date}'
        })

    if missing_timeframe_items:
        tf_grouped: Dict[str, List[str]] = {}
        for item in missing_timeframe_items:
            tf_grouped.setdefault(item["timeframe"], []).append(item["fyers_symbol"])

        for tf, syms in tf_grouped.items():
            sym_list = "ALL" if len(syms) == len(instruments) else ",".join(syms)
            start_dt = "2026-08-01" if "S" in tf else target_start_date
            recommended_commands.append({
                "title": f"Fetch Missing Timeframe '{tf}' ({len(syms)} symbols)",
                "cmd": f'script\\fetch_data_background.bat -Symbols "{sym_list}" -Timeframes "{tf}" -StartDate {start_dt}'
            })

    print("\n" + "=" * 105)
    print("  MISSING DATA & GAP ANALYSIS REPORT")
    print("=" * 105)

    if completely_missing_symbols:
        print(f"\n[!] Completely Missing Instruments from Database ({len(completely_missing_symbols)}):")
        for ms in completely_missing_symbols:
            print(f"  - {ms}")
    else:
        print(f"\n[OK] All {len(watchlist_symbols)} Nifty 50 watchlist instruments are registered in database.")

    if missing_timeframe_items:
        print(f"\n[!] Missing Timeframe Combinations ({len(missing_timeframe_items)} items):")
        tf_grouped_p: Dict[str, List[str]] = {}
        for item in missing_timeframe_items:
            tf_grouped_p.setdefault(item["timeframe"], []).append(item["fyers_symbol"])

        for tf, syms in tf_grouped_p.items():
            print(f"\n  Timeframe '{tf}': Missing for {len(syms)} symbols")
            if len(syms) <= 10:
                print(f"    Symbols: {', '.join(syms)}")
            else:
                print(f"    Symbols (first 10): {', '.join(syms[:10])} ... (+{len(syms)-10} more)")
    else:
        print(f"\n[OK] All requested timeframes ({', '.join(timeframes)}) have data for existing instruments.")

    if partial_date_items:
        print(f"\n[!] Instruments with Delayed Start Dates (Target: {target_start_date}):")
        for item in partial_date_items:
            print(f"  - {item['symbol']} ({item['timeframe']}): starts at {item['current_start']}")

    print("\n" + "-" * 105)
    print("  RECOMMENDED FETCH COMMANDS (Run only for missing data)")
    print("-" * 105)

    if not recommended_commands:
        print("  [OK] Database is fully up-to-date for the selected timeframes. No fetch required!")
    else:
        for rc in recommended_commands:
            print(f"\n  # {rc['title']}:")
            print(f"  {rc['cmd']}")

    print("\n" + "=" * 105)

    return {
        "completely_missing_symbols": completely_missing_symbols,
        "missing_timeframe_items": missing_timeframe_items,
        "partial_date_items": partial_date_items,
        "recommended_commands": recommended_commands
    }


def export_csv_report(
    summary_records: List[Dict[str, Any]],
    output_path: str
):
    """Export complete dataset to CSV format."""
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "Symbol", "Display_Name", "FYERS_Symbol", "Timeframe",
            "Start_Year", "Start_Month", "Start_Date",
            "End_Year", "End_Month", "End_Date",
            "Candle_Count", "Status"
        ])
        for r in summary_records:
            writer.writerow([
                r["symbol"],
                r["display_name"],
                r["fyers_symbol"],
                r["timeframe"],
                r["start_year"],
                r["start_month"],
                r["start_date"],
                r["end_year"],
                r["end_month"],
                r["end_date"],
                r["candle_count"],
                r["status"]
            ])

    print(f"\n[EXPORT] CSV Report saved successfully to:\n  -> {os.path.abspath(output_path)}")


def export_markdown_report(
    instruments: List[Dict[str, Any]],
    summary_records: List[Dict[str, Any]],
    timeframes: List[str],
    output_path: str
):
    """Export formatted Markdown report."""
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    lines = []
    lines.append("# SMM Trading Platform - Market Data Inventory Report")
    lines.append(f"\n**Generated At:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    lines.append(f"**Database:** `{DEFAULT_DB_PATH}`")
    lines.append(f"**Total Instruments:** {len(instruments)}")
    lines.append(f"**Timeframes Analyzed:** `{', '.join(timeframes)}`\n")

    total_candles = sum(r["candle_count"] for r in summary_records)
    lines.append(f"### Total Persisted Candles: `{total_candles:,}`\n")

    lines.append("## Timeframe Coverage Summary\n")
    lines.append("| Timeframe | Instruments With Data | Total Candles | Earliest Date | Latest Date |")
    lines.append("|---|---|---|---|---|")

    for tf in timeframes:
        tf_recs = [r for r in summary_records if r["timeframe"] == tf and r["candle_count"] > 0]
        cnt = sum(r["candle_count"] for r in tf_recs)
        min_dt = min([r["start_date"] for r in tf_recs]) if tf_recs else "-"
        max_dt = max([r["end_date"] for r in tf_recs]) if tf_recs else "-"
        lines.append(f"| `{tf}` | {len(tf_recs)} / {len(instruments)} | {cnt:,} | {min_dt} | {max_dt} |")

    lines.append("\n## Nifty 50 Instrument Matrix\n")
    data_map = {(r["symbol"], r["timeframe"]): r["candle_count"] for r in summary_records}

    tf_cols = " | ".join([f"`{tf}`" for tf in timeframes])
    tf_divs = " | ".join(["---"] * len(timeframes))
    lines.append(f"| # | Symbol | FYERS Symbol | {tf_cols} | Total Candles |")
    lines.append(f"|---|---|---|{tf_divs}|---|")

    for idx, inst in enumerate(instruments, 1):
        sym = inst["symbol"]
        fyers_sym = inst.get("fyers_symbol", sym)
        sym_total = sum(data_map.get((sym, tf), 0) for tf in timeframes)

        row_vals = []
        for tf in timeframes:
            cnt = data_map.get((sym, tf), 0)
            if cnt > 0:
                row_vals.append(f"{cnt:,}")
            else:
                row_vals.append("-")

        tf_data_str = " | ".join(row_vals)
        lines.append(f"| {idx} | **{sym}** | `{fyers_sym}` | {tf_data_str} | **{sym_total:,}** |")

    lines.append("\n## Detailed Inventory Data\n")
    lines.append("| Symbol | FYERS Symbol | TF | Start Year | Start Month | Start Date | End Year | End Month | End Date | Candles | Status |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for r in summary_records:
        if r["candle_count"] > 0:
            lines.append(f"| {r['symbol']} | `{r['fyers_symbol']}` | `{r['timeframe']}` | {r['start_year']} | {r['start_month']} | {r['start_date']} | {r['end_year']} | {r['end_month']} | {r['end_date']} | {r['candle_count']:,} | {r['status']} |")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"\n[EXPORT] Markdown Report saved successfully to:\n  -> {os.path.abspath(output_path)}")


def export_html_report(
    db_path: str,
    instruments: List[Dict[str, Any]],
    summary_records: List[Dict[str, Any]],
    monthly_records: Optional[List[Dict[str, Any]]],
    timeframes: List[str],
    gap_data: Dict[str, Any],
    output_path: str
):
    """
    Generate an ultra-modern, interactive, self-contained HTML Dashboard report
    with live search, column sorting, filtering tabs, matrix heatmap, and 1-click fetch command copy.
    """
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    db_size_gb = os.path.getsize(db_path) / (1024 ** 3) if os.path.exists(db_path) else 0
    total_candles = sum(r["candle_count"] for r in summary_records)
    active_records = [r for r in summary_records if r["candle_count"] > 0]
    earliest_date = min([r["start_date"] for r in active_records]) if active_records else "-"
    latest_date = max([r["end_date"] for r in active_records]) if active_records else "-"

    # Build matrix map: symbol -> {tf: {cnt, start, end}}
    matrix_map: Dict[str, Dict[str, Any]] = {}
    for inst in instruments:
        matrix_map[inst["symbol"]] = {"display_name": inst.get("display_name", inst["symbol"]), "fyers": inst.get("fyers_symbol", inst["symbol"]), "tfs": {}}

    for r in summary_records:
        sym = r["symbol"]
        tf = r["timeframe"]
        if sym in matrix_map:
            matrix_map[sym]["tfs"][tf] = {
                "cnt": r["candle_count"],
                "start": r["start_date"],
                "end": r["end_date"],
                "start_yr": r["start_year"],
                "start_mo": r["start_month"],
                "end_yr": r["end_year"],
                "end_mo": r["end_month"],
                "status": r["status"]
            }

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SMM Trading Platform - Market Data Inventory & Coverage Report</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {{
      --bg-dark: #090d16;
      --bg-card: rgba(18, 24, 38, 0.85);
      --bg-card-hover: rgba(28, 36, 56, 0.95);
      --border-color: rgba(255, 255, 255, 0.08);
      --border-focus: #3b82f6;
      --primary: #3b82f6;
      --primary-glow: rgba(59, 130, 246, 0.25);
      --accent-cyan: #06b6d4;
      --accent-emerald: #10b981;
      --accent-emerald-glow: rgba(16, 185, 129, 0.2);
      --accent-amber: #f59e0b;
      --accent-rose: #f43f5e;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --text-dim: #64748b;
      --font-sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      --font-mono: 'JetBrains Mono', Consolas, Monaco, monospace;
    }}

    * {{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }}

    body {{
      background-color: var(--bg-dark);
      background-image: radial-gradient(circle at 15% 15%, rgba(59, 130, 246, 0.06) 0%, transparent 40%),
                        radial-gradient(circle at 85% 85%, rgba(16, 185, 129, 0.05) 0%, transparent 40%);
      color: var(--text-main);
      font-family: var(--font-sans);
      min-height: 100vh;
      padding: 24px;
      line-height: 1.5;
    }}

    .container {{
      max-width: 1680px;
      margin: 0 auto;
    }}

    /* Header */
    header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      padding: 20px 28px;
      background: var(--bg-card);
      backdrop-filter: blur(16px);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      margin-bottom: 24px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }}

    .brand-title {{
      display: flex;
      align-items: center;
      gap: 14px;
    }}

    .brand-logo {{
      width: 44px;
      height: 44px;
      background: linear-gradient(135deg, #2563eb, #06b6d4);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 22px;
      box-shadow: 0 0 20px var(--primary-glow);
    }}

    .brand-info h1 {{
      font-size: 22px;
      font-weight: 800;
      letter-spacing: -0.02em;
      background: linear-gradient(to right, #ffffff, #94a3b8);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }}

    .brand-info p {{
      font-size: 13px;
      color: var(--text-muted);
      font-family: var(--font-mono);
    }}

    .header-badges {{
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }}

    .badge {{
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: 600;
      font-family: var(--font-mono);
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid var(--border-color);
    }}

    .badge-live {{
      background: rgba(16, 185, 129, 0.15);
      border-color: rgba(16, 185, 129, 0.4);
      color: #34d399;
    }}

    .pulse-dot {{
      width: 8px;
      height: 8px;
      background-color: #10b981;
      border-radius: 50%;
      box-shadow: 0 0 8px #10b981;
      animation: pulse 2s infinite;
    }}

    @keyframes pulse {{
      0%, 100% {{ opacity: 1; transform: scale(1); }}
      50% {{ opacity: 0.5; transform: scale(0.85); }}
    }}

    /* KPI Grid */
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }}

    .kpi-card {{
      background: var(--bg-card);
      backdrop-filter: blur(12px);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 20px;
      transition: all 0.2s ease;
      position: relative;
      overflow: hidden;
    }}

    .kpi-card:hover {{
      transform: translateY(-2px);
      border-color: rgba(255, 255, 255, 0.15);
      background: var(--bg-card-hover);
    }}

    .kpi-card::before {{
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 3px;
      background: linear-gradient(90deg, var(--accent-cyan), var(--primary));
    }}

    .kpi-card.emerald::before {{ background: linear-gradient(90deg, var(--accent-emerald), #059669); }}
    .kpi-card.amber::before {{ background: linear-gradient(90deg, var(--accent-amber), #d97706); }}
    .kpi-card.rose::before {{ background: linear-gradient(90deg, var(--accent-rose), #e11d48); }}

    .kpi-label {{
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--text-dim);
      font-weight: 700;
      margin-bottom: 8px;
    }}

    .kpi-value {{
      font-size: 26px;
      font-weight: 800;
      font-family: var(--font-mono);
      color: var(--text-main);
      margin-bottom: 4px;
    }}

    .kpi-subtext {{
      font-size: 12px;
      color: var(--text-muted);
    }}

    /* Tabs & Controls */
    .nav-bar {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 12px 18px;
      margin-bottom: 20px;
    }}

    .tab-buttons {{
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }}

    .tab-btn {{
      background: transparent;
      border: 1px solid transparent;
      color: var(--text-muted);
      padding: 8px 18px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s ease;
      display: flex;
      align-items: center;
      gap: 8px;
    }}

    .tab-btn:hover {{
      color: var(--text-main);
      background: rgba(255, 255, 255, 0.05);
    }}

    .tab-btn.active {{
      background: var(--primary);
      color: #ffffff;
      border-color: var(--primary);
      box-shadow: 0 4px 14px var(--primary-glow);
    }}

    .search-box {{
      display: flex;
      align-items: center;
      gap: 10px;
      background: rgba(0, 0, 0, 0.3);
      border: 1px solid var(--border-color);
      border-radius: 10px;
      padding: 6px 14px;
      min-width: 280px;
    }}

    .search-box input {{
      background: transparent;
      border: none;
      outline: none;
      color: var(--text-main);
      font-family: var(--font-sans);
      font-size: 13px;
      width: 100%;
    }}

    .search-box input::placeholder {{
      color: var(--text-dim);
    }}

    /* Filter Pills */
    .filter-pills {{
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-bottom: 16px;
      align-items: center;
    }}

    .filter-pill {{
      background: rgba(255, 255, 255, 0.04);
      border: 1px solid var(--border-color);
      color: var(--text-muted);
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s ease;
    }}

    .filter-pill:hover, .filter-pill.active {{
      background: rgba(59, 130, 246, 0.15);
      border-color: var(--primary);
      color: #93c5fd;
    }}

    /* Content Panels */
    .tab-panel {{
      display: none;
    }}

    .tab-panel.active {{
      display: block;
      animation: fadeIn 0.2s ease-in-out;
    }}

    @keyframes fadeIn {{
      from {{ opacity: 0; transform: translateY(4px); }}
      to {{ opacity: 1; transform: translateY(0); }}
    }}

    /* Table Styling */
    .table-card {{
      background: var(--bg-card);
      backdrop-filter: blur(12px);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      overflow: hidden;
      box-shadow: 0 4px 24px rgba(0, 0, 0, 0.2);
    }}

    .table-container {{
      overflow-x: auto;
      max-height: 720px;
    }}

    table {{
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 13px;
    }}

    th {{
      background: #0f1524;
      color: var(--text-muted);
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      padding: 14px 16px;
      border-bottom: 1px solid var(--border-color);
      position: sticky;
      top: 0;
      z-index: 10;
      cursor: pointer;
      user-select: none;
      white-space: nowrap;
    }}

    th:hover {{
      color: var(--text-main);
      background: #151d32;
    }}

    th.sort-asc::after {{ content: " ▲"; font-size: 10px; color: var(--primary); }}
    th.sort-desc::after {{ content: " ▼"; font-size: 10px; color: var(--primary); }}

    td {{
      padding: 12px 16px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.04);
      color: var(--text-main);
      white-space: nowrap;
    }}

    tr:hover td {{
      background: rgba(255, 255, 255, 0.03);
    }}

    .font-mono {{
      font-family: var(--font-mono);
    }}

    .text-right {{
      text-align: right;
    }}

    .text-center {{
      text-align: center;
    }}

    /* Cell Status Badges */
    .status-badge {{
      display: inline-block;
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      font-family: var(--font-mono);
    }}

    .status-badge.available {{
      background: rgba(16, 185, 129, 0.15);
      color: #34d399;
      border: 1px solid rgba(16, 185, 129, 0.3);
    }}

    .status-badge.empty {{
      background: rgba(244, 63, 94, 0.15);
      color: #fb7185;
      border: 1px solid rgba(244, 63, 94, 0.3);
    }}

    /* Matrix Heatmap Cells */
    .matrix-cell {{
      text-align: center;
      font-family: var(--font-mono);
      font-size: 12px;
      font-weight: 600;
      position: relative;
    }}

    .cell-has-data {{
      color: #34d399;
      background: rgba(16, 185, 129, 0.08);
      border-radius: 6px;
      padding: 4px 6px;
      display: inline-block;
      min-width: 48px;
      cursor: default;
    }}

    .cell-has-data:hover {{
      background: rgba(16, 185, 129, 0.25);
      box-shadow: 0 0 10px rgba(16, 185, 129, 0.3);
    }}

    .cell-no-data {{
      color: var(--text-dim);
      display: inline-block;
      min-width: 48px;
    }}

    /* Tooltip */
    .tooltip {{
      position: relative;
    }}

    .tooltip:hover::after {{
      content: attr(data-tooltip);
      position: absolute;
      bottom: 125%;
      left: 50%;
      transform: translateX(-50%);
      background: #1e293b;
      color: #ffffff;
      padding: 6px 10px;
      border-radius: 6px;
      font-size: 11px;
      white-space: pre-wrap;
      z-index: 100;
      box-shadow: 0 4px 14px rgba(0,0,0,0.5);
      border: 1px solid rgba(255,255,255,0.1);
      pointer-events: none;
      min-width: 140px;
      text-align: left;
    }}

    /* Gap Assistant Cards */
    .assistant-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(480px, 1fr));
      gap: 20px;
      margin-top: 10px;
    }}

    .assistant-card {{
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 24px;
    }}

    .assistant-card h3 {{
      font-size: 16px;
      font-weight: 700;
      margin-bottom: 12px;
      display: flex;
      align-items: center;
      gap: 10px;
    }}

    .cmd-box {{
      background: #060910;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      padding: 14px 16px;
      margin: 12px 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
    }}

    .cmd-text {{
      font-family: var(--font-mono);
      font-size: 12px;
      color: #38bdf8;
      word-break: break-all;
      user-select: all;
    }}

    .copy-btn {{
      background: rgba(59, 130, 246, 0.2);
      border: 1px solid var(--primary);
      color: #93c5fd;
      padding: 6px 14px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.15s ease;
      white-space: nowrap;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }}

    .copy-btn:hover {{
      background: var(--primary);
      color: #ffffff;
    }}

    /* Toast Notification */
    #toast {{
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #10b981;
      color: #ffffff;
      padding: 12px 20px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 700;
      box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
      display: none;
      z-index: 1000;
    }}
  </style>
</head>
<body>

<div class="container">
  <!-- Header -->
  <header>
    <div class="brand-title">
      <div class="brand-logo">📊</div>
      <div class="brand-info">
        <h1>Market Data Coverage & Inventory Report</h1>
        <p>Database: {os.path.abspath(db_path)} ({db_size_gb:.2f} GB)</p>
      </div>
    </div>
    <div class="header-badges">
      <div class="badge badge-live"><div class="pulse-dot"></div> PERSISTED INVENTORY</div>
      <div class="badge">Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}</div>
      <div class="badge">{len(instruments)} Instruments</div>
      <div class="badge">{len(timeframes)} Timeframes</div>
    </div>
  </header>

  <!-- KPI Grid -->
  <div class="kpi-grid">
    <div class="kpi-card">
      <div class="kpi-label">Total Persisted Candles</div>
      <div class="kpi-value">{total_candles:,}</div>
      <div class="kpi-subtext">Across {len(active_records):,} active combinations</div>
    </div>
    <div class="kpi-card emerald">
      <div class="kpi-label">Historical Span</div>
      <div class="kpi-value">{earliest_date[:4]} - {latest_date[:4]}</div>
      <div class="kpi-subtext">{earliest_date} to {latest_date}</div>
    </div>
    <div class="kpi-card amber">
      <div class="kpi-label">Instruments Tracked</div>
      <div class="kpi-value">{len(instruments)} / 50</div>
      <div class="kpi-subtext">Nifty 50 Universe</div>
    </div>
    <div class="kpi-card rose">
      <div class="kpi-label">Missing Gaps Identified</div>
      <div class="kpi-value">{len(gap_data.get('missing_timeframe_items', []))}</div>
      <div class="kpi-subtext">Actionable fetch commands available</div>
    </div>
  </div>

  <!-- Navigation Bar & Controls -->
  <div class="nav-bar">
    <div class="tab-buttons">
      <button class="tab-btn active" onclick="switchTab('matrix')">📊 Timeframe Matrix</button>
      <button class="tab-btn" onclick="switchTab('inventory')">📋 Full Inventory Table</button>
      <button class="tab-btn" onclick="switchTab('assistant')">⚡ Fetch Gap Assistant</button>
    </div>
    <div class="search-box">
      <span>🔍</span>
      <input type="text" id="globalSearch" placeholder="Search symbol, timeframe, or year..." onkeyup="handleSearch()">
    </div>
  </div>

  <!-- TAB 1: Timeframe Matrix -->
  <div id="tab-matrix" class="tab-panel active">
    <div class="table-card">
      <div class="table-container">
        <table id="matrixTable">
          <thead>
            <tr>
              <th style="width: 50px;">#</th>
              <th>Symbol</th>
              <th>FYERS Symbol</th>
              {" ".join([f'<th class="text-center">{tf}</th>' for tf in timeframes])}
              <th class="text-right">Total Candles</th>
            </tr>
          </thead>
          <tbody>
          """

    # Populate Matrix rows
    for idx, inst in enumerate(instruments, 1):
        sym = inst["symbol"]
        fyers_sym = inst.get("fyers_symbol", sym)
        m_info = matrix_map.get(sym, {})
        sym_total = sum(m_info.get("tfs", {}).get(tf, {}).get("cnt", 0) for tf in timeframes)

        cells = []
        for tf in timeframes:
            tf_data = m_info.get("tfs", {}).get(tf, {})
            cnt = tf_data.get("cnt", 0)
            if cnt > 0:
                s_dt = tf_data.get("start", "-")
                e_dt = tf_data.get("end", "-")
                s_yr = tf_data.get("start_yr", "-")
                s_mo = tf_data.get("start_mo", "-")
                e_yr = tf_data.get("end_yr", "-")
                e_mo = tf_data.get("end_mo", "-")
                
                if cnt >= 1_000_000:
                    cnt_fmt = f"{cnt/1_000_000:.1f}M"
                elif cnt >= 10_000:
                    cnt_fmt = f"{cnt/1_000:.0f}k"
                elif cnt >= 1_000:
                    cnt_fmt = f"{cnt/1_000:.1f}k"
                else:
                    cnt_fmt = str(cnt)

                tooltip_text = f"{sym} ({tf})\nCandles: {cnt:,}\nStart: {s_dt} (Yr: {s_yr}, Mo: {s_mo})\nEnd: {e_dt} (Yr: {e_yr}, Mo: {e_mo})"
                cells.append(f'<td class="matrix-cell"><span class="cell-has-data tooltip" data-tooltip="{tooltip_text}">{cnt_fmt}</span></td>')
            else:
                cells.append('<td class="matrix-cell"><span class="cell-no-data">-</span></td>')

        html_content += f"""
            <tr class="matrix-row" data-symbol="{sym}">
              <td class="font-mono text-dim">{idx}</td>
              <td style="font-weight: 700; color: #60a5fa;">{sym}</td>
              <td class="font-mono text-dim" style="font-size: 11px;">{fyers_sym}</td>
              {" ".join(cells)}
              <td class="font-mono text-right" style="font-weight: 700;">{sym_total:,}</td>
            </tr>
        """

    html_content += f"""
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB 2: Full Detailed Inventory Table -->
  <div id="tab-inventory" class="tab-panel">
    <div class="filter-pills">
      <span style="font-size: 12px; color: var(--text-dim); margin-right: 4px;">Quick Filter:</span>
      <button class="filter-pill active" onclick="filterInventory('ALL', this)">All Records ({len(summary_records)})</button>
      <button class="filter-pill" onclick="filterInventory('AVAILABLE', this)">Available Only ({len(active_records)})</button>
      <button class="filter-pill" onclick="filterInventory('EMPTY', this)">Missing/Empty Only ({len(summary_records)-len(active_records)})</button>
      <button class="filter-pill" onclick="filterInventory('1D', this)">Daily 1D</button>
      <button class="filter-pill" onclick="filterInventory('1h', this)">Hourly 1h</button>
      <button class="filter-pill" onclick="filterInventory('15m', this)">15 Minutes</button>
      <button class="filter-pill" onclick="filterInventory('1m', this)">1 Minute Base</button>
      <button class="filter-pill" onclick="filterInventory('5S', this)">5 Seconds</button>
    </div>

    <div class="table-card">
      <div class="table-container">
        <table id="inventoryTable">
          <thead>
            <tr>
              <th onclick="sortTable('inventoryTable', 0)">Symbol</th>
              <th onclick="sortTable('inventoryTable', 1)">FYERS Symbol</th>
              <th onclick="sortTable('inventoryTable', 2)">Timeframe</th>
              <th onclick="sortTable('inventoryTable', 3)">Start Year</th>
              <th onclick="sortTable('inventoryTable', 4)">Start Month</th>
              <th onclick="sortTable('inventoryTable', 5)">Start Date</th>
              <th onclick="sortTable('inventoryTable', 6)">End Year</th>
              <th onclick="sortTable('inventoryTable', 7)">End Month</th>
              <th onclick="sortTable('inventoryTable', 8)">End Date</th>
              <th class="text-right" onclick="sortTable('inventoryTable', 9, true)">Candle Count</th>
              <th class="text-center" onclick="sortTable('inventoryTable', 10)">Status</th>
            </tr>
          </thead>
          <tbody>
    """

    for r in summary_records:
        status_cls = "available" if r["candle_count"] > 0 else "empty"
        html_content += f"""
            <tr class="inv-row" data-symbol="{r['symbol']}" data-tf="{r['timeframe']}" data-status="{r['status']}">
              <td style="font-weight: 700; color: #93c5fd;">{r['symbol']}</td>
              <td class="font-mono text-dim" style="font-size: 11px;">{r['fyers_symbol']}</td>
              <td class="font-mono" style="font-weight: 600; color: #38bdf8;">{r['timeframe']}</td>
              <td class="font-mono">{r['start_year']}</td>
              <td class="font-mono">{r['start_month']}</td>
              <td class="font-mono text-dim">{r['start_date']}</td>
              <td class="font-mono">{r['end_year']}</td>
              <td class="font-mono">{r['end_month']}</td>
              <td class="font-mono text-dim">{r['end_date']}</td>
              <td class="font-mono text-right" style="font-weight: 700;" data-value="{r['candle_count']}">{r['candle_count']:,}</td>
              <td class="text-center"><span class="status-badge {status_cls}">{r['status']}</span></td>
            </tr>
        """

    html_content += f"""
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- TAB 3: Fetch Gap Assistant -->
  <div id="tab-assistant" class="tab-panel">
    <div class="assistant-grid">
      <div class="assistant-card">
        <h3>⚡ Actionable Ingestion Commands</h3>
        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px;">
          Copy and run these commands to fetch <strong>only missing data</strong> without fetching existing data.
        </p>
    """

    if gap_data.get("recommended_commands"):
        for rc in gap_data["recommended_commands"]:
            html_content += f"""
        <div style="margin-bottom: 16px;">
          <div style="font-size: 12px; font-weight: 700; color: #f8fafc; margin-bottom: 4px;">{rc['title']}</div>
          <div class="cmd-box">
            <span class="cmd-text">{rc['cmd']}</span>
            <button class="copy-btn" onclick="copyCommand(this)">📋 Copy</button>
          </div>
        </div>
            """
    else:
        html_content += """
        <div style="padding: 16px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; color: #34d399;">
          ✓ Database has complete coverage across all selected timeframes. No additional ingestion required!
        </div>
        """

    html_content += f"""
      </div>

      <div class="assistant-card">
        <h3>⚠️ Gap & Start Date Analysis</h3>
        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 14px;">
          Summary of missing timeframe combinations and instruments with IPO/delayed start dates.
        </p>
        <div style="max-height: 420px; overflow-y: auto;">
          <div style="margin-bottom: 12px;">
            <div style="font-size: 12px; font-weight: 700; color: #fb7185;">Missing Timeframes:</div>
            <p style="font-size: 12px; color: var(--text-muted);">
              {len(gap_data.get('missing_timeframe_items', []))} timeframe-symbol combinations are not yet in database.
            </p>
          </div>
          <div>
            <div style="font-size: 12px; font-weight: 700; color: #f59e0b; margin-bottom: 6px;">Delayed Start Dates (Post-2017 IPOs):</div>
            <ul style="font-size: 12px; color: var(--text-muted); padding-left: 18px; line-height: 1.8;">
    """

    for p in gap_data.get("partial_date_items", []):
        html_content += f"<li><strong>{p['symbol']}</strong> ({p['timeframe']}): Starts at <code>{p['current_start']}</code></li>"

    html_content += """
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Toast for Copy Notification -->
<div id="toast">Command copied to clipboard!</div>

<script>
  function switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
    
    event.currentTarget.classList.add('active');
    document.getElementById('tab-' + tabId).classList.add('active');
  }

  function handleSearch() {
    const query = document.getElementById('globalSearch').value.toLowerCase().trim();

    // Filter Matrix
    document.querySelectorAll('.matrix-row').forEach(row => {
      const sym = row.getAttribute('data-symbol').toLowerCase();
      row.style.display = sym.includes(query) ? '' : 'none';
    });

    // Filter Inventory
    document.querySelectorAll('.inv-row').forEach(row => {
      const text = row.innerText.toLowerCase();
      row.style.display = text.includes(query) ? '' : 'none';
    });
  }

  function filterInventory(filter, btn) {
    document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
    if (btn) btn.classList.add('active');

    document.querySelectorAll('.inv-row').forEach(row => {
      const status = row.getAttribute('data-status');
      const tf = row.getAttribute('data-tf');

      if (filter === 'ALL') {
        row.style.display = '';
      } else if (filter === 'AVAILABLE' || filter === 'EMPTY') {
        row.style.display = (status === filter) ? '' : 'none';
      } else {
        row.style.display = (tf === filter) ? '' : 'none';
      }
    });
  }

  function copyCommand(btn) {
    const box = btn.closest('.cmd-box');
    const textEl = box.querySelector('.cmd-text');
    const text = textEl.innerText.trim();

    // 1. Create hidden textarea for 100% reliable copy on local file:// protocol
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    textarea.style.top = '0';
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();

    let success = false;
    try {
      success = document.execCommand('copy');
    } catch (err) {
      console.error('execCommand copy error:', err);
    }
    document.body.removeChild(textarea);

    // 2. Try modern clipboard API as secondary
    if (!success && navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => { success = true; });
    }

    // 3. Visual feedback on the button itself
    const originalHtml = btn.innerHTML;
    btn.innerHTML = '✓ Copied!';
    btn.style.background = '#10b981';
    btn.style.color = '#ffffff';
    btn.style.borderColor = '#10b981';

    // 4. Toast notification
    const toast = document.getElementById('toast');
    if (toast) {
      toast.innerText = 'Command copied to clipboard!';
      toast.style.display = 'block';
      setTimeout(() => { toast.style.display = 'none'; }, 2200);
    }

    // Reset button style after 2 seconds
    setTimeout(() => {
      btn.innerHTML = originalHtml;
      btn.style.background = '';
      btn.style.color = '';
      btn.style.borderColor = '';
    }, 2000);
  }

  let sortDirections = {};
  function sortTable(tableId, colIndex, isNumeric = false) {
    const table = document.getElementById(tableId);
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const isAsc = !sortDirections[colIndex];
    sortDirections[colIndex] = isAsc;

    // Reset header indicators
    table.querySelectorAll('th').forEach(th => {
      th.classList.remove('sort-asc', 'sort-desc');
    });
    table.querySelectorAll('th')[colIndex].classList.add(isAsc ? 'sort-asc' : 'sort-desc');

    rows.sort((a, b) => {
      const aCell = a.children[colIndex];
      const bCell = b.children[colIndex];

      let aVal = isNumeric ? parseFloat(aCell.getAttribute('data-value') || aCell.innerText.replace(/,/g, '')) || 0 : aCell.innerText.trim();
      let bVal = isNumeric ? parseFloat(bCell.getAttribute('data-value') || bCell.innerText.replace(/,/g, '')) || 0 : bCell.innerText.trim();

      if (aVal < bVal) return isAsc ? -1 : 1;
      if (aVal > bVal) return isAsc ? 1 : -1;
      return 0;
    });

    rows.forEach(r => tbody.appendChild(r));
  }
</script>

</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    # Also update latest HTML file for easy persistent bookmarking
    latest_path = os.path.join(os.path.dirname(os.path.abspath(output_path)), "latest_market_data_report.html")
    with open(latest_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"\n[EXPORT] Interactive HTML Report saved to:\n  -> {os.path.abspath(output_path)}")
    print(f"  -> {os.path.abspath(latest_path)}")


def main():
    parser = argparse.ArgumentParser(
        description="Generate Market Data Inventory and Gap Analysis Report from smm_trading.db"
    )
    parser.add_argument(
        "--db-path",
        default=DEFAULT_DB_PATH,
        help="Path to smm_trading.db SQLite database file"
    )
    parser.add_argument(
        "--watchlist",
        default=DEFAULT_WATCHLIST_PATH,
        help="Path to Nifty 50 Watchlist CSV file"
    )
    parser.add_argument(
        "--symbols", "-s",
        default="ALL",
        help="Comma-separated symbols or 'ALL' (e.g., INFY,TCS or NSE:RELIANCE-EQ)"
    )
    parser.add_argument(
        "--timeframes", "-t",
        default="ALL",
        help="Comma-separated timeframes or 'ALL' (e.g., 5S,10S,1m,5m,15m,1h,1D)"
    )
    parser.add_argument(
        "--breakdown", "-b",
        choices=["summary", "monthly", "yearly", "matrix", "missing", "all"],
        default="all",
        help="Report view mode: summary, monthly, yearly, matrix, missing, or all (default: all)"
    )
    parser.add_argument(
        "--export-html",
        nargs="?",
        const="",
        default="",
        help="Export report to interactive HTML. Optional file path or automatic timestamped filename (default: enabled)"
    )
    parser.add_argument(
        "--open", "--open-html",
        action="store_true",
        help="Automatically open the generated HTML report in the default web browser"
    )
    parser.add_argument(
        "--export-csv",
        nargs="?",
        const="",
        default=None,
        help="Export report to CSV. Optional file path or automatic timestamped filename"
    )
    parser.add_argument(
        "--export-md",
        nargs="?",
        const="",
        default=None,
        help="Export report to Markdown. Optional file path or automatic timestamped filename"
    )
    parser.add_argument(
        "--target-start-date",
        default="2017-07-03",
        help="Expected historical start date for gap analysis (default: 2017-07-03)"
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=16,
        help="Concurrency thread worker count for database lookups (default: 16)"
    )

    args = parser.parse_args()

    if not os.path.exists(args.db_path):
        print(f"[ERROR] Database file not found: {args.db_path}", file=sys.stderr)
        sys.exit(1)

    t_start = time.time()
    conn = get_db_connection(args.db_path)

    try:
        all_instruments = get_instruments(conn)
        if not all_instruments:
            print("[WARNING] No instruments found in database table 'instruments'.", file=sys.stderr)
            sys.exit(0)

        # Parse filter symbols
        if args.symbols.strip().upper() == "ALL":
            selected_instruments = all_instruments
        else:
            raw_syms = [s.strip().upper() for s in args.symbols.split(",") if s.strip()]
            selected_instruments = []
            for inst in all_instruments:
                sym_clean = inst["symbol"].upper()
                fyers_clean = inst.get("fyers_symbol", "").upper()
                if any(s in [sym_clean, fyers_clean] or s == sym_clean.replace("NSE:", "").replace("-EQ", "") for s in raw_syms):
                    selected_instruments.append(inst)

            if not selected_instruments:
                print(f"[WARNING] No instruments matched filter symbols: {args.symbols}", file=sys.stderr)
                sys.exit(0)

        # Parse filter timeframes
        if args.timeframes.strip().upper() == "ALL":
            selected_timeframes = ALL_TIMEFRAMES
        else:
            selected_timeframes = [t.strip() for t in args.timeframes.split(",") if t.strip()]

        watchlist_symbols = load_nifty50_watchlist(args.watchlist)

        print("=" * 105)
        print("  SMM TRADING PLATFORM - MARKET DATA INVENTORY INSPECTOR")
        print("=" * 105)
        print(f"Database File     : {os.path.abspath(args.db_path)} ({os.path.getsize(args.db_path)/(1024**3):.2f} GB)")
        print(f"Instruments Count : {len(selected_instruments)} / {len(all_instruments)} total")
        print(f"Timeframes        : {', '.join(selected_timeframes)}")
        print(f"Report Mode       : {args.breakdown.upper()}")
        print(f"Target Start Date : {args.target_start_date}")
        print("=" * 105)

        # Fast multithreaded summary query (sub-2 seconds for full 50x14 matrix)
        summary_records = query_summary_coverage_fast(
            args.db_path,
            selected_instruments,
            selected_timeframes,
            max_workers=args.workers
        )

        monthly_records = None
        if args.breakdown in ["monthly"]:
            monthly_records = query_monthly_coverage_fast(
                args.db_path,
                summary_records,
                max_workers=args.workers
            )

        yearly_records = None
        if args.breakdown in ["yearly"]:
            yearly_records = query_yearly_coverage_fast(
                args.db_path,
                summary_records,
                max_workers=args.workers
            )

        # Render console views
        if args.breakdown in ["summary", "all"]:
            print_summary_view(summary_records)

        if args.breakdown in ["matrix", "all"]:
            print_matrix_view(selected_instruments, summary_records, selected_timeframes)

        if args.breakdown in ["monthly"]:
            if monthly_records:
                print_monthly_view(monthly_records)

        if args.breakdown in ["yearly"]:
            if yearly_records:
                print_yearly_view(yearly_records)

        gap_data = analyze_missing_data(
            watchlist_symbols,
            selected_instruments,
            summary_records,
            selected_timeframes,
            target_start_date=args.target_start_date
        )

        # Handle file exports
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")

        # HTML Export (Default enabled)
        html_path = None
        if args.export_html is not None:
            html_path = args.export_html if args.export_html else os.path.join(REPORTS_DIR, f"market_data_inventory_{timestamp_str}.html")
            export_html_report(args.db_path, selected_instruments, summary_records, monthly_records, selected_timeframes, gap_data, html_path)

        if args.export_csv is not None:
            csv_path = args.export_csv if args.export_csv else os.path.join(REPORTS_DIR, f"market_data_inventory_{timestamp_str}.csv")
            export_csv_report(summary_records, csv_path)

        if args.export_md is not None:
            md_path = args.export_md if args.export_md else os.path.join(REPORTS_DIR, f"market_data_inventory_{timestamp_str}.md")
            export_markdown_report(selected_instruments, summary_records, selected_timeframes, md_path)

        if args.open and html_path and os.path.exists(html_path):
            webbrowser.open(f"file:///{os.path.abspath(html_path).replace(os.sep, '/')}")

        print(f"\n[DONE] Report execution finished in {time.time() - t_start:.2f} seconds.")

    finally:
        conn.close()


if __name__ == "__main__":
    main()
