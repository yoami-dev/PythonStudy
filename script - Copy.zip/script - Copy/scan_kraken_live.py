#!/usr/bin/env python3
"""
===============================================================================
 KRAKEN NIFTY 50 REAL-TIME SCANNER & ALERT DAEMON
===============================================================================
 Location: D:\\Milind\\MyTradingPlatform\\script\\scan_kraken_live.py

 Scans all Nifty 50 instruments in the background without needing manual charts.
 Triggers audio sound and terminal alerts whenever a KRAKEN setup is detected.

 Usage:
   python script/scan_kraken_live.py
   python script/scan_kraken_live.py --loop --interval 60
   python script/scan_kraken_live.py --timeframe 5m --rr 3.0 --t1 1.2
===============================================================================
"""

import os
import sys
import time
import sqlite3
import argparse
from datetime import datetime, timezone, timedelta

# Ensure project root is on sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.strategies.impl.kraken_strategy import KrakenStrategyEngine, IST_TZ
from app.market_data.resampler.resampler import CandleResampler

try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    HAS_WINSOUND = False

DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")


def play_alert_chime():
    if HAS_WINSOUND:
        try:
            winsound.Beep(1200, 200)
            winsound.Beep(1600, 300)
        except Exception:
            pass


def scan_all_symbols(engine: KrakenStrategyEngine, timeframe: str = "5m", lookback_days: int = 4):
    if not os.path.exists(DB_PATH):
        print(f"[ERROR] Database file not found at: {DB_PATH}")
        return

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT id, symbol FROM instruments WHERE active = 1 ORDER BY symbol ASC")
    inst_rows = cursor.fetchall()

    now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
    print(f"\n[{now_ist.strftime('%Y-%m-%d %H:%M:%S IST')}] Scanning {len(inst_rows)} Nifty instruments for KRAKEN setups...")

    start_date_str = (now_ist - timedelta(days=lookback_days)).strftime("%Y-%m-%d 00:00:00")
    active_alerts = []

    for row in inst_rows:
        inst_id = row["id"]
        sym = row["symbol"].replace("NSE:", "").replace("-EQ", "")

        cursor.execute(
            """
            SELECT candle_timestamp, open, high, low, close, volume
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= ?
            ORDER BY candle_timestamp ASC
            """,
            (inst_id, start_date_str)
        )
        c_1m = [dict(r) for r in cursor.fetchall()]
        if not c_1m or len(c_1m) < 60:
            continue

        if timeframe != "1m":
            candles = CandleResampler.resample_1m_candles(c_1m, timeframe)
        else:
            candles = c_1m

        if len(candles) < 30:
            continue

        curr_price = float(candles[-1]["close"])
        result = engine.evaluate(
            symbol=sym,
            instrument="NSE_EQ",
            current_price=curr_price,
            candles=candles,
            timeframe=timeframe
        )

        if result.get("status") == "VALID":
            active_alerts.append((sym, result, candles[-1]))

    conn.close()

    if active_alerts:
        play_alert_chime()
        print("\n" + "=" * 80)
        print(f" 🚨 KRAKEN ALERTS DETECTED ({len(active_alerts)} SETUPS FOUND)")
        print("=" * 80)
        for sym, res, last_c in active_alerts:
            dir_str = res["direction"]
            ev = res.get("evidence", {})
            c_time = str(last_c.get("candle_timestamp"))[:19]
            print(f" • [{dir_str}] {sym:<12} @ {c_time} | Entry: {res['entry_price']:.2f} | "
                  f"SL: {res['stop_loss_price']:.2f} | T1 (+1.2R): {res['t1_target_price']:.2f} | "
                  f"T2 (+3.0R): {res['target_price']:.2f} | RVOL: {ev.get('rvol', 1.0):.2f}x")
            print(f"   Reason: {res.get('explanation')}")
        print("=" * 80 + "\n")
    else:
        print(f" [OK] Scan complete. No active KRAKEN setups at this moment.")


def main():
    parser = argparse.ArgumentParser(description="KRAKEN Real-Time Scanner & Alert Engine")
    parser.add_argument("--timeframe", type=str, default="5m", help="Candle timeframe (default: 5m)")
    parser.add_argument("--rr", type=float, default=3.0, help="T2 Risk-to-Reward (default: 3.0)")
    parser.add_argument("--t1", type=float, default=1.2, help="T1 Lock-in R:R (default: 1.2)")
    parser.add_argument("--loop", action="store_true", help="Run continuously in a loop")
    parser.add_argument("--interval", type=int, default=60, help="Scan interval in seconds for loop mode")
    args = parser.parse_args()

    engine = KrakenStrategyEngine(target_rr=args.rr, t1_rr=args.t1)

    print("===============================================================================")
    print(" KRAKEN NIFTY 50 REAL-TIME SCANNER & ALERT DAEMON")
    print(f" Timeframe: {args.timeframe} | Target 1: +{args.t1:.1f}R | Target 2: +{args.rr:.1f}R")
    print("===============================================================================")

    if args.loop:
        print(f"[INFO] Running in background loop (Interval: {args.interval}s). Press Ctrl+C to exit.")
        try:
            while True:
                scan_all_symbols(engine, timeframe=args.timeframe)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n[INFO] Scanner daemon stopped by user.")
    else:
        scan_all_symbols(engine, timeframe=args.timeframe)


if __name__ == "__main__":
    main()
