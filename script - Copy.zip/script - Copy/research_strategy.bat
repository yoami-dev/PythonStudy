@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Multi-Strategy Historical Research CLI (Batch)
:: Location: E:\Milind\MyTradingPlatform\script\research_strategy.bat
:: ============================================================================
::
:: Evaluates historical strategy details and outcome resolutions for:
:: SMM, PAPA, FOME, GUE, SMC
::
:: Usage Examples:
::   research_strategy.bat -Symbol INFY -Timeframe 15m
::   research_strategy.bat -Symbol TCS -Timeframe 15m -Open
::   research_strategy.bat -Symbol RELIANCE -Timeframe 1m -Strategies ALL
::   research_strategy.bat -Symbol INFY -Timeframe 15m -StartDate 2026-09-01 -StartTime 09:30 -Open
::   research_strategy.bat -Preset TARGET_FIRST -Open
:: ============================================================================

title SMM Trading Platform - Strategy Historical Research

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%research_strategy.ps1" %*

endlocal
