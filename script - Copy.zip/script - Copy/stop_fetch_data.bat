@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Stop Background Data Fetcher (Batch)
:: Location: D:\Milind\MyTradingPlatform\script\stop_fetch_data.bat
:: ============================================================================

title SMM Trading Platform - Stop Fetcher

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%stop_fetch_data.ps1" %*

endlocal
