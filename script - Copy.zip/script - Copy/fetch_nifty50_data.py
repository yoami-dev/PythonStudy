#!/usr/bin/env python3
"""
================================================================================
SMM Trading Platform - Automated Nifty 50 Historical Data Fetcher
Location: D:\\Milind\\MyTradingPlatform\\script\\fetch_nifty50_data.py
================================================================================

Fetches and persists historical market data for all Nifty 50 instruments into
the SQLite database 'smm_trading.db' across FYERS native timeframes:
  1. Seconds: 5S, 10S
  2. Minutes: 1, 2, 3, 4, 5, 15, 30, 60 (passed as integer strings or canonical format)
  3. Daily: D / 1D

Usage:
  python script/fetch_nifty50_data.py
  python script/fetch_nifty50_data.py --timeframes 5S,10S,1,5,15,60,1D
  python script/fetch_nifty50_data.py --symbols NSE:INFY-EQ,NSE:TCS-EQ --timeframes 1,5,1D
  python script/fetch_nifty50_data.py --start-date 2024-01-01 --end-date 2026-09-06
"""

import os
import sys
import argparse
import asyncio
import logging
import signal
from datetime import datetime, timezone, timedelta
from typing import List, Optional

# Ensure project root is on sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.db.session import AsyncSessionLocal
from app.auth.fyers.token_manager import FyersTokenManager
from app.universe.watchlist_parser import WatchlistParser
from app.market_data.services.nifty50_importer import Nifty50HistoricalImporter
from app.market_data.timeframe import (
    normalize_timeframe_code,
    get_fyers_resolution,
    FYERS_NATIVE_RESOLUTIONS
)
from app.utils.datetime_utils import utc_now
from app.market_data.normalization.fyers_normalizer import FyersMarketDataNormalizer

DEFAULT_WATCHLIST = os.path.join(PROJECT_ROOT, "Prompts", "Watchlist_Nifty 50_2026-08-24.csv")
PID_FILE = os.path.join(PROJECT_ROOT, "script", ".fetch_data.pid")
LOG_FILE = os.path.join(PROJECT_ROOT, "script", "fetch_data.log")

# Setup Logging
logger = logging.getLogger("fetch_nifty50_data")


def setup_logger(log_file_path: str):
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # Console handler (if stdout is attached)
    if sys.stdout is not None:
        try:
            ch = logging.StreamHandler(sys.stdout)
            ch.setLevel(logging.INFO)
            ch.setFormatter(formatter)
            logger.addHandler(ch)
        except Exception:
            pass

    # File handler (always log to file with auto-flush)
    class AutoFlushFileHandler(logging.FileHandler):
        def emit(self, record):
            super().emit(record)
            self.flush()

    os.makedirs(os.path.dirname(log_file_path), exist_ok=True)
    fh = AutoFlushFileHandler(log_file_path, mode="a", encoding="utf-8")
    fh.setLevel(logging.INFO)
    fh.setFormatter(formatter)
    logger.addHandler(fh)


def write_pid_file(pid_path: str):
    try:
        with open(pid_path, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except Exception as e:
        logger.warning(f"Could not write PID file: {e}")


def remove_pid_file(pid_path: str):
    try:
        if os.path.exists(pid_path):
            os.remove(pid_path)
    except Exception:
        pass


class BackgroundDataFetcher:
    def __init__(
        self,
        timeframes: List[str],
        symbols: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        concurrency: int = 3,
        watchlist_file: str = DEFAULT_WATCHLIST
    ):
        self.raw_timeframes = timeframes
        self.symbols = symbols
        self.start_date = start_date
        self.end_date = end_date or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        self.concurrency = concurrency
        self.watchlist_file = watchlist_file
        self.is_running = True

    async def verify_auth(self) -> bool:
        """Ensure a valid FYERS access token is available in smm_trading.db."""
        async with AsyncSessionLocal() as session:
            token_mgr = FyersTokenManager(session)
            token = await token_mgr.get_valid_access_token()
            if not token:
                logger.error("FYERS authentication token missing or expired in database.")
                logger.error("Please login to FYERS via the Dashboard UI (http://127.0.0.1:8000/) first.")
                return False

            health = await token_mgr.check_connection_health(token)
            if not health.get("healthy"):
                logger.error(f"FYERS token connection health check failed: {health.get('error')}")
                return False

            logger.info("FYERS Authentication verified successfully.")
            return True

    def resolve_universe(self) -> List[str]:
        """Resolve Nifty 50 universe symbols from CSV."""
        if self.symbols and self.symbols != ["ALL"]:
            canonical_syms = [FyersMarketDataNormalizer.to_canonical_symbol(s) for s in self.symbols if s and s.strip()]
            return list(dict.fromkeys(canonical_syms))

        if not os.path.exists(self.watchlist_file):
            raise FileNotFoundError(f"Watchlist file not found at: {self.watchlist_file}")

        parse_result = WatchlistParser.parse_fyers_watchlist_csv(self.watchlist_file)
        all_syms = parse_result.all_symbols
        logger.info(f"Loaded {len(all_syms)} instruments from {os.path.basename(self.watchlist_file)} (1 Index + {parse_result.actual_count} constituents).")
        return all_syms

    async def run(self):
        """Execute historical backfill across all specified timeframes."""
        if not await self.verify_auth():
            sys.exit(1)

        instruments = self.resolve_universe()
        total_timeframes = len(self.raw_timeframes)

        logger.info("=" * 80)
        logger.info(f"STARTING NIFTY 50 HISTORICAL DATA INGESTION ENGINE")
        logger.info(f"Total Instruments : {len(instruments)}")
        logger.info(f"Requested Intervals: {', '.join(self.raw_timeframes)}")
        logger.info(f"Target End Date   : {self.end_date}")
        logger.info(f"Concurrency Limit : {self.concurrency}")
        logger.info("=" * 80)

        importer = Nifty50HistoricalImporter(concurrency_limit=self.concurrency)
        today_utc = datetime.now(timezone.utc)

        grand_total_received = 0
        grand_total_inserted = 0
        grand_total_duplicates = 0
        failed_jobs = []

        for idx, raw_tf in enumerate(self.raw_timeframes, 1):
            if not self.is_running:
                logger.info("Fetch process received stop signal. Aborting subsequent timeframes.")
                break

            tf_norm = normalize_timeframe_code(raw_tf)
            logger.info("-" * 80)
            logger.info(f"[{idx}/{total_timeframes}] Processing Timeframe: '{raw_tf}' (Canonical: '{tf_norm}')")

            # Check if FYERS supports this resolution natively
            try:
                res_code = get_fyers_resolution(raw_tf)
            except ValueError as ve:
                logger.error(f"Timeframe '{raw_tf}' unsupported: {ve}")
                continue

            # Special case for "4" / "4m": FYERS API v3 documentation & live endpoint reject resolution "4"
            if res_code == "4" or tf_norm == "4m":
                logger.warning(
                    f"[FYERS_NOTICE] Resolution '4' (4-minute) is not supported natively by FYERS API v3 "
                    f"(supported native resolutions: 5S, 10S, 15S, 30S, 45S, 1, 2, 3, 5, 10, 15, 20, 30, 45, 60, 120, 180, 240, 1D, 1W, 1M). "
                    f"Skipping 4m to comply with Step 4.67G native-candles architecture without silent resampling."
                )
                continue

            # Calculate date boundaries for this timeframe
            tf_start = self.start_date
            if tf_norm.endswith("S"):
                # Seconds interval: FYERS only provides historical seconds data for the last 30 days
                max_seconds_history_days = 29
                earliest_seconds_date = (today_utc - timedelta(days=max_seconds_history_days)).strftime("%Y-%m-%d")
                if not tf_start or tf_start < earliest_seconds_date:
                    logger.info(
                        f"[SECONDS_CLAMP] FYERS API limits seconds historical data to 30 days. "
                        f"Clamping start date for '{tf_norm}' to: {earliest_seconds_date}"
                    )
                    tf_start = earliest_seconds_date
            else:
                if not tf_start:
                    tf_start = "2017-07-03"  # Standard default platform historical start date

            logger.info(f"Launching import job for '{tf_norm}': range {tf_start} to {self.end_date} across {len(instruments)} instruments...")

            try:
                job_info = await importer.create_import_job(
                    watchlist_file=self.watchlist_file,
                    timeframe=tf_norm,
                    start_date=tf_start,
                    end_date=self.end_date,
                    symbols=instruments
                )
                job_id = job_info["job_id"]
                job_code = job_info["job_code"]
                total_chunks = job_info["total_chunks"]

                logger.info(f"Created Job #{job_id} ({job_code}) with {total_chunks} total chunks.")

                # Execute Job
                job_result = await importer.execute_import_job(job_id)

                status = job_result.get("status", "UNKNOWN")
                rcvd = job_result.get("rows_received", 0)
                ins = job_result.get("rows_inserted", 0)
                dups = job_result.get("duplicates", 0)
                failed = job_result.get("failed_chunks", 0)

                grand_total_received += rcvd
                grand_total_inserted += ins
                grand_total_duplicates += dups

                if status in ["FAILED", "PARTIAL"]:
                    failed_jobs.append((job_id, tf_norm, status))

                logger.info(
                    f"Completed Job #{job_id} ({tf_norm}): Status={status} | "
                    f"Candles Received={rcvd:,} | Inserted={ins:,} | Duplicates={dups:,} | Failed Chunks={failed}"
                )

            except Exception as e:
                logger.error(f"Error executing import job for timeframe '{raw_tf}': {e}", exc_info=True)
                failed_jobs.append((-1, raw_tf, str(e)))

        logger.info("=" * 80)
        logger.info("HISTORICAL DATA INGESTION ENGINE RUN SUMMARY")
        logger.info(f"Grand Total Candles Received  : {grand_total_received:,}")
        logger.info(f"Grand Total Candles Inserted  : {grand_total_inserted:,}")
        logger.info(f"Grand Total Duplicate Candles : {grand_total_duplicates:,}")
        if failed_jobs:
            logger.warning(f"Jobs with warnings/failures: {failed_jobs}")
        else:
            logger.info("All requested timeframes completed successfully!")
        logger.info("=" * 80)


def main():
    parser = argparse.ArgumentParser(description="Fetch and store Nifty 50 historical data into smm_trading.db.")
    parser.add_argument(
        "-t", "--timeframes",
        type=str,
        default="5S,10S,1,2,3,4,5,15,30,60,1D",
        help="Comma-separated list of timeframes (e.g. '5S,10S,1,2,3,4,5,15,30,60,1D')."
    )
    parser.add_argument(
        "-s", "--symbols",
        type=str,
        default="ALL",
        help="Comma-separated list of symbols (e.g. 'NSE:INFY-EQ,NSE:TCS-EQ') or 'ALL' for Nifty 50 universe."
    )
    parser.add_argument(
        "--start-date",
        type=str,
        default=None,
        help="Start date YYYY-MM-DD (defaults to 2017-07-03 for minutes/daily; clamped to 29 days for seconds)."
    )
    parser.add_argument(
        "--end-date",
        type=str,
        default=None,
        help="End date YYYY-MM-DD (defaults to current date)."
    )
    parser.add_argument(
        "-c", "--concurrency",
        type=int,
        default=3,
        help="Concurrency limit for API requests (default: 3)."
    )
    parser.add_argument(
        "--watchlist",
        type=str,
        default=DEFAULT_WATCHLIST,
        help="Path to Nifty 50 watchlist CSV file."
    )
    parser.add_argument(
        "--log-file",
        type=str,
        default=LOG_FILE,
        help="Path to output log file."
    )

    args = parser.parse_args()

    setup_logger(args.log_file)
    write_pid_file(PID_FILE)

    if args.timeframes.strip().upper() == "ALL":
        timeframes_list = ["5S", "10S", "1", "2", "3", "5", "10", "15", "20", "30", "60", "120", "240", "1D"]
    else:
        raw_list = [tf.strip() for tf in args.timeframes.split(",") if tf.strip()]
        if any(tf.upper() == "ALL" for tf in raw_list):
            timeframes_list = ["5S", "10S", "1", "2", "3", "5", "10", "15", "20", "30", "60", "120", "240", "1D"]
        else:
            timeframes_list = raw_list

    symbols_list = None if args.symbols.strip().upper() == "ALL" else [s.strip() for s in args.symbols.split(",") if s.strip()]

    fetcher = BackgroundDataFetcher(
        timeframes=timeframes_list,
        symbols=symbols_list,
        start_date=args.start_date,
        end_date=args.end_date,
        concurrency=args.concurrency,
        watchlist_file=args.watchlist
    )

    def sig_handler(signum, frame):
        logger.info(f"Received termination signal ({signum}). Initiating graceful stop...")
        fetcher.is_running = False

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    try:
        asyncio.run(fetcher.run())
    finally:
        remove_pid_file(PID_FILE)


if __name__ == "__main__":
    main()
