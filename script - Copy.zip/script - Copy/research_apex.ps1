# ===============================================================================
#  APEX TRADING STRATEGY (>= 80% WIN RATE) — POWERSHELL RUNNER
# ===============================================================================

param (
    [string]$Symbol = "ALL",
    [string]$Timeframe = "5m",
    [string]$StartDate = "2026-09-01",
    [string]$StartTime = "09:30",
    [string]$EndDate = $null,
    [string]$DbPath = "$PSScriptRoot\..\smm_trading.db",
    [switch]$Open
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path "$ScriptDir\.."

$PyExe = "$ProjectRoot\venv\Scripts\python.exe"
if (-not (Test-Path $PyExe)) {
    $PyExe = "python"
}

$PyArgs = @(
    "-u",
    "$ScriptDir\discover_apex_strategy.py",
    "-Symbol", $Symbol,
    "-Timeframe", $Timeframe,
    "-StartDate", $StartDate,
    "-StartTime", $StartTime,
    "-DbPath", $DbPath
)

if ($EndDate) {
    $PyArgs += @("-EndDate", $EndDate)
}

if ($Open) {
    $PyArgs += "-Open"
}

Write-Host "Running APEX Strategy Discovery..." -ForegroundColor Cyan
& $PyExe @PyArgs
