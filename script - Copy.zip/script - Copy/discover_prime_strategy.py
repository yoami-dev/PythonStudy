#!/usr/bin/env python3
"""
===============================================================================
 PRIME STRATEGY DISCOVERY & HISTORICAL BACKTESTING ENGINE
===============================================================================
 Executes multi-year backtesting across the Nifty 50 universe to validate the
 high-probability PRIME (Institutional Liquidity Sweep & MSS) strategy.
 Computes Win Rate %, Profit Factor, Net R, Expectancy, and produces an interactive
 visual discovery HTML report.
"""

import os
import sys
import argparse
import logging
import json
import sqlite3
from datetime import datetime, timezone, timedelta
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import List, Dict, Any, Optional, Tuple

# Configure UTF-8 encoding for Windows terminals
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.market_data.resampler.resampler import CandleResampler
from app.market_data.timeframe import normalize_timeframe_code
from app.strategies.impl.prime_strategy import PrimeStrategyEngine
from app.strategies.contracts import StrategyInputContext, StrategyResultStatus
from app.strategies.adapters.prime_adapter import PrimeStrategyAdapter
from app.utils.datetime_utils import ensure_utc

DEFAULT_DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "script", "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)


class Term:
    BOLD = "\033[1m"
    GREEN = "\033[92m"
    RED = "\033[91m"
    YELLOW = "\033[93m"
    CYAN = "\033[96m"
    MAGENTA = "\033[95m"
    DIM = "\033[2m"
    RESET = "\033[0m"


def get_db_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{os.path.abspath(db_path)}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def find_instrument(conn: sqlite3.Connection, symbol: str) -> Dict[str, Any]:
    c = conn.cursor()
    sym_clean = symbol.strip().upper()
    c.execute(
        "SELECT id, symbol, display_name, exchange, fyers_symbol FROM instruments WHERE UPPER(symbol) = ? OR UPPER(fyers_symbol) = ?",
        (sym_clean, sym_clean)
    )
    row = c.fetchone()
    if row:
        return dict(row)
    c.execute(
        "SELECT id, symbol, display_name, exchange, fyers_symbol FROM instruments WHERE UPPER(symbol) LIKE ? OR UPPER(fyers_symbol) LIKE ?",
        (f"%{sym_clean}%", f"%{sym_clean}%")
    )
    row = c.fetchone()
    if row:
        return dict(row)
    raise ValueError(f"Instrument '{symbol}' not found in database.")


def parse_db_timestamp(ts: Any) -> datetime:
    if isinstance(ts, datetime):
        return ensure_utc(ts)
    if isinstance(ts, str):
        ts_clean = ts.replace("Z", "+00:00")
        if "+" not in ts_clean and "-" not in ts_clean[10:]:
            ts_clean += "+00:00"
        try:
            return datetime.fromisoformat(ts_clean)
        except Exception:
            pass
    return ensure_utc(datetime.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S"))


def backtest_prime_single_symbol(
    symbol: str,
    db_path: str = DEFAULT_DB_PATH,
    timeframe: str = "5m",
    start_date: str = "2026-09-01",
    start_time: str = "09:30:00",
    end_date: Optional[str] = None,
    future_candles_count: int = 30,
    cached_1m_candles: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """
    Runs systematic historical backtest of PRIME on a single symbol.
    """
    tf_clean = normalize_timeframe_code(timeframe)
    engine = PrimeStrategyEngine(volume_multiplier=1.05, target_rr_ratio=1.25)
    adapter = PrimeStrategyAdapter(engine=engine)

    if cached_1m_candles is not None and len(cached_1m_candles) > 0:
        all_1m_rows = cached_1m_candles
        inst_key = f"NSE:{symbol.upper()}-EQ"
    else:
        conn = get_db_connection(db_path)
        inst_info = find_instrument(conn, symbol)
        inst_id = inst_info["id"]
        inst_key = inst_info["symbol"]

        c = conn.cursor()
        c.execute(
            """
            SELECT candle_timestamp, open, high, low, close, volume
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = '1m'
            ORDER BY candle_timestamp ASC
            """,
            (inst_id,)
        )
        all_1m_rows = [dict(r) for r in c.fetchall()]
        conn.close()

    if not all_1m_rows:
        return {"symbol": symbol, "total_trades": 0, "target_hits": 0, "sl_hits": 0, "unresolved": 0, "trades": [], "win_rate": 0.0}

    # Resample 1m candles into execution timeframe (e.g. 5m)
    resampled_exec = CandleResampler.resample_1m_candles(all_1m_rows, tf_clean)

    # Date filter
    eff_start_date = start_date.strip() if start_date else "2017-07-03"
    eff_start_time = start_time.strip() if start_time else "09:30:00"
    if len(eff_start_time.split(":")) == 2:
        eff_start_time += ":00"
    eval_start_dt = datetime.fromisoformat(f"{eff_start_date}T{eff_start_time}+05:30").astimezone(timezone.utc)

    eval_end_dt = None
    if end_date and str(end_date).strip():
        eval_end_dt = datetime.fromisoformat(f"{str(end_date).strip()}T15:30:00+05:30").astimezone(timezone.utc)

    raw_1m_ts = [parse_db_timestamp(r["candle_timestamp"]) for r in all_1m_rows]
    import bisect

    trades = []
    cooldown_until_idx = -1

    for idx in range(30, len(resampled_exec)):
        cand = resampled_exec[idx]
        ts = parse_db_timestamp(cand["candle_timestamp"])

        if ts < eval_start_dt:
            continue
        if eval_end_dt and ts > eval_end_dt:
            break
        if idx < cooldown_until_idx:
            continue

        # Lookback slice (last 500 candles in timeframe for full multi-day & session context)
        slice_start = max(0, idx - 500)
        ctx_candles = resampled_exec[slice_start : idx + 1]

        context = StrategyInputContext(
            instrument=inst_key,
            symbol=symbol,
            timeframe=tf_clean,
            current_price=float(cand["close"]),
            evaluation_timestamp=ts,
            candles=ctx_candles,
        )

        res = adapter.evaluate(context)

        if res.status == StrategyResultStatus.VALID and res.entry_price and res.stop_loss_price and res.target_price:
            entry_p = res.entry_price
            sl_p = res.stop_loss_price
            target_p = res.target_price
            direction = res.direction

            # Track future 1m candles for outcome resolution
            pos_1m = bisect.bisect_right(raw_1m_ts, ts)
            future_slice = all_1m_rows[pos_1m : pos_1m + (future_candles_count * 15)]

            outcome = "UNRESOLVED"
            exit_price = None
            exit_ts = None
            bars_held = 0

            for fut_c in future_slice:
                bars_held += 1
                f_h = float(fut_c["high"])
                f_l = float(fut_c["low"])
                f_ts = fut_c["candle_timestamp"]

                if direction == "LONG":
                    # Check Target hit first or SL hit
                    if f_h >= target_p:
                        outcome = "TARGET_HIT"
                        exit_price = target_p
                        exit_ts = f_ts
                        break
                    elif f_l <= sl_p:
                        outcome = "SL_HIT"
                        exit_price = sl_p
                        exit_ts = f_ts
                        break
                elif direction == "SHORT":
                    if f_l <= target_p:
                        outcome = "TARGET_HIT"
                        exit_price = target_p
                        exit_ts = f_ts
                        break
                    elif f_h >= sl_p:
                        outcome = "SL_HIT"
                        exit_price = sl_p
                        exit_ts = f_ts
                        break

            risk = abs(entry_p - sl_p)
            reward = abs(target_p - entry_p)
            rr_ratio = round(reward / risk, 2) if risk > 0 else 1.80

            trade_rec = {
                "symbol": symbol,
                "candle_timestamp": str(cand.get("candle_timestamp") or cand.get("timestamp")),
                "direction": direction,
                "entry_price": round(entry_p, 2),
                "stop_loss_price": round(sl_p, 2),
                "target_price": round(target_p, 2),
                "risk_reward": rr_ratio,
                "outcome": outcome,
                "exit_price": round(exit_price, 2) if exit_price else None,
                "exit_timestamp": exit_ts,
                "bars_held": bars_held,
                "setup": res.evidence.get("setup", "PRIME_LIQUIDITY_SWEEP"),
                "sweep_level": res.evidence.get("sweep_level", ""),
                "volume_ratio": res.evidence.get("volume_ratio", 1.0),
                "vwap": res.evidence.get("vwap", 0.0),
            }
            trades.append(trade_rec)

            # Deduplication cooldown (jump ahead 6 execution candles)
            cooldown_until_idx = idx + 6

    target_hits = sum(1 for t in trades if t["outcome"] == "TARGET_HIT")
    sl_hits = sum(1 for t in trades if t["outcome"] == "SL_HIT")
    unresolved = sum(1 for t in trades if t["outcome"] == "UNRESOLVED")
    tot_resolved = target_hits + sl_hits
    win_rate = (target_hits / tot_resolved * 100.0) if tot_resolved > 0 else 0.0

    return {
        "symbol": symbol,
        "total_trades": len(trades),
        "target_hits": target_hits,
        "sl_hits": sl_hits,
        "unresolved": unresolved,
        "win_rate": round(win_rate, 2),
        "trades": trades,
    }


def _worker_symbol_backtest(args: tuple) -> Dict[str, Any]:
    symbol, db_path, timeframe, start_date, start_time, end_date, future_candles, cached_candles = args
    return backtest_prime_single_symbol(
        symbol=symbol,
        db_path=db_path,
        timeframe=timeframe,
        start_date=start_date,
        start_time=start_time,
        end_date=end_date,
        future_candles_count=future_candles,
        cached_1m_candles=cached_candles,
    )


def run_universe_prime_discovery(
    symbols: List[str],
    timeframe: str = "5m",
    start_date: str = "2026-09-01",
    start_time: str = "09:30:00",
    end_date: Optional[str] = None,
    db_path: str = DEFAULT_DB_PATH,
    max_workers: int = 6,
) -> Dict[str, Any]:
    """Runs PRIME discovery backtest across all specified symbols."""
    print(f"\n{Term.BOLD}{Term.CYAN}Initializing PRIME Strategy Discovery & Universe Backtest...{Term.RESET}", flush=True)
    print(f"  {Term.BOLD}Symbols ({len(symbols)}):{Term.RESET} {', '.join(symbols[:8])}{'...' if len(symbols) > 8 else ''}", flush=True)
    print(f"  {Term.BOLD}Timeframe:{Term.RESET} {timeframe} | {Term.BOLD}Period:{Term.RESET} {start_date} {start_time} to {end_date or 'Latest'}", flush=True)
    print(f"  {Term.BOLD}Target R:R Ratio:{Term.RESET} 1:1.80 | {Term.BOLD}Required Target Win Rate:{Term.RESET} >= 70.0%\n", flush=True)

    # Preload symbol 1m candles into RAM (windowed)
    print(f"  {Term.DIM}Preloading historical candles for {len(symbols)} symbols into RAM...{Term.RESET}", flush=True)
    conn = get_db_connection(db_path)
    candle_cache = {}
    eff_start_date = start_date.strip() if start_date else "2017-07-03"
    eff_start_time = start_time.strip() if start_time else "09:30:00"
    if len(eff_start_time.split(":")) == 2:
        eff_start_time += ":00"
    eval_start_dt_utc = datetime.fromisoformat(f"{eff_start_date}T{eff_start_time}+05:30").astimezone(timezone.utc)
    eval_start_str = eval_start_dt_utc.strftime("%Y-%m-%d %H:%M:%S")

    for sym in symbols:
        try:
            inst = find_instrument(conn, sym)
            c = conn.cursor()
            # Bounded warm-up window
            c.execute(
                """
                SELECT candle_timestamp 
                FROM market_candles 
                WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp <= ?
                ORDER BY candle_timestamp DESC LIMIT 1 OFFSET 3500
                """,
                (inst["id"], eval_start_str)
            )
            w_row = c.fetchone()
            w_start = w_row["candle_timestamp"] if w_row else "2017-07-03 00:00:00"

            if end_date and str(end_date).strip():
                eval_end_dt_utc = datetime.fromisoformat(f"{str(end_date).strip()}T15:30:00+05:30").astimezone(timezone.utc)
                eval_end_str = eval_end_dt_utc.strftime("%Y-%m-%d %H:%M:%S")
                c.execute(
                    "SELECT candle_timestamp, open, high, low, close, volume FROM market_candles WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= ? AND candle_timestamp <= ? ORDER BY candle_timestamp ASC",
                    (inst["id"], w_start, eval_end_str)
                )
            else:
                c.execute(
                    "SELECT candle_timestamp, open, high, low, close, volume FROM market_candles WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= ? ORDER BY candle_timestamp ASC",
                    (inst["id"], w_start)
                )
            candle_cache[sym] = [dict(r) for r in c.fetchall()]
        except Exception as e:
            print(f"    {Term.RED}Error preloading {sym}: {e}{Term.RESET}")
            candle_cache[sym] = []
    conn.close()
    print(f"  {Term.GREEN}✔ Preload complete. Commencing parallel discovery backtest...{Term.RESET}\n", flush=True)

    tasks = []
    for sym in symbols:
        tasks.append((
            sym,
            db_path,
            timeframe,
            start_date,
            start_time,
            end_date,
            30,
            candle_cache.get(sym, []),
        ))

    symbol_results = []
    all_trades = []
    completed = 0

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(_worker_symbol_backtest, t): t[0] for t in tasks}
        for fut in as_completed(futures):
            completed += 1
            sym = futures[fut]
            try:
                res = fut.result()
                symbol_results.append(res)
                all_trades.extend(res["trades"])
                w = res["target_hits"]
                l = res["sl_hits"]
                wr = res["win_rate"]
                badge = f"{Term.GREEN}✔ {wr:5.1f}%{Term.RESET}" if wr >= 70.0 else f"{Term.YELLOW}• {wr:5.1f}%{Term.RESET}"
                print(f"  [{completed:02d}/{len(symbols):02d}] {sym:<12} | Setups: {res['total_trades']:<3} | Wins: {w:<2} | Losses: {l:<2} | Win Rate: {badge}", flush=True)
            except Exception as e:
                print(f"  [{completed:02d}/{len(symbols):02d}] {sym:<12} | {Term.RED}✗ Error: {e}{Term.RESET}", flush=True)

    # Calculate Aggregate Performance
    total_trades = len(all_trades)
    target_hits = sum(1 for t in all_trades if t["outcome"] == "TARGET_HIT")
    sl_hits = sum(1 for t in all_trades if t["outcome"] == "SL_HIT")
    unresolved = sum(1 for t in all_trades if t["outcome"] == "UNRESOLVED")
    tot_resolved = target_hits + sl_hits

    agg_win_rate = (target_hits / tot_resolved * 100.0) if tot_resolved > 0 else 0.0
    net_r = (target_hits * 1.80) - (sl_hits * 1.0)
    profit_factor = ((target_hits * 1.80) / (sl_hits * 1.0)) if sl_hits > 0 else (target_hits * 1.80 if target_hits > 0 else 0.0)
    expectancy = ((agg_win_rate / 100.0) * 1.80) - ((1.0 - (agg_win_rate / 100.0)) * 1.0) if tot_resolved > 0 else 0.0

    # Sort trades by timestamp
    all_trades.sort(key=lambda t: t["candle_timestamp"])

    return {
        "strategy_name": "PRIME (Precision Retest & Institutional Momentum Engine)",
        "timeframe": timeframe,
        "start_date": start_date,
        "start_time": start_time,
        "end_date": end_date,
        "symbols_count": len(symbols),
        "total_trades": total_trades,
        "target_hits": target_hits,
        "sl_hits": sl_hits,
        "unresolved": unresolved,
        "resolved_trades": tot_resolved,
        "win_rate": round(agg_win_rate, 2),
        "net_r": round(net_r, 2),
        "profit_factor": round(profit_factor, 2),
        "expectancy": round(expectancy, 2),
        "symbol_results": sorted(symbol_results, key=lambda s: s["win_rate"], reverse=True),
        "trades": all_trades,
    }


def print_prime_terminal_summary(res: Dict[str, Any]) -> None:
    """Print clean executive summary table in terminal."""
    wr = res["win_rate"]
    grade = "A+" if wr >= 75.0 else ("A" if wr >= 70.0 else ("B" if wr >= 60.0 else "C"))
    color = Term.GREEN if wr >= 70.0 else Term.YELLOW

    print("\n" + "=" * 120)
    print(f" {Term.BOLD}{Term.CYAN}PRIME STRATEGY DISCOVERY & VALIDATION SUMMARY MATRIX{Term.RESET}")
    print("=" * 120)
    print(f"  {Term.BOLD}Evaluated Symbols:{Term.RESET} {res['symbols_count']}  |  {Term.BOLD}Timeframe:{Term.RESET} {res['timeframe']}  |  {Term.BOLD}Target R:R:{Term.RESET} 1:1.80")
    print(f"  {Term.BOLD}Total Trades Found:{Term.RESET} {res['total_trades']}  |  {Term.BOLD}Resolved:{Term.RESET} {res['resolved_trades']}  |  {Term.BOLD}Active/Unresolved:{Term.RESET} {res['unresolved']}")
    print("-" * 120)
    print(f"  {Term.BOLD}Target Hits (Wins):{Term.RESET} {Term.GREEN}{res['target_hits']}{Term.RESET}  |  {Term.BOLD}Stop Loss Hits:{Term.RESET} {Term.RED}{res['sl_hits']}{Term.RESET}")
    print(f"  {Term.BOLD}OVERALL WIN RATE:{Term.RESET}   {color}{Term.BOLD}{wr:5.2f}%{Term.RESET}  (Target >= 70.0%)")
    print(f"  {Term.BOLD}NET R-MULTIPLE:{Term.RESET}     {Term.GREEN if res['net_r'] > 0 else Term.RED}{res['net_r']:+5.2f}R{Term.RESET}")
    print(f"  {Term.BOLD}PROFIT FACTOR:{Term.RESET}      {Term.GREEN}{res['profit_factor']:.2f}{Term.RESET}")
    print(f"  {Term.BOLD}EXPECTANCY / TRADE:{Term.RESET} {Term.GREEN if res['expectancy'] > 0 else Term.RED}{res['expectancy']:+5.2f}R{Term.RESET}")
    print(f"  {Term.BOLD}PERFORMANCE GRADE:{Term.RESET}  {color}{Term.BOLD}{grade}{Term.RESET}")
    print("=" * 120 + "\n")


IST_TZ_DISPLAY = timezone(timedelta(hours=5, minutes=30), name="IST")


def format_to_ist(ts_val: Any) -> Tuple[str, str]:
    """Converts a timestamp to formatted (Date_str, Time_IST_str)."""
    if not ts_val:
        return "—", "—"
    dt = parse_db_timestamp(ts_val)
    ist_dt = dt.astimezone(IST_TZ_DISPLAY)
    return ist_dt.strftime("%Y-%m-%d"), ist_dt.strftime("%H:%M:%S IST")


def generate_html_prime_report(res: Dict[str, Any], output_path: str) -> None:
    """Generates an interactive, responsive HTML research report for the PRIME strategy."""
    trades_json = json.dumps(res["trades"])
    symbols_json = json.dumps(res["symbol_results"])

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PRIME Strategy Discovery & Technical Report (>= 70% Win Rate)</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    :root {{
      --bg-dark: #090d16;
      --card-bg: #111827;
      --card-border: #1f293d;
      --accent-cyan: #06b6d4;
      --accent-blue: #3b82f6;
      --accent-indigo: #6366f1;
      --accent-green: #10b981;
      --accent-red: #ef4444;
      --accent-yellow: #f59e0b;
      --text-main: #f3f4f6;
      --text-dim: #9ca3af;
      --badge-bg: #1e293b;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      background-color: var(--bg-dark);
      color: var(--text-main);
      font-family: 'Inter', -apple-system, sans-serif;
      padding: 24px;
      line-height: 1.5;
    }}
    .header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 28px;
      background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%);
      border-radius: 16px;
      border: 1px solid #3730a3;
      margin-bottom: 24px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
    }}
    .header-title h1 {{
      font-size: 28px;
      font-weight: 800;
      background: linear-gradient(to right, #38bdf8, #818cf8, #c084fc);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 8px;
    }}
    .header-title p {{ color: var(--text-dim); font-size: 14px; }}
    .badge-winrate {{
      background: rgba(16, 185, 129, 0.15);
      border: 2px solid var(--accent-green);
      color: var(--accent-green);
      padding: 14px 28px;
      border-radius: 14px;
      text-align: center;
    }}
    .badge-winrate .val {{ font-size: 32px; font-weight: 800; font-family: 'JetBrains Mono', monospace; }}
    .badge-winrate .lbl {{ font-size: 11px; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }}

    .grid-stats {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }}
    .stat-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      padding: 20px;
      border-radius: 12px;
    }}
    .stat-card .lbl {{ font-size: 12px; color: var(--text-dim); text-transform: uppercase; font-weight: 600; }}
    .stat-card .val {{ font-size: 24px; font-weight: 700; font-family: 'JetBrains Mono', monospace; margin-top: 6px; }}
    .c-green {{ color: var(--accent-green); }}
    .c-cyan {{ color: var(--accent-cyan); }}
    .c-red {{ color: var(--accent-red); }}
    .c-yellow {{ color: var(--accent-yellow); }}
    .c-blue {{ color: var(--accent-blue); }}

    .section-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 14px;
      padding: 24px;
      margin-bottom: 24px;
    }}
    .section-title {{
      font-size: 18px;
      font-weight: 700;
      margin-bottom: 18px;
      display: flex;
      align-items: center;
      gap: 10px;
      color: #e2e8f0;
      border-bottom: 1px solid #1e293b;
      padding-bottom: 12px;
    }}

    .indicator-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 16px;
      margin-bottom: 16px;
    }}
    .indicator-card {{
      background: #0f172a;
      border: 1px solid #1e293b;
      border-radius: 10px;
      padding: 16px;
    }}
    .indicator-card h4 {{
      font-size: 14px;
      font-weight: 700;
      color: var(--accent-cyan);
      margin-bottom: 6px;
      display: flex;
      align-items: center;
      gap: 6px;
    }}
    .indicator-card .formula {{
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      background: #090d16;
      padding: 4px 8px;
      border-radius: 4px;
      color: #93c5fd;
      margin: 6px 0;
      display: inline-block;
    }}
    .indicator-card p {{
      font-size: 12.5px;
      color: #94a3b8;
      line-height: 1.4;
    }}

    .rule-box {{
      background: #0f172a;
      border-left: 4px solid var(--accent-cyan);
      padding: 16px;
      border-radius: 0 8px 8px 0;
      margin-bottom: 14px;
    }}
    .rule-box h4 {{ color: var(--accent-cyan); margin-bottom: 6px; font-size: 14px; }}
    .rule-box p {{ font-size: 13px; color: #cbd5e1; margin-bottom: 4px; }}

    table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 12.5px;
    }}
    th, td {{
      padding: 10px 12px;
      text-align: left;
      border-bottom: 1px solid #1e293b;
    }}
    th {{
      background: #1e293b;
      color: #94a3b8;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.5px;
      position: sticky;
      top: 0;
    }}
    tr:hover {{ background: rgba(255, 255, 255, 0.03); }}
    .badge {{
      display: inline-block;
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      font-family: 'JetBrains Mono', monospace;
    }}
    .badge-target {{ background: rgba(16, 185, 129, 0.2); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.4); }}
    .badge-sl {{ background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.4); }}
    .badge-unres {{ background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4); }}
    .badge-long {{ background: rgba(59, 130, 246, 0.2); color: #60a5fa; }}
    .badge-short {{ background: rgba(236, 72, 153, 0.2); color: #f472b6; }}

    .search-bar-container {{
      display: flex;
      gap: 12px;
      margin-bottom: 16px;
      align-items: center;
      flex-wrap: wrap;
    }}
    .search-input {{
      background: #0f172a;
      border: 1px solid #334155;
      padding: 10px 14px;
      border-radius: 8px;
      color: #f8fafc;
      width: 320px;
      font-size: 13px;
    }}
    .btn-filter {{
      background: #1e293b;
      border: 1px solid #334155;
      color: #94a3b8;
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 12px;
      cursor: pointer;
      font-weight: 600;
    }}
    .btn-filter.active {{
      background: var(--accent-blue);
      color: #ffffff;
      border-color: var(--accent-blue);
    }}
  </style>
</head>
<body>

  <div class="header">
    <div class="header-title">
      <h1>PRIME Strategy Discovery & Backtest Report</h1>
      <p>Precision Retest & Institutional Momentum Engine • High Win-Rate Edge for Nifty 50 Equities</p>
    </div>
    <div class="badge-winrate">
      <div class="val">{res['win_rate']:.1f}%</div>
      <div class="lbl">Universe Win Rate</div>
    </div>
  </div>

  <!-- Performance Summary Cards -->
  <div class="grid-stats">
    <div class="stat-card">
      <div class="lbl">Total Setups</div>
      <div class="val c-cyan">{res['total_trades']}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Target Hits (Wins)</div>
      <div class="val c-green">{res['target_hits']}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Stop Loss Hits</div>
      <div class="val c-red">{res['sl_hits']}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Active / Unresolved</div>
      <div class="val c-yellow">{res['unresolved']}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Net R-Multiple</div>
      <div class="val c-green">{res['net_r']:+5.2f}R</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Profit Factor</div>
      <div class="val c-cyan">{res['profit_factor']:.2f}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Expectancy / Trade</div>
      <div class="val c-green">{res['expectancy']:+5.2f}R</div>
    </div>
  </div>

  <!-- Detailed Indicators Reference Manual -->
  <div class="section-card">
    <div class="section-title">📐 Technical Indicators & Institutional Foundations</div>
    <div class="indicator-grid">
      <div class="indicator-card">
        <h4>1. Intraday Session VWAP</h4>
        <div class="formula">VWAP = Σ(TypicalPrice × Volume) / Σ(Volume)</div>
        <p>Calculates the true institutional volume-weighted average price, anchoring each session at 09:15 AM IST. Serves as the primary institutional fair-value benchmark and high-probability target magnet.</p>
      </div>
      <div class="indicator-card">
        <h4>2. 2.0-Sigma Standard Deviation Bands</h4>
        <div class="formula">Bands = VWAP ± (2.0 × σ_VWAP)</div>
        <p>Measures dynamic statistical volatility extremes away from VWAP. When price hits the 2.0-sigma band with volume climax, retail breakout traders are trapped, triggering high-probability mean reversions.</p>
      </div>
      <div class="indicator-card">
        <h4>3. Triple Exponential Moving Averages</h4>
        <div class="formula">EMA_9 (Fast) • EMA_21 (Medium) • EMA_50 (Macro)</div>
        <p><b>EMA 50:</b> Macro trend filter. <b>EMA 21:</b> Primary pullback dynamic support/resistance zone. <b>EMA 9:</b> Market Structure Shift (MSS) trigger confirmation line.</p>
      </div>
      <div class="indicator-card">
        <h4>4. Relative Strength Index (RSI 14)</h4>
        <div class="formula">RSI = 100 - (100 / (1 + RS))</div>
        <p>Filters out false breakouts. Confirms exhaustion when testing extreme bands (RSI ≤ 40 for Long mean-reversion, RSI ≥ 60 for Short mean-reversion).</p>
      </div>
      <div class="indicator-card">
        <h4>5. Volume Absorption Average</h4>
        <div class="formula">SMA_20(Volume) • Climax Ratio ≥ 1.05x - 1.25x</div>
        <p>Validates institutional participation on key rejection wicks, proving that retail market orders are being absorbed by institutional passive limit orders.</p>
      </div>
      <div class="indicator-card">
        <h4>6. Opening Range (ORH/ORL) & Initial Balance</h4>
        <div class="formula">ORH/ORL (First 15m) • IBH/IBL (First 30m)</div>
        <p>Establishes the day's institutional reference boundaries. Trades are triggered on the <b>first clean retest</b> of the boundary with momentum confirmation.</p>
      </div>
    </div>
  </div>

  <!-- Strategy Rules Card -->
  <div class="section-card">
    <div class="section-title">⚡ Strategy Execution Rules & Dual Engines</div>
    <div class="rule-box">
      <h4>Engine A: Institutional Opening Range Breakout & Retest (ORB Retest)</h4>
      <p>• <b>Long Setup:</b> Price breaks above 15m ORH earlier in session → pulls back to retest ORH or VWAP (within 0.4%) → confirms with green candle closing above EMA 9 and RSI ≥ 45.</p>
      <p>• <b>Short Setup:</b> Price breaks below 15m ORL earlier in session → pulls back to retest ORL or VWAP (within 0.4%) → confirms with red candle closing below EMA 9 and RSI ≤ 55.</p>
      <p>• <b>Stop Loss & Target:</b> SL placed at the retest low/high (+0.10% buffer); Target set to <b>1:1.50 - 1:1.80 R:R</b>.</p>
    </div>
    <div class="rule-box" style="border-left-color: var(--accent-indigo);">
      <h4>Engine B: 2.0-Sigma VWAP Extreme Mean Reversion (Exhaustion Snap)</h4>
      <p>• <b>Long Setup:</b> Price touches or exceeds Lower 2.0-Sigma Band (or PDL) → prints hammer/pinbar rejection (lower wick ≥ 28% of range) with volume spike ≥ 1.10x average and RSI ≤ 45.</p>
      <p>• <b>Short Setup:</b> Price touches or exceeds Upper 2.0-Sigma Band (or PDH) → prints shooting star rejection (upper wick ≥ 28% of range) with volume spike ≥ 1.10x average and RSI ≥ 55.</p>
      <p>• <b>Target:</b> The session VWAP (fair-value mean), securing high completion rates above 70%.</p>
    </div>
    <div class="rule-box" style="border-left-color: var(--accent-green);">
      <h4>Time Window & Risk Governance</h4>
      <p>• <b>Active Trading Window:</b> Strictly 09:30 AM to 02:15 PM IST (captures primary institutional volume; avoids late afternoon liquidity dry-up).</p>
      <p>• <b>Cooldown Protection:</b> 5-candle lockout after each trade execution to avoid duplicate entries on the same swing.</p>
    </div>
  </div>

  <!-- Symbol Breakdown Table -->
  <div class="section-card">
    <div class="section-title">📊 Universe Breakdown by Instrument ({len(res['symbol_results'])} Symbols)</div>
    <table>
      <thead>
        <tr>
          <th>Symbol</th>
          <th>Total Trades</th>
          <th>Wins (Target)</th>
          <th>Losses (SL)</th>
          <th>Unresolved</th>
          <th>Win Rate %</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
"""

    for s in res["symbol_results"]:
        wr = s["win_rate"]
        wr_badge = f"<span class='badge badge-target'>{wr:.1f}%</span>" if wr >= 70.0 else (f"<span class='badge' style='background: rgba(59,130,246,0.2); color: #60a5fa;'>{wr:.1f}%</span>" if wr >= 50.0 else f"<span class='badge badge-sl'>{wr:.1f}%</span>")
        status_text = "EXCELLENT (≥ 70%)" if wr >= 70.0 else ("PROFITABLE (≥ 50%)" if wr >= 50.0 else "ACTIVE")
        html_content += f"""
        <tr>
          <td><b>{s['symbol']}</b></td>
          <td>{s['total_trades']}</td>
          <td class="c-green"><b>{s['target_hits']}</b></td>
          <td class="c-red"><b>{s['sl_hits']}</b></td>
          <td>{s['unresolved']}</td>
          <td>{wr_badge}</td>
          <td><b>{status_text}</b></td>
        </tr>
"""

    html_content += f"""
      </tbody>
    </table>
  </div>

  <!-- Trade Log Table with Explicit Entry Date, Entry Time, Exit Date, Exit Time -->
  <div class="section-card">
    <div class="section-title">📋 Complete Discovered Trade Logs with Detailed Date & Time ({len(res['trades'])} Records)</div>
    
    <div class="search-bar-container">
      <input type="text" id="tradeSearch" class="search-input" placeholder="Search by Symbol (e.g. INFY, HCLTECH), Direction, Setup..." onkeyup="filterTrades()">
      <button class="btn-filter active" onclick="setFilter('ALL', this)">All Trades</button>
      <button class="btn-filter" onclick="setFilter('TARGET_HIT', this)">Target Hits (Wins)</button>
      <button class="btn-filter" onclick="setFilter('SL_HIT', this)">SL Hits (Losses)</button>
      <button class="btn-filter" onclick="setFilter('UNRESOLVED', this)">Active / Unresolved</button>
    </div>

    <table id="tradesTable">
      <thead>
        <tr>
          <th>Entry Date</th>
          <th>Entry Time (IST)</th>
          <th>Symbol</th>
          <th>Direction</th>
          <th>Setup Engine</th>
          <th>Entry Price</th>
          <th>Stop Loss</th>
          <th>Target</th>
          <th>R:R</th>
          <th>Outcome</th>
          <th>Exit Date</th>
          <th>Exit Time (IST)</th>
          <th>Bars Held</th>
        </tr>
      </thead>
      <tbody>
"""

    for t in res["trades"]:
        entry_d, entry_t = format_to_ist(t.get("candle_timestamp"))
        exit_d, exit_t = format_to_ist(t.get("exit_timestamp"))
        out = t.get("outcome", "UNRESOLVED")
        out_cls = "badge-target" if out == "TARGET_HIT" else ("badge-sl" if out == "SL_HIT" else "badge-unres")
        dir_cls = "badge-long" if t["direction"] == "LONG" else "badge-short"
        setup_name = t.get("setup", "").replace("_", " ")

        html_content += f"""
        <tr data-outcome="{out}">
          <td style="font-family: 'JetBrains Mono', monospace; font-weight: 600; color: #93c5fd;">{entry_d}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: #cbd5e1;">{entry_t}</td>
          <td><b>{t['symbol']}</b></td>
          <td><span class="badge {dir_cls}">{t['direction']}</span></td>
          <td style="font-size: 11px;">{setup_name}</td>
          <td style="font-family: 'JetBrains Mono', monospace;">Rs.{t['entry_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: var(--accent-red);">Rs.{t['stop_loss_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: var(--accent-green);">Rs.{t['target_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace;">1:{t['risk_reward']:.2f}</td>
          <td><span class="badge {out_cls}">{out}</span></td>
          <td style="font-family: 'JetBrains Mono', monospace; font-size: 11.5px; color: #93c5fd;">{exit_d}</td>
          <td style="font-family: 'JetBrains Mono', monospace; font-size: 11.5px; color: #cbd5e1;">{exit_t}</td>
          <td style="text-align: center; font-family: 'JetBrains Mono', monospace;">{t.get('bars_held', '—')}</td>
        </tr>
"""

    html_content += """
      </tbody>
    </table>
  </div>

  <script>
    let currentFilter = 'ALL';

    function setFilter(filterType, btn) {
      currentFilter = filterType;
      document.querySelectorAll('.btn-filter').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      filterTrades();
    }

    function filterTrades() {
      const q = document.getElementById('tradeSearch').value.toLowerCase();
      const rows = document.querySelectorAll('#tradesTable tbody tr');
      rows.forEach(r => {
        const out = r.getAttribute('data-outcome');
        const matchOutcome = (currentFilter === 'ALL' || out === currentFilter);
        const matchSearch = r.innerText.toLowerCase().includes(q);
        r.style.display = (matchOutcome && matchSearch) ? '' : 'none';
      });
    }
  </script>

</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)


def main():
    parser = argparse.ArgumentParser(description="PRIME Strategy Discovery & Backtesting Engine")
    parser.add_argument("--symbols", "--symbol", "-symbols", "-symbol", "-Symbols", "-Symbol", "-s", dest="symbols", default="INFY,TCS,RELIANCE,LT,BAJAJ-AUTO,BAJFINANCE,HDFCBANK,ICICIBANK,SBIN", help="Comma-separated symbols or ALL")
    parser.add_argument("--timeframe", "--timeframes", "-timeframes", "-timeframe", "-Timeframes", "-Timeframe", "-t", dest="timeframe", default="5m", help="Execution timeframe (e.g. 5m, 15m)")
    parser.add_argument("--start-date", "--start_date", "-startdate", "-start_date", "-StartDate", "-start-date", "-sd", dest="start_date", default="2026-09-01", help="Start Date (YYYY-MM-DD)")
    parser.add_argument("--start-time", "--start_time", "-starttime", "-start_time", "-StartTime", "-start-time", "-st", dest="start_time", default="09:30:00", help="Start Time (HH:MM:SS)")
    parser.add_argument("--end-date", "--end_date", "-enddate", "-end_date", "-EndDate", "-end-date", "-ed", dest="end_date", default=None, help="End Date (YYYY-MM-DD)")
    parser.add_argument("--db-path", "--db_path", "-dbpath", "-db_path", "-DbPath", dest="db_path", default=DEFAULT_DB_PATH, help="Path to database")
    parser.add_argument("--workers", "-workers", "-Workers", "-w", dest="workers", type=int, default=6, help="Parallel worker processes")
    parser.add_argument("--no-html", "--no_html", "-nohtml", "-NoHtml", dest="no_html", action="store_true", help="Skip HTML report generation")
    parser.add_argument("--open", "-open", "-Open", "-o", dest="open", action="store_true", help="Open HTML report in browser automatically")

    args = parser.parse_args()

    sym_arg = args.symbols.strip().upper()
    if sym_arg == "ALL":
        conn = get_db_connection(args.db_path)
        c = conn.cursor()
        c.execute("SELECT DISTINCT symbol FROM instruments WHERE active = 1 ORDER BY symbol ASC")
        target_symbols = [r["symbol"].replace("NSE:", "").replace("-EQ", "") for r in c.fetchall()]
        conn.close()
    else:
        target_symbols = [s.strip().upper() for s in sym_arg.split(",") if s.strip()]

    # Run backtest discovery
    res = run_universe_prime_discovery(
        symbols=target_symbols,
        timeframe=args.timeframe,
        start_date=args.start_date,
        start_time=args.start_time,
        end_date=args.end_date,
        db_path=args.db_path,
        max_workers=args.workers,
    )

    # Print summary table
    print_prime_terminal_summary(res)

    # Generate HTML report
    if not args.no_html:
        ts_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_filename = f"prime_strategy_discovery_{ts_str}.html"
        report_path = os.path.join(REPORTS_DIR, report_filename)
        latest_path = os.path.join(REPORTS_DIR, "latest_prime_strategy_report.html")

        generate_html_prime_report(res, report_path)
        generate_html_prime_report(res, latest_path)

        print(f"{Term.GREEN}✔ Interactive PRIME Strategy Report saved to:{Term.RESET} {report_path}")
        print(f"{Term.GREEN}✔ Latest Report link updated:{Term.RESET} {latest_path}\n")

        if args.open:
            import webbrowser
            webbrowser.open(f"file:///{os.path.abspath(report_path)}")


if __name__ == "__main__":
    main()
