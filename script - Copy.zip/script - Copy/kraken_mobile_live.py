#!/usr/bin/env python3
"""
===============================================================================
 KRAKEN STANDALONE MOBILE SCANNER & ALERT ENGINE (ANDROID / TERMUX READY)
===============================================================================
 Location: script/kraken_mobile_live.py

 Single self-contained script designed to run natively on Android via Termux.
 Zero external local directory dependencies (pure standalone).

 Features:
   - Embedded KRAKEN Two-Stage Engine (LSRI, Session VWAP, IVAR, MTVS)
   - Mobile-optimized card layout designed for Android phone screens
   - Automatic intraday trade lifecycle tracking (Working vs Completed)
   - Persistent token loading from 'fyers_token.txt' (set it once per day)
   - Native Android alert sound / vibration support (via Termux API / Bell)

 Usage in Termux:
   python kraken_mobile_live.py --loop
   python kraken_mobile_live.py --token <YOUR_TOKEN> --loop
===============================================================================
"""

import os
import sys
import time
import math
import argparse
import webbrowser
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime, time as dtime, timezone, timedelta
from typing import List, Dict, Any, Optional, Tuple

IST_TZ = timezone(timedelta(hours=5, minutes=30))

DEFAULT_CLIENT_ID = "RVL9EOD3TM-100"
DEFAULT_SECRET_KEY = "5F13YACRE4"
DEFAULT_REDIRECT_URI = "http://127.0.0.1:8000/api/v1/auth/fyers/callback"
TOKEN_FILE = "fyers_token.txt"

# Initialize ANSI Virtual Terminal Processing and UTF-8 output
if sys.platform == "win32":
    try:
        os.system("")
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass



class C:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    
    # Standard High-Compatibility Colors
    RED = "\033[1;31m"
    GREEN = "\033[1;32m"
    YELLOW = "\033[1;33m"
    BLUE = "\033[1;34m"
    MAGENTA = "\033[1;35m"
    CYAN = "\033[1;36m"
    WHITE = "\033[1;37m"
    GRAY = "\033[0;90m"

    # High-contrast background badges
    BG_GREEN = "\033[42;1;30m"
    BG_RED = "\033[41;1;37m"
    BG_CYAN = "\033[46;1;30m"
    BG_YELLOW = "\033[43;1;30m"
    BG_MAGENTA = "\033[45;1;37m"



# Liquid Nifty 50 Universe
NIFTY_SYMBOLS = [
    "SUNPHARMA", "SBIN", "MARUTI", "BRITANNIA", "WIPRO",
    "BAJAJ-AUTO", "BAJAJFINSV", "BAJFINANCE", "BHARTIARTL", "BPCL",
    "CIPLA", "COALINDIA", "DRREDDY", "EICHERMOT", "GRASIM",
    "HCLTECH", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO", "HINDALCO",
    "HINDUNILVR", "ICICIBANK", "INDUSINDBK", "INFY", "ITC",
    "JSWSTEEL", "KOTAKBANK", "LT", "M&M", "NESTLEIND",
    "NTPC", "ONGC", "POWERGRID", "RELIANCE", "SBILIFE",
    "SHRIRAMFIN", "TATACONSUM", "TATASTEEL", "TCS", "TECHM",
    "TITAN", "TRENT", "ULTRACEMCO"
]

try:
    from fyers_apiv3 import fyersModel
    HAS_FYERS = True
except ImportError:
    HAS_FYERS = False



# ===============================================================================
# EMBEDDED KRAKEN STRATEGY ENGINE
# ===============================================================================

class KrakenStrategyEngine:
    def __init__(
        self,
        target_rr: float = 3.0,
        t1_rr: float = 1.2,
        sl_buffer_atr: float = 0.08,
        min_wick_ratio: float = 0.25,
        volume_multiplier: float = 1.15,
    ):
        self.target_rr = float(target_rr)
        self.t1_rr = float(t1_rr)
        self.sl_buffer_atr = float(sl_buffer_atr)
        self.min_wick_ratio = float(min_wick_ratio)
        self.volume_multiplier = float(volume_multiplier)

    def _parse_dt(self, c: Dict[str, Any]) -> datetime:
        raw_ts = c.get("candle_timestamp") or c.get("timestamp") or c.get("datetime")
        if isinstance(raw_ts, datetime):
            if raw_ts.tzinfo is None:
                return raw_ts.replace(tzinfo=timezone.utc)
            return raw_ts
        ts_str = str(raw_ts).replace("Z", "+00:00")
        if "+" not in ts_str and "-" not in ts_str[10:]:
            ts_str += "+00:00"
        try:
            return datetime.fromisoformat(ts_str)
        except Exception:
            return datetime.strptime(str(raw_ts)[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)

    def calculate_session_vwap(self, candles: List[Dict[str, Any]]) -> List[float]:
        if not candles:
            return []
        vwap_vals = []
        curr_date = None
        cum_pv = 0.0
        cum_vol = 0.0

        for c in candles:
            dt = self._parse_dt(c).astimezone(IST_TZ)
            d = dt.date()
            high = float(c["high"])
            low = float(c["low"])
            close = float(c["close"])
            vol = float(c.get("volume", 0.0) or 0.0)

            if curr_date != d:
                curr_date = d
                cum_pv = 0.0
                cum_vol = 0.0

            typical_price = (high + low + close) / 3.0
            cum_pv += typical_price * vol
            cum_vol += vol

            if cum_vol > 0:
                vwap_vals.append(cum_pv / cum_vol)
            else:
                vwap_vals.append(typical_price)

        return vwap_vals

    def calculate_emas(self, values: List[float], periods: List[int]) -> Dict[int, List[float]]:
        results = {}
        n = len(values)
        for period in periods:
            ema = [values[0]] if values else []
            multiplier = 2.0 / (period + 1.0)
            for i in range(1, n):
                val = (values[i] - ema[-1]) * multiplier + ema[-1]
                ema.append(val)
            results[period] = ema
        return results

    def calculate_atr(self, highs: List[float], lows: List[float], closes: List[float], period: int = 14) -> List[float]:
        n = len(closes)
        if n < 2:
            return [0.0] * n
        tr_list = [highs[0] - lows[0]]
        for i in range(1, n):
            h = highs[i]
            l = lows[i]
            prev_c = closes[i - 1]
            tr = max(h - l, abs(h - prev_c), abs(l - prev_c))
            tr_list.append(tr)

        atr_vals = []
        current_atr = sum(tr_list[:period]) / float(period) if n >= period else tr_list[0]
        for i in range(n):
            if i < period:
                atr_vals.append(current_atr)
            else:
                current_atr = (current_atr * (period - 1) + tr_list[i]) / float(period)
                atr_vals.append(current_atr)
        return atr_vals

    def calculate_rsi(self, closes: List[float], period: int = 14) -> List[float]:
        n = len(closes)
        if n < period + 1:
            return [50.0] * n
        gains = []
        losses = []
        for i in range(1, n):
            diff = closes[i] - closes[i - 1]
            gains.append(max(diff, 0.0))
            losses.append(max(-diff, 0.0))
        rsi_vals = [50.0] * period
        avg_gain = sum(gains[:period]) / float(period)
        avg_loss = sum(losses[:period]) / float(period)
        for i in range(period, n):
            if i > period:
                diff = closes[i] - closes[i - 1]
                g = max(diff, 0.0)
                l = max(-diff, 0.0)
                avg_gain = (avg_gain * (period - 1) + g) / float(period)
                avg_loss = (avg_loss * (period - 1) + l) / float(period)
            if avg_loss == 0.0:
                rsi_vals.append(100.0)
            else:
                rs = avg_gain / avg_loss
                rsi_vals.append(100.0 - (100.0 / (1.0 + rs)))
        return rsi_vals

    def calculate_opening_range(self, candles: List[Dict[str, Any]]) -> Tuple[Optional[float], Optional[float]]:
        if not candles:
            return None, None
        curr_dt = self._parse_dt(candles[-1]).astimezone(IST_TZ)
        today = curr_dt.date()

        morning_candles = []
        for c in reversed(candles):
            c_dt = self._parse_dt(c).astimezone(IST_TZ)
            if c_dt.date() != today:
                break
            if dtime(9, 15) <= c_dt.time() < dtime(9, 30):
                morning_candles.append(c)

        if not morning_candles:
            return None, None

        or_high = max(float(x["high"]) for x in morning_candles)
        or_low = min(float(x["low"]) for x in morning_candles)
        return or_high, or_low

    def evaluate(
        self,
        symbol: str,
        current_price: float,
        candles: List[Dict[str, Any]],
        index_bias: str = "NEUTRAL",
        market_regime: str = "TRENDING",
    ) -> Dict[str, Any]:
        if len(candles) < 30:
            return {"status": "UNDEFINED"}

        c_curr = candles[-1]
        c_prev = candles[-2]
        curr_dt = self._parse_dt(c_curr)
        curr_ist = curr_dt.astimezone(IST_TZ)
        curr_time = curr_ist.time()

        is_morning = dtime(9, 30) <= curr_time <= dtime(11, 15)
        is_afternoon = dtime(13, 15) <= curr_time <= dtime(14, 15)
        if not (is_morning or is_afternoon):
            return {"status": "UNDEFINED"}

        # Dynamic volume filter: Higher bar for afternoon sessions and non-trending index regimes
        effective_vol_mult = self.volume_multiplier
        if is_afternoon:
            effective_vol_mult = max(effective_vol_mult, 1.50)
        elif index_bias == "NEUTRAL":
            effective_vol_mult = max(effective_vol_mult, 1.55)

        # Dynamic runner target: Take conservative +2.0R on rangebound/choppy index days vs +3.0R on trending days
        effective_target_rr = 2.0 if market_regime == "RANGEBOUND" else self.target_rr

        closes = [float(c["close"]) for c in candles]
        highs = [float(c["high"]) for c in candles]
        lows = [float(c["low"]) for c in candles]
        opens = [float(c["open"]) for c in candles]
        volumes = [float(c.get("volume", 0.0) or 0.0) for c in candles]

        vwap_vals = self.calculate_session_vwap(candles)
        curr_vwap = vwap_vals[-1]

        emas = self.calculate_emas(closes, [9, 21, 50, 60, 150])
        atr_vals = self.calculate_atr(highs, lows, closes, 14)
        rsi_vals = self.calculate_rsi(closes, 14)

        ema9 = emas[9][-1]
        ema21 = emas[21][-1]
        ema50 = emas[50][-1]
        ema60 = emas[60][-1]
        ema150 = emas[150][-1]
        curr_atr = atr_vals[-1] if atr_vals else (closes[-1] * 0.005)
        curr_rsi = rsi_vals[-1]

        htf_bull = (ema60 >= ema150) or (closes[-1] > curr_vwap and closes[-1] > ema50)
        htf_bear = (ema60 <= ema150) or (closes[-1] < curr_vwap and closes[-1] < ema50)

        # Macro Nifty 50 Trend Alignment Filter
        allow_long = (index_bias != "BEARISH")
        allow_short = (index_bias != "BULLISH")

        avg_vol_20 = float(sum(volumes[-21:-1]) / 20.0) if len(volumes) >= 21 else 1.0
        if avg_vol_20 <= 0:
            avg_vol_20 = 1.0

        curr_open = opens[-1]
        curr_high = highs[-1]
        curr_low = lows[-1]
        curr_close = closes[-1]
        curr_vol = volumes[-1]

        rvol = curr_vol / avg_vol_20
        c_range = curr_high - curr_low
        upper_wick = curr_high - max(curr_open, curr_close)
        lower_wick = min(curr_open, curr_close) - curr_low

        upper_wick_ratio = (upper_wick / c_range) if c_range > 0 else 0.0
        lower_wick_ratio = (lower_wick / c_range) if c_range > 0 else 0.0

        or_high, or_low = self.calculate_opening_range(candles)
        swing_high_20 = max(highs[-21:-1])
        swing_low_20 = min(lows[-21:-1])

        ref_high = or_high if or_high is not None else swing_high_20
        ref_low = or_low if or_low is not None else swing_low_20

        # SETUP 1: BEAR TRAP (LONG)
        swept_low = (curr_low < ref_low) and (curr_close > ref_low)
        if allow_long and htf_bull and swept_low and (curr_close > curr_open) and (lower_wick_ratio >= self.min_wick_ratio):
            if rvol >= effective_vol_mult and curr_rsi >= 28.0:
                entry = curr_close
                stop_loss = round(curr_low - (self.sl_buffer_atr * curr_atr), 2)
                risk = round(entry - stop_loss, 2)
                if 0.20 * curr_atr <= risk <= 2.2 * curr_atr:
                    return {
                        "status": "VALID",
                        "direction": "LONG",
                        "entry_price": entry,
                        "stop_loss_price": stop_loss,
                        "t1_target_price": round(entry + (risk * self.t1_rr), 2),
                        "target_price": round(entry + (risk * effective_target_rr), 2),
                        "target_rr": effective_target_rr,
                        "explanation": f"Bear Trap Long (Low {ref_low:.2f} swept & rejected | Nifty: {index_bias})"
                    }

        # SETUP 2: BULL TRAP (SHORT)
        swept_high = (curr_high > ref_high) and (curr_close < ref_high)
        if allow_short and htf_bear and swept_high and (curr_close < curr_open) and (upper_wick_ratio >= self.min_wick_ratio):
            if rvol >= effective_vol_mult and curr_rsi <= 72.0:
                entry = curr_close
                stop_loss = round(curr_high + (self.sl_buffer_atr * curr_atr), 2)
                risk = round(stop_loss - entry, 2)
                if 0.20 * curr_atr <= risk <= 2.2 * curr_atr:
                    return {
                        "status": "VALID",
                        "direction": "SHORT",
                        "entry_price": entry,
                        "stop_loss_price": stop_loss,
                        "t1_target_price": round(entry - (risk * self.t1_rr), 2),
                        "target_price": round(entry - (risk * effective_target_rr), 2),
                        "target_rr": effective_target_rr,
                        "explanation": f"Bull Trap Short (High {ref_high:.2f} swept & rejected | Nifty: {index_bias})"
                    }

        # SETUP 3: PULLBACK LONG
        if allow_long and htf_bull and (curr_close > curr_vwap) and (ema9 > ema21 > ema50) and (curr_close > curr_open):
            pullback = (curr_low <= ema21 or highs[-2] >= ema21 and lows[-2] <= ema21)
            reversal = (curr_close > float(c_prev["high"])) and (lower_wick_ratio >= 0.20 or rvol >= 1.20)
            if pullback and reversal and rvol >= effective_vol_mult:
                entry = curr_close
                pivot_low = min(curr_low, float(c_prev["low"]))
                stop_loss = round(pivot_low - (self.sl_buffer_atr * curr_atr), 2)
                risk = round(entry - stop_loss, 2)
                if 0.25 * curr_atr <= risk <= 2.0 * curr_atr:
                    return {
                        "status": "VALID",
                        "direction": "LONG",
                        "entry_price": entry,
                        "stop_loss_price": stop_loss,
                        "t1_target_price": round(entry + (risk * self.t1_rr), 2),
                        "target_price": round(entry + (risk * effective_target_rr), 2),
                        "target_rr": effective_target_rr,
                        "explanation": f"Value Pullback Long (EMA21/VWAP bounce | Nifty: {index_bias})"
                    }

        # SETUP 4: PULLBACK SHORT
        if allow_short and htf_bear and (curr_close < curr_vwap) and (ema9 < ema21 < ema50) and (curr_close < curr_open):
            pullback = (curr_high >= ema21 or lows[-2] <= ema21 and highs[-2] >= ema21)
            reversal = (curr_close < float(c_prev["low"])) and (upper_wick_ratio >= 0.20 or rvol >= 1.20)
            if pullback and reversal and rvol >= effective_vol_mult:
                entry = curr_close
                pivot_high = max(curr_high, float(c_prev["high"]))
                stop_loss = round(pivot_high + (self.sl_buffer_atr * curr_atr), 2)
                risk = round(stop_loss - entry, 2)
                if 0.25 * curr_atr <= risk <= 2.0 * curr_atr:
                    return {
                        "status": "VALID",
                        "direction": "SHORT",
                        "entry_price": entry,
                        "stop_loss_price": stop_loss,
                        "t1_target_price": round(entry - (risk * self.t1_rr), 2),
                        "target_price": round(entry - (risk * effective_target_rr), 2),
                        "target_rr": effective_target_rr,
                        "explanation": f"Value Pullback Short (EMA21/VWAP rejection | Nifty: {index_bias})"
                    }

        return {"status": "UNDEFINED"}


# ===============================================================================
# MOBILE NOTIFICATIONS & DATA FETCHING
# ===============================================================================

def notify_mobile(title: str, message: str):
    """Triggers Android vibration / notification if Termux API installed, plus bell chime."""
    # Terminal bell
    sys.stdout.write('\a')
    sys.stdout.flush()

    # Termux API integration (if installed)
    try:
        os.system(f'termux-vibrate -d 300 > /dev/null 2>&1')
        os.system(f'termux-notification -t "{title}" -c "{message}" --sound > /dev/null 2>&1')
    except Exception:
        pass


def fetch_symbol_candles(fyers: Any, symbol: str, from_date: str, to_date: str) -> Optional[List[Dict[str, Any]]]:
    data = {
        "symbol": f"NSE:{symbol}-EQ",
        "resolution": "5",
        "date_format": "1",
        "range_from": from_date,
        "range_to": to_date,
        "cont_flag": "1"
    }
    try:
        res = fyers.history(data=data)
        if not isinstance(res, dict) or res.get("s") != "ok":
            return None
        raw = res.get("candles", [])
        if not raw:
            return None
        candles = []
        for c in raw:
            candles.append({
                "candle_timestamp": datetime.fromtimestamp(c[0], tz=timezone.utc),
                "open": float(c[1]),
                "high": float(c[2]),
                "low": float(c[3]),
                "close": float(c[4]),
                "volume": float(c[5])
            })
        return candles
    except Exception:
        return None


def fetch_nifty_index_state(fyers: Any, from_date: str, to_date: str) -> Dict[str, Any]:
    """Fetches Nifty 50 Index 5m candles, computes Session VWAP, and determines Macro Market Regime & Bias."""
    data = {
        "symbol": "NSE:NIFTY50-INDEX",
        "resolution": "5",
        "date_format": "1",
        "range_from": from_date,
        "range_to": to_date,
        "cont_flag": "1"
    }
    default_state = {
        "bias_map": {},
        "current_bias": "NEUTRAL",
        "current_price": 0.0,
        "current_vwap": 0.0,
        "diff": 0.0,
        "regime": "TRENDING",
        "day_range_pct": 1.0,
        "target_rr": 3.0
    }
    try:
        res = fyers.history(data=data)
        if not isinstance(res, dict) or res.get("s") != "ok":
            return default_state
        raw = res.get("candles", [])
        if not raw:
            return default_state

        now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
        today = now_ist.date()

        cum_pv = 0.0
        cum_vol = 0.0
        curr_date = None
        bias_map = {}
        highs, lows, opens = [], [], []

        for c in raw:
            dt = datetime.fromtimestamp(c[0], tz=timezone.utc).astimezone(IST_TZ)
            d = dt.date()
            if d != today:
                continue

            open_p = float(c[1])
            high_p = float(c[2])
            low_p = float(c[3])
            close_p = float(c[4])
            vol_p = float(c[5]) if float(c[5]) > 0 else 1.0

            if curr_date != d:
                curr_date = d
                cum_pv = 0.0
                cum_vol = 0.0

            tp = (high_p + low_p + close_p) / 3.0
            cum_pv += tp * vol_p
            cum_vol += vol_p
            vwap_val = cum_pv / cum_vol

            diff = close_p - vwap_val
            pct_diff = diff / vwap_val

            if abs(pct_diff) <= 0.0003:
                c_bias = "NEUTRAL"
            elif diff > 0:
                c_bias = "BULLISH"
            else:
                c_bias = "BEARISH"

            t_key = dt.strftime("%Y-%m-%d %H:%M")
            bias_map[t_key] = {
                "bias": c_bias,
                "price": close_p,
                "vwap": vwap_val,
                "diff": diff
            }
            highs.append(high_p)
            lows.append(low_p)
            opens.append(open_p)

        if not highs or not opens:
            return default_state

        day_range_pct = ((max(highs) - min(lows)) / opens[0]) * 100.0
        regime = "RANGEBOUND" if day_range_pct < 0.85 else "TRENDING"
        latest_c = raw[-1]
        latest_dt = datetime.fromtimestamp(latest_c[0], tz=timezone.utc).astimezone(IST_TZ)
        latest_key = latest_dt.strftime("%Y-%m-%d %H:%M")
        latest_info = bias_map.get(latest_key, {
            "bias": "NEUTRAL",
            "price": float(latest_c[4]),
            "vwap": float(latest_c[4]),
            "diff": 0.0
        })

        # Market Mood Matrix based on Directional Bias and Volatility Regime
        curr_b = latest_info["bias"]
        if curr_b == "BEARISH":
            if regime == "TRENDING":
                mood_tag = "🔴 EXTREME BEARISH / RISK-OFF"
                mood_desc = "Broad Distribution & Institutional Selling"
                action_plan = "Aggressive Shorts Favored | Longs Strictly Forbidden"
                mood_color = C.RED
            else:
                mood_tag = "🔴 CAUTIOUSLY BEARISH / SLOW BLEED"
                mood_desc = "Dull Rangebound Distribution & Choppy Down-Drift"
                action_plan = "Defensive Shorts Only | Quick Target Harvest (+2.0R)"
                mood_color = C.RED
        elif curr_b == "BULLISH":
            if regime == "TRENDING":
                mood_tag = "🟢 AGGRESSIVELY BULLISH / RISK-ON"
                mood_desc = "Broad Institutional Accumulation & Trend Expansion"
                action_plan = "Aggressive Longs Favored | Hold Full Runners (+3.0R)"
                mood_color = C.GREEN
            else:
                mood_tag = "🟢 MILDLY BULLISH / BUY-ON-DIPS"
                mood_desc = "Selective Sector Rotation & Rangebound Accumulation"
                action_plan = "Defensive Longs Only | Quick Target Harvest (+2.0R)"
                mood_color = C.GREEN
        else:
            if regime == "RANGEBOUND":
                mood_tag = "🟡 CHOPPY / INDECISIVE (SIDEWAYS)"
                mood_desc = "Tight Volatility Squeeze & Sideways Chop"
                action_plan = "Extreme Caution | Scalp Only (RVOL >= 1.55x Required)"
                mood_color = C.YELLOW
            else:
                mood_tag = "🟡 EQUILIBRIUM CONSOLIDATION"
                mood_desc = "Balancing at VWAP / Momentum Breakout Imminent"
                action_plan = "Wait for Confirmed Range Breakout"
                mood_color = C.YELLOW

        return {
            "bias_map": bias_map,
            "current_bias": latest_info["bias"],
            "current_price": latest_info["price"],
            "current_vwap": latest_info["vwap"],
            "diff": latest_info["diff"],
            "regime": regime,
            "day_range_pct": day_range_pct,
            "target_rr": 2.0 if regime == "RANGEBOUND" else 3.0,
            "mood_tag": mood_tag,
            "mood_desc": mood_desc,
            "action_plan": action_plan,
            "mood_color": mood_color,
        }
    except Exception:
        return default_state


def evaluate_today_lifecycle(engine: KrakenStrategyEngine, sym: str, candles: List[Dict[str, Any]], nifty_state: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    if len(candles) < 30:
        return []

    now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
    today_date = now_ist.date()

    captured_trades = []
    active_trade = None

    bias_map = nifty_state.get("bias_map", {}) if nifty_state else {}
    fallback_bias = nifty_state.get("current_bias", "NEUTRAL") if nifty_state else "NEUTRAL"
    regime = nifty_state.get("regime", "TRENDING") if nifty_state else "TRENDING"

    for idx in range(30, len(candles)):
        c_curr = candles[idx]
        c_dt = c_curr["candle_timestamp"].astimezone(IST_TZ)

        if c_dt.date() != today_date:
            continue

        t_key = c_dt.strftime("%Y-%m-%d %H:%M")
        bar_bias = bias_map.get(t_key, {}).get("bias", fallback_bias)

        if active_trade is None:
            res = engine.evaluate(
                symbol=sym,
                current_price=float(c_curr["close"]),
                candles=candles[:idx + 1],
                index_bias=bar_bias,
                market_regime=regime
            )
            if res.get("status") == "VALID":
                tgt_rr = res.get("target_rr", 3.0)
                active_trade = {
                    "symbol": sym,
                    "direction": res["direction"],
                    "entry_price": float(res["entry_price"]),
                    "stop_loss_price": float(res["stop_loss_price"]),
                    "initial_sl": float(res["stop_loss_price"]),
                    "t1_target_price": float(res["t1_target_price"]),
                    "target_price": float(res["target_price"]),
                    "target_rr": tgt_rr,
                    "trigger_time": c_dt.strftime("%H:%M"),
                    "trigger_idx": idx,
                    "status": f"[{res['direction']} ACTIVE]",
                    "t1_hit": False,
                    "closed": False,
                    "explanation": res.get("explanation", ""),
                    "is_fresh": (idx == len(candles) - 1)
                }
        else:
            high = float(c_curr["high"])
            low = float(c_curr["low"])
            tgt_rr = active_trade.get("target_rr", 3.0)

            if active_trade["direction"] == "LONG":
                if not active_trade["t1_hit"] and high >= active_trade["t1_target_price"]:
                    active_trade["t1_hit"] = True
                    active_trade["stop_loss_price"] = active_trade["entry_price"]
                    active_trade["status"] = "[BUY T1 (BE)]"

                if high >= active_trade["target_price"]:
                    active_trade["status"] = f"[T2 HIT +{tgt_rr:.1f}R]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None
                elif low <= active_trade["stop_loss_price"]:
                    active_trade["status"] = "[EXITED (BE)]" if active_trade["t1_hit"] else "[STOPPED OUT]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None

            elif active_trade["direction"] == "SHORT":
                if not active_trade["t1_hit"] and low <= active_trade["t1_target_price"]:
                    active_trade["t1_hit"] = True
                    active_trade["stop_loss_price"] = active_trade["entry_price"]
                    active_trade["status"] = "[SELL T1 (BE)]"

                if low <= active_trade["target_price"]:
                    active_trade["status"] = f"[T2 HIT +{tgt_rr:.1f}R]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None
                elif high >= active_trade["stop_loss_price"]:
                    active_trade["status"] = "[EXITED (BE)]" if active_trade["t1_hit"] else "[STOPPED OUT]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None

    if active_trade is not None:
        captured_trades.append(active_trade)

    return captured_trades


def scan_mobile(fyers: Any, engine: KrakenStrategyEngine, symbols: List[str]):
    now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
    from_date = (now_ist - timedelta(days=7)).strftime("%Y-%m-%d")
    to_date = now_ist.strftime("%Y-%m-%d")

    # 1. Fetch Nifty 50 Macro Index Regime & Bias
    nifty_state = fetch_nifty_index_state(fyers, from_date, to_date)
    bias_tag = nifty_state.get("current_bias", "NEUTRAL")
    regime_tag = nifty_state.get("regime", "TRENDING")
    nifty_p = nifty_state.get("current_price", 0.0)
    nifty_vw = nifty_state.get("current_vwap", 0.0)
    diff_pts = nifty_state.get("diff", 0.0)
    day_rng = nifty_state.get("day_range_pct", 0.0)
    tgt2 = nifty_state.get("target_rr", 3.0)

    mood_tag = nifty_state.get("mood_tag", "UNKNOWN")
    mood_desc = nifty_state.get("mood_desc", "")
    action_plan = nifty_state.get("action_plan", "")
    mood_color = nifty_state.get("mood_color", C.YELLOW)

    if bias_tag == "BEARISH":
        bias_badge = f"{C.BG_RED} 🔴 BEARISH {C.RESET}"
    elif bias_tag == "BULLISH":
        bias_badge = f"{C.BG_GREEN} 🟢 BULLISH {C.RESET}"
    else:
        bias_badge = f"{C.BG_YELLOW} 🟡 NEUTRAL {C.RESET}"

    # Print Mobile Nifty 50 Macro Header with Market Mood Card
    print("\n" + f"{C.BOLD}{C.BLUE}" + "=" * 50 + f"{C.RESET}")
    print(f" {C.BOLD}{C.WHITE}📊 NIFTY 50 MACRO REGIME{C.RESET} | {bias_badge}")
    print(f"{C.BOLD}{C.BLUE}" + "=" * 50 + f"{C.RESET}")
    print(f" Index   : {C.BOLD}{C.WHITE}{nifty_p:.2f}{C.RESET} | VWAP: {nifty_vw:.2f} ({diff_pts:+.2f} pts)")
    print(f" Mood    : {C.BOLD}{mood_color}{mood_tag}{C.RESET}")
    print(f" Action  : {C.WHITE}{action_plan}{C.RESET}")
    print(f" Context : {C.GRAY}{mood_desc}{C.RESET}")
    print(f" Regime  : {C.YELLOW}{regime_tag}{C.RESET} (Range: {day_rng:.2f}% -> Runner: +{tgt2:.1f}R)")
    print(f"{C.BOLD}{C.BLUE}" + "=" * 50 + f"{C.RESET}")

    print(f"\n{C.CYAN}>> [{now_ist.strftime('%H:%M:%S IST')}]{C.RESET} Scanning {len(symbols)} Nifty 50 instruments...")

    all_trades = []
    success_count = 0
    new_signals = []

    for sym in symbols:
        candles = fetch_symbol_candles(fyers, sym, from_date, to_date)
        if candles and len(candles) >= 30:
            success_count += 1
            curr_close = float(candles[-1]["close"])
            trades = evaluate_today_lifecycle(engine, sym, candles, nifty_state)
            for t in trades:
                t["curr_price"] = curr_close
                all_trades.append(t)
                if t.get("is_fresh"):
                    new_signals.append(t)
        time.sleep(0.12)

    # 2. Trigger mobile sound & notification on fresh trigger
    if new_signals:
        notify_mobile("KRAKEN ALERT!", f"{len(new_signals)} fresh trade setup triggered!")
        is_short_alert = any(t["direction"] == "SHORT" for t in new_signals)
        header_bg = C.BG_RED if is_short_alert else C.BG_GREEN
        print("\n" + f"{header_bg} 🚨 FRESH KRAKEN TRADE SETUP TRIGGERED ({len(new_signals)}) 🚨 {C.RESET}")
        for t in new_signals:
            if t["direction"] == "LONG":
                dir_tag = f"{C.BG_GREEN} LONG {C.RESET}"
            else:
                dir_tag = f"{C.BG_RED} SHORT {C.RESET}"

            tgt_rr_t = t.get("target_rr", 3.0)
            print(f">> {dir_tag} {C.BOLD}{C.WHITE}{t['symbol']}{C.RESET} @ {C.BOLD}{t['entry_price']:.2f}{C.RESET}")
            print(f"   SL: {C.RED}{t['stop_loss_price']:.2f}{C.RESET} | T1: {C.CYAN}{t['t1_target_price']:.2f}{C.RESET} (+1.2R) | T2: {C.GREEN}{t['target_price']:.2f}{C.RESET} (+{tgt_rr_t:.1f}R)")
            print(f"   {C.GRAY}Reason: {t.get('explanation')}{C.RESET}")
        print(f"{C.GRAY}--------------------------------------------{C.RESET}\n")

    working = [t for t in all_trades if not t.get("closed", False)]
    completed = [t for t in all_trades if t.get("closed", False)]

    # 3. Mobile Card Display: Active Working Trades
    print("\n" + f"{C.BOLD}{C.CYAN}" + "=" * 50 + f"{C.RESET}")
    print(f" {C.BOLD}{C.CYAN}🔥 [ACTIVE TRADES IN PROGRESS]{C.RESET} {C.BOLD}{C.WHITE}({len(working)}){C.RESET}")
    print(f"{C.BOLD}{C.CYAN}" + "=" * 50 + f"{C.RESET}")
    if working:
        for t in working:
            cur_p = t.get("curr_price", t["entry_price"])
            init_risk = abs(t["entry_price"] - t["initial_sl"])
            tgt_rr_t = t.get("target_rr", 3.0)
            if t["direction"] == "LONG":
                pnl = cur_p - t["entry_price"]
                cur_r = pnl / init_risk if init_risk > 0 else 0.0
                dir_tag = f"🟢 {C.BG_GREEN} LONG {C.RESET}"
            else:
                pnl = t["entry_price"] - cur_p
                cur_r = pnl / init_risk if init_risk > 0 else 0.0
                dir_tag = f"🔴 {C.BG_RED} SHORT {C.RESET}"

            # P&L Styling
            if pnl > 0.001:
                pnl_styled = f"🟢 {C.BOLD}{C.GREEN}{pnl:+.2f} pts ({cur_r:+.2f}R) ▲{C.RESET}"
            elif pnl < -0.001:
                pnl_styled = f"🔴 {C.BOLD}{C.RED}{pnl:+.2f} pts ({cur_r:+.2f}R) ▼{C.RESET}"
            else:
                pnl_styled = f"⚪ {C.BOLD}{C.CYAN}0.00 pts (0.00R){C.RESET}"

            # Status Badge Styling
            if "T1" in t["status"]:
                st_badge = f"🛡️ {C.BOLD}{C.CYAN}{t['status']}{C.RESET}"
            elif t["direction"] == "LONG":
                st_badge = f"🟢 {C.BOLD}{C.GREEN}{t['status']}{C.RESET}"
            else:
                st_badge = f"🔴 {C.BOLD}{C.RED}{t['status']}{C.RESET}"

            be_tag = f" 🛡️ {C.BOLD}{C.CYAN}(BE SHIELD ACTIVE){C.RESET}" if t["t1_hit"] else ""

            print(f"• {C.BOLD}{C.WHITE}{t['symbol']:<12}{C.RESET} {dir_tag} {st_badge}")
            print(f"  Entry: {C.WHITE}{t['entry_price']:.2f}{C.RESET} | Live: {C.BOLD}{C.WHITE}{cur_p:.2f}{C.RESET}")
            print(f"  P&L  : {pnl_styled}")
            print(f"  SL   : 🔴 {C.RED}{t['stop_loss_price']:.2f}{C.RESET}{be_tag}")
            print(f"  T1   : 🔵 {C.CYAN}{t['t1_target_price']:.2f}{C.RESET} (+1.2R) | T2: 🟢 {C.GREEN}{t['target_price']:.2f}{C.RESET} (+{tgt_rr_t:.1f}R)")
            print(f"{C.GRAY}" + "-" * 50 + f"{C.RESET}")
    else:
        print(f" {C.GRAY}No active trades right now. Waiting for setups...{C.RESET}")

    # 3. Mobile Card Display: Completed Trades Today
    print("\n" + f"{C.BOLD}{C.MAGENTA}" + "=" * 50 + f"{C.RESET}")
    print(f" {C.BOLD}{C.MAGENTA}🏁 [COMPLETED TRADES TODAY]{C.RESET} {C.BOLD}{C.WHITE}({len(completed)}){C.RESET}")
    print(f"{C.BOLD}{C.MAGENTA}" + "=" * 50 + f"{C.RESET}")
    if completed:
        for t in completed:
            if t["direction"] == "LONG":
                dir_str = f"🟢 {C.BOLD}{C.GREEN}LONG{C.RESET}"
            else:
                dir_str = f"🔴 {C.BOLD}{C.RED}SHORT{C.RESET}"

            if "HIT" in t["status"] or "TARGET" in t["status"]:
                res_str = f"🎯 {C.BOLD}{C.GREEN}{t['status']}{C.RESET}"
            elif "BREAKEVEN" in t["status"] or "(BE)" in t["status"]:
                res_str = f"🛡️ {C.BOLD}{C.CYAN}{t['status']}{C.RESET}"
            else:
                res_str = f"❌ {C.BOLD}{C.RED}{t['status']}{C.RESET}"

            print(f"• {C.BOLD}{C.WHITE}{t['symbol']:<12}{C.RESET} ({dir_str}) | Trig: {C.GRAY}{t['trigger_time']}{C.RESET}")
            print(f"  Entry: {t['entry_price']:.2f} | SL: {t['stop_loss_price']:.2f}")
            print(f"  Outcome: {res_str}")
            print(f"{C.GRAY}" + "-" * 50 + f"{C.RESET}")
    else:
        print(f" {C.GRAY}No completed trades yet today.{C.RESET}")
    print(f"{C.BOLD}{C.MAGENTA}" + "=" * 50 + f"{C.RESET}\n")





class FyersMobileCallbackHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Suppress internal server logs

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/api/v1/auth/fyers/callback":
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")
            return

        query = urllib.parse.parse_qs(parsed.query)
        auth_code_list = query.get("auth_code") or query.get("code") or query.get("s_id")

        if not auth_code_list:
            self.send_response(400)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<h3>Missing auth_code parameter</h3>")
            return

        auth_code = auth_code_list[0]

        try:
            session_model = fyersModel.SessionModel(
                client_id=DEFAULT_CLIENT_ID,
                secret_key=DEFAULT_SECRET_KEY,
                redirect_uri=DEFAULT_REDIRECT_URI,
                response_type="code",
                grant_type="authorization_code"
            )
            session_model.set_token(auth_code)
            res = session_model.generate_token()

            if not isinstance(res, dict) or res.get("s") != "ok" or "access_token" not in res:
                err_msg = res.get("message", "Token generation failed") if isinstance(res, dict) else str(res)
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(f"<h3>Login Failed: {err_msg}</h3>".encode("utf-8"))
                return

            access_token = res["access_token"]

            # Save to fyers_token.txt so future runs are automatic
            with open(TOKEN_FILE, "w") as f:
                f.write(access_token)

            self.server.access_token = access_token

            # Render mobile-friendly confirmation page
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            html = """<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FYERS Login Successful</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; background: #0d1117; color: #c9d1d9; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; text-align: center; }
        .card { background: #161b22; padding: 30px; border-radius: 12px; border: 1px solid #30363d; margin: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        .badge { font-size: 40px; color: #3fb950; margin-bottom: 10px; }
        h1 { color: #f0f6fc; font-size: 20px; margin: 10px 0; }
        p { color: #8b949e; font-size: 14px; line-height: 1.5; }
        .btn { display: inline-block; margin-top: 15px; padding: 10px 20px; background: #238636; color: #fff; text-decoration: none; border-radius: 6px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">&#10004;</div>
        <h1>FYERS Login Successful!</h1>
        <p>Your session is authenticated & token saved.</p>
        <p><b>Please switch back to Termux</b> to view your live scanner.</p>
    </div>
</body>
</html>"""
            self.wfile.write(html.encode("utf-8"))

        except Exception as e:
            self.send_response(500)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(f"<h3>Internal Error: {e}</h3>".encode("utf-8"))


def open_mobile_browser(url: str):
    """Attempts multiple methods to open default browser on Android / Linux / Windows."""
    # 1. Android Activity Manager (am start)
    if os.system(f'am start -a android.intent.action.VIEW -d "{url}" > /dev/null 2>&1') == 0:
        return
    # 2. Termux open tool
    if os.system(f'termux-open-url "{url}" > /dev/null 2>&1') == 0:
        return
    # 3. Standard Python webbrowser
    try:
        webbrowser.open(url)
    except Exception:
        pass


def run_mobile_oauth_flow() -> Optional[str]:
    print("\n" + "=" * 50)
    print(" [AUTH NEEDED] Automatic FYERS Login")
    print("=" * 50)
    print(" Starting callback server on port 8000...")

    session_model = fyersModel.SessionModel(
        client_id=DEFAULT_CLIENT_ID,
        secret_key=DEFAULT_SECRET_KEY,
        redirect_uri=DEFAULT_REDIRECT_URI,
        response_type="code",
        grant_type="authorization_code"
    )
    auth_url = session_model.generate_authcode()

    try:
        server = HTTPServer(("0.0.0.0", 8000), FyersMobileCallbackHandler)
    except OSError as e:
        print(f"[ERROR] Port 8000 in use: {e}")
        return None

    server.access_token = None

    print("\nOpening FYERS login page in your browser...")
    open_mobile_browser(auth_url)

    print("\nIf browser did not open, tap or copy this link:")
    print(f"{auth_url}\n")
    print("Waiting for login in browser (Ctrl+C to abort)...")

    try:
        while server.access_token is None:
            server.handle_request()
    except KeyboardInterrupt:
        print("\n[INFO] Login cancelled by user.")
        server.server_close()
        return None

    server.server_close()
    return server.access_token


def get_authenticated_fyers(client_id: str, token_arg: Optional[str] = None):
    token = token_arg

    # 1. Check local environment or files
    if not token:
        # Check smm_trading.db (if on PC)
        for path in ["smm_trading.db", "../smm_trading.db", os.path.join(os.path.dirname(__file__), "..", "smm_trading.db")]:
            if os.path.exists(path):
                try:
                    import sqlite3
                    conn = sqlite3.connect(path)
                    c = conn.cursor()
                    c.execute("SELECT access_token FROM fyers_tokens ORDER BY id DESC LIMIT 1")
                    row = c.fetchone()
                    conn.close()
                    if row and row[0]:
                        token = row[0]
                        break
                except Exception:
                    pass

    if not token:
        env_tok = os.environ.get("FYERS_ACCESS_TOKEN")
        if env_tok:
            token = env_tok.strip()

    if not token and os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, "r") as f:
                c = f.read().strip()
                if c:
                    token = c
        except Exception:
            pass

    # 2. Test if existing token is valid
    if token:
        fyers = fyersModel.FyersModel(token=token, is_async=False, client_id=client_id, log_path=".")
        try:
            profile = fyers.get_profile()
            if isinstance(profile, dict) and profile.get("s") == "ok":
                user_name = profile.get("data", {}).get("name", "Trader")
                print(f"\n[AUTH OK] Connected to FYERS: {user_name}")
                return fyers, token
            else:
                err = profile.get("message", "Token expired")
                print(f"\n[AUTH EXPIRED] Saved token expired ({err}).")
        except Exception:
            pass

    # 3. Token is missing or expired: Launch automated mobile browser login!
    token = run_mobile_oauth_flow()
    if not token:
        print("[ERROR] Login could not be completed. Exiting.")
        sys.exit(1)

    fyers = fyersModel.FyersModel(token=token, is_async=False, client_id=client_id, log_path=".")
    try:
        profile = fyers.get_profile()
        user_name = profile.get("data", {}).get("name", "Trader") if isinstance(profile, dict) else "Trader"
        print(f"\n[AUTH OK] Connected to FYERS: {user_name}")
    except Exception:
        pass

    return fyers, token


def main():
    parser = argparse.ArgumentParser(description="KRAKEN Mobile Live Scanner (Android/Termux)")
    parser.add_argument("--token", type=str, default=None, help="FYERS access token")
    parser.add_argument("--client_id", type=str, default=DEFAULT_CLIENT_ID, help="FYERS Client ID")
    parser.add_argument("--interval", type=int, default=60, help="Poll interval in seconds (default: 60)")
    parser.add_argument("--loop", action="store_true", help="Run in continuous loop")
    args = parser.parse_args()

    if not HAS_FYERS:
        print("[ERROR] 'fyers_apiv3' is required. In Termux, run: pip install fyers-apiv3")
        sys.exit(1)

    fyers, token = get_authenticated_fyers(client_id=args.client_id, token_arg=args.token)

    engine = KrakenStrategyEngine()

    print("\n" + f"{C.BG_CYAN} =========================================== {C.RESET}")
    print(f" {C.BOLD}{C.WHITE}KRAKEN MOBILE [PRO COLOR ENGINE v2.0]{C.RESET}")
    print(f" 🟢 {C.GREEN}GREEN (BUY){C.RESET} | 🔴 {C.RED}RED (SELL){C.RESET} | 🛡️ {C.CYAN}BE SHIELD{C.RESET}")
    print(f" Tracking {len(NIFTY_SYMBOLS)} Nifty 50 Instruments (Interval: {args.interval}s)")
    print(f"{C.BG_CYAN} =========================================== {C.RESET}")



    if args.loop:
        try:
            while True:
                scan_mobile(fyers, engine, NIFTY_SYMBOLS)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n[INFO] Stopped by user.")
    else:
        scan_mobile(fyers, engine, NIFTY_SYMBOLS)


if __name__ == "__main__":
    main()
