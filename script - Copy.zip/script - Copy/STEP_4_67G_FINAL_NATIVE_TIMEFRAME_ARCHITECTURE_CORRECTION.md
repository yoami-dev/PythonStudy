# STEP 4.67G — FINAL NATIVE TIMEFRAME ARCHITECTURE CORRECTION

## Objective
Make historical research strategy-agnostic and capable of evaluating SMM, PAPA, FOME, GUE, SMC, and future strategies across arbitrary supported timeframes using **native candles stored in our own database**.

### Mandatory architectural rule
If a timeframe is supported by the upstream market-data source and is required for research, obtain/store that timeframe natively and read it directly from the database.

**Never resample 1m (or any other timeframe) to create a requested research timeframe when native data is available or expected.**

Historical research must be DB-first:
FYERS historical ingestion → native DB candles → native multi-timeframe provider → strategy adapter → strategy engine.

## 1. Native timeframe universe
Audit these required FYERS/project resolutions:

### Seconds
1S, 5S, 10S, 30S

### Minutes
1m, 2m, 3m, 4m, 5m, 10m, 15m, 20m, 30m, 60m, 120m, 240m

### Higher timeframe
1D

Also audit existing 1W support because current SMM profiles may require it.

Do not invent unsupported resolutions. Verify actual ingestion/API capability before implementing.

## 2. Database audit first
Inspect `market_candles` and report for INFY:
- timeframe
- row count
- minimum timestamp
- maximum timestamp

Also report platform-wide counts where useful.

Use this matrix:

| Timeframe | Required | In DB | Rows | Min | Max | Native |
|---|---|---|---:|---|---|---|
| 1S | YES | | | | | |
| 5S | YES | | | | | |
| 10S | YES | | | | | |
| 30S | YES | | | | | |
| 1m | YES | | | | | |
| 2m | YES | | | | | |
| 3m | YES | | | | | |
| 4m | YES | | | | | |
| 5m | YES | | | | | |
| 10m | YES | | | | | |
| 15m | YES | | | | | |
| 20m | YES | | | | | |
| 30m | YES | | | | | |
| 60m | YES | | | | | |
| 120m | YES | | | | | |
| 240m | YES | | | | | |
| 1D | YES | | | | | |
| 1W | AUDIT | | | | | |

Clearly distinguish:
- supported and stored
- supported but not stored
- unavailable/unsupported
- not currently needed by SMM but required for future research

## 3. Audit FYERS ingestion
Trace the existing historical-data ingestion path.

Determine which required native resolutions can be requested and stored.

If a resolution is missing:
- document the gap
- do not silently resample
- make only the smallest additive ingestion change if proven necessary
- do not change unrelated architecture

FYERS may be used during ingestion/update. Historical research itself must never call FYERS.

## 4. Native provider
Verify `HistoricalMultiTimeframeDataProvider` is strategy-agnostic and can retrieve arbitrary native timeframe values.

It must:
- query `market_candles` directly
- never call FYERS
- never call `CandleResampler`
- never synthesize missing timeframes
- enforce `candle_timestamp <= T`
- preserve chronological order
- preserve mutation isolation
- support efficient range preloading/slicing

Do not redesign APIs unnecessarily if the current provider already supports arbitrary timeframe lists.

## 5. Missing-data rule
If requested native timeframe is absent:

requested timeframe → no native DB candles → `NOT_EVALUATED`

Never:
requested 3m → resample 1m → evaluate.

## 6. SMM profile-chain verification
Existing SMM profiles must continue to work without modifying SMM rules/profiles.

Verify at minimum:

1. `1m + 5m + 30m`
2. `2m + 10m + 1h`
3. `15m + 1h + 1D`
4. `1h + 1D + 1W`

Each timeframe must come directly from the database.

If any required native timeframe is missing, return `NOT_EVALUATED`; never fall back to resampling.

## 7. Future strategy requirement
Do not hard-code SMM-only assumptions into the provider.

Future PAPA/FOME/GUE/SMC adapters must be able to request arbitrary native timeframe candles from the same provider.

Do not implement those strategies in this step.

## 8. Look-ahead
For every timeframe:
- timestamp < T → visible
- timestamp == T → visible
- timestamp > T → invisible

Verify this for multiple native timeframe classes.

## 9. Mandatory no-resampling tests
Add focused tests proving:
- native DB retrieval
- `CandleResampler.resample_1m_candles` calls = 0 during historical research
- FYERS history calls = 0 during historical research
- missing native timeframe → `NOT_EVALUATED`
- no fallback to another timeframe
- strict look-ahead protection
- SMM native chain verification

## 10. Performance
Range research must preload native timeframe data once and reuse it.

Do not reintroduce:
- repeated full-history resampling
- repeated DB queries per evaluation
- rebuilding higher timeframes from 1m

Do not optimize indicator calculations unless profiling proves it is necessary.

## 11. Hard exclusions
Do NOT modify:
- SMM rules, TIDE, WAVE, RIPPLE
- SMM indicators/final decision logic
- StrategyInputContext/StrategyResult/BaseStrategyAdapter
- existing SMMStrategyAdapter
- Strategy Registry
- Common Confluence Engine
- MultiStrategyResearchRunner
- HistoricalReplayEngine
- HistoricalOutcomeEvaluator
- Level Resolver
- broker/OMS/execution
- portfolio/accounting
- live trading
- database redesign
- UI redesign
- PAPA/FOME/GUE/SMC implementation

Only modify native market-data ingestion/storage/provider/research wiring if directly required.

## 12. Final report
Return:
A. Complete native timeframe inventory.
B. FYERS native ingestion capability.
C. Database gaps.
D. Provider verification.
E. Historical research resampling calls — expected 0.
F. Historical research FYERS calls — expected 0.
G. Look-ahead verification.
H. SMM chain results:
   - 1m/5m/30m
   - 2m/10m/1h
   - 15m/1h/1D
   - 1h/1D/1W
I. Exact test result `X/Y passed`.

Do not claim full-project regression unless the complete suite was actually executed.

## 13. Freeze rule
Do NOT freeze until:
1. the native timeframe universe is audited;
2. database gaps are documented;
3. arbitrary native timeframe retrieval is verified;
4. historical research performs zero resampling;
5. historical research performs zero FYERS calls;
6. look-ahead is verified;
7. existing SMM profiles use native candles;
8. missing native data produces `NOT_EVALUATED`;
9. focused tests pass.

STOP after this audit. Do not continue to another architectural step.
