@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Application Status Script
:: Location: D:\Milind\MyTradingPlatform\script\status_app.bat
:: ============================================================================

title SMM Trading Platform - Status Check

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%.."
set "PROJECT_ROOT=%CD%"
set "PORT=8000"

echo ============================================================================
echo   SMM Trading Platform Status Check
echo ============================================================================
echo Project Root : %PROJECT_ROOT%
echo Checking Port: %PORT%
echo.

set "FOUND_PID="
for /f "tokens=*" %%a in ('powershell -NoProfile -Command "(Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue).OwningProcess"') do (
    set "FOUND_PID=%%a"
)

if not defined FOUND_PID goto :not_running

echo [STATUS] Application is RUNNING (PID: %FOUND_PID%)
echo.
echo Testing Health Endpoint (http://127.0.0.1:%PORT%/api/v1/health)...
powershell -NoProfile -Command "try { $r = Invoke-RestMethod -Uri 'http://127.0.0.1:%PORT%/api/v1/health' -TimeoutSec 3; Write-Host '[HEALTH] Response:' ($r | ConvertTo-Json -Compress) } catch { Write-Host '[HEALTH] Could not reach health endpoint:' $_.Exception.Message }"
goto :done

:not_running
echo [STATUS] Application is STOPPED (No process listening on port %PORT%)

:done
echo.
echo ============================================================================
echo.
endlocal
