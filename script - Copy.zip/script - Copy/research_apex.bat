@echo off
setlocal enabledelayedexpansion

REM ===============================================================================
REM  APEX TRADING STRATEGY (>= 80% WIN RATE) — BACKTEST & DISCOVERY RUNNER
REM ===============================================================================
REM  Usage Examples:
REM    research_apex.bat -Symbol INFY,TCS,RELIANCE,LT -Timeframe 5m -StartDate 2026-09-01 -Open
REM    research_apex.bat -Symbol ALL -Timeframe 5m -StartDate 2026-09-01
REM ===============================================================================

set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%.."

set PY_EXE=venv\Scripts\python.exe
if not exist "%PY_EXE%" (
    set PY_EXE=python
)

"%PY_EXE%" -u "%SCRIPT_DIR%discover_apex_strategy.py" %*

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] APEX Strategy Discovery script exited with error code %ERRORLEVEL%.
)

endlocal
