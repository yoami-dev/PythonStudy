<#
================================================================================
SMM Trading Platform - Multi-Strategy Historical Research CLI (PowerShell)
Location: E:\Milind\MyTradingPlatform\script\research_strategy.ps1
================================================================================
Executes historical strategy research and outcome evaluation for:
- SMM  : Smart Money Model (Frozen multi-timeframe Tide/Wave/Ripple + indicators)
- PAPA : Price Action Pattern Analysis (Engulfing, Pinbars, Swing Structure)
- FOME : Flow Order Momentum Evaluation (VWAP deviation, Delta, Volume Expansion)
- GUE  : Gap-Unfill Execution (Opening Gaps, Gap-fill Targets, Continuation)
- SMC  : Smart Money Concepts (BOS/CHoCH, Order Blocks, Fair Value Gaps)

Parameters:
  -Symbol         : Instrument Symbol (Default: INFY)
  -Timeframe      : Candle Timeframe e.g. 1m, 2m, 3m, 5m, 15m, 30m, 1h, 1D (Default: 15m)
  -Strategies     : ALL | SMM,PAPA,FOME,GUE,SMC (Default: ALL)
  -StartDate      : YYYY-MM-DD (e.g. 2026-09-01)
  -StartTime      : HH:MM or HH:MM:SS (e.g. 09:30)
  -Lookback       : Context lookback candle count <= T (Default: 50)
  -FutureCandles  : Subsequent inspected future candles count > T (Default: 20)
  -NoHtml         : Switch to disable interactive HTML report generation
  -Open           : Switch to automatically open HTML report in default browser
  -ExportJson     : Switch or path to export raw evaluation JSON
  -Preset         : Preset deterministic scenario ID (e.g. TARGET_FIRST, SL_FIRST, AMBIGUOUS)
  -DbPath         : Custom path to SQLite database

Examples:
  .\script\research_strategy.ps1 -Symbol INFY -Timeframe 15m
  .\script\research_strategy.ps1 -Symbol TCS -Timeframe 15m -Open
  .\script\research_strategy.ps1 -Symbol RELIANCE -Timeframe 1m -Strategies SMM,PAPA,SMC
  .\script\research_strategy.ps1 -Symbol INFY -Timeframe 15m -StartDate 2026-09-01 -StartTime 09:30 -Open
  .\script\research_strategy.ps1 -Preset TARGET_FIRST -Open
#>

param (
    [Alias("Symbols")]
    [string]$Symbol = "INFY",

    [Alias("Timeframes")]
    [string]$Timeframe = "15m",

    [Alias("Strategy")]
    [string]$Strategies = "ALL",

    [string]$StartDate = "2017-07-03",

    [string]$EndDate = "",

    [string]$StartTime = "09:30",

    [int]$Lookback = 50,

    [int]$FutureCandles = 20,

    [switch]$NoHtml,

    [switch]$Open,

    [string]$ExportJson = "",

    [string]$DbPath = "",

    [Alias("TideTimeframe")]
    [string]$Tide = "",

    [Alias("WaveTimeframe")]
    [string]$Wave = ""
)


$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$PythonExe = Join-Path $ProjectRoot "venv\Scripts\python.exe"

if (-not (Test-Path $PythonExe)) {
    $PythonExe = "python"
}

$PyScript = Join-Path $ScriptDir "research_strategy.py"

if (-not (Test-Path $PyScript)) {
    Write-Host "[ERROR] Python research script not found: $PyScript" -ForegroundColor Red
    exit 1
}

# Construct argument list
$PyArgs = @(
    $PyScript,
    "--symbol", $Symbol,
    "--timeframe", $Timeframe,
    "--strategies", $Strategies,
    "--lookback", $Lookback.ToString(),
    "--future-count", $FutureCandles.ToString()
)

if ($StartDate) {
    $PyArgs += @("--start-date", $StartDate)
}

if ($EndDate) {
    $PyArgs += @("--end-date", $EndDate)
}

if ($StartTime) {
    $PyArgs += @("--start-time", $StartTime)
}

if ($Preset) {
    $PyArgs += @("--preset", $Preset)
}

if ($DbPath) {
    $PyArgs += @("--db-path", $DbPath)
}

if ($NoHtml) {
    $PyArgs += @("--no-html")
}

if ($Open) {
    $PyArgs += @("--open")
}

if ($ExportJson) {
    $PyArgs += @("--export-json", $ExportJson)
}

if ($Tide) {
    $PyArgs += @("--tide", $Tide)
}

if ($Wave) {
    $PyArgs += @("--wave", $Wave)
}

# Execute Python script
& $PythonExe -u @PyArgs
