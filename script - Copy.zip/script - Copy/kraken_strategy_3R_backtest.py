#!/usr/bin/env python3
"""
===============================================================================
 KRAKEN PRECISION 3R - SQLITE BACKTESTER
===============================================================================

Purpose
-------
Backtest the current KRAKEN Precision 3R strategy against 5-minute OHLCV data
already stored in smm_trading.db.

IMPORTANT
---------
1. No FYERS API is used.
2. No future candle is used to create an entry signal.
3. Signals are evaluated candle-by-candle.
4. Backtest session is 09:15 through 15:15 IST, inclusive.
5. NIFTY macro bias/regime is also calculated only from candles available up
   to the signal candle.
6. If both SL and target are touched in the same 5-minute candle, SL is
   conservatively assumed to happen first because OHLC data does not reveal
   the intrabar sequence.
7. This script does NOT manufacture trades or force a target win rate.

Default database:
    <project_root>/smm_trading.db

Examples:
    python kraken_strategy_backtest.py
    python kraken_strategy_backtest.py --date 2026-09-08
    python kraken_strategy_backtest.py --db D:\\Milind\\MyTradingPlatform\\smm_trading.db
    python kraken_strategy_backtest.py --date 2026-09-08 --rr 3 --t1 1.2

The database schema is discovered automatically. If your database uses unusual
column/table names, the script prints the available SQLite schema so it can be
mapped easily.
===============================================================================
"""

import os
import sys
import sqlite3
import argparse
import math
from datetime import datetime, timezone, timedelta, time as dtime
from zoneinfo import ZoneInfo
from collections import defaultdict

IST = ZoneInfo("Asia/Kolkata")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_DB = os.path.join(PROJECT_ROOT, "smm_trading.db")

NIFTY_SYMBOL_ALIASES = {
    "NSE:NIFTY50-INDEX",
    "NIFTY50-INDEX",
    "NIFTY50",
    "NIFTY",
    "NIFTY_50",
    "NIFTY50INDEX",
}

STOCK_SYMBOLS = [
    "SUNPHARMA", "SBIN", "MARUTI", "BRITANNIA", "WIPRO",
    "BAJAJ-AUTO", "BAJAJFINSV", "BAJFINANCE", "BHARTIARTL", "BPCL",
    "CIPLA", "COALINDIA", "DRREDDY", "EICHERMOT", "GRASIM",
    "HCLTECH", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO", "HINDALCO",
    "HINDUNILVR", "ICICIBANK", "INDUSINDBK", "INFY", "ITC",
    "JSWSTEEL", "KOTAKBANK", "LT", "M&M", "NESTLEIND",
    "NTPC", "ONGC", "POWERGRID", "RELIANCE", "SBILIFE",
    "SHRIRAMFIN", "TATACONSUM", "TATASTEEL", "TCS", "TECHM",
    "TITAN", "TRENT", "ULTRACEMCO"
]


# =============================================================================
# INDICATORS - same calculation family used by the attached strategy
# =============================================================================

def closes(candles):
    return [float(x["close"]) for x in candles]


def ema(values, period):
    if not values:
        return 0.0
    alpha = 2.0 / (period + 1.0)
    value = float(values[0])
    for v in values[1:]:
        value = alpha * float(v) + (1.0 - alpha) * value
    return value


def atr(candles, period=14):
    if len(candles) < 2:
        return 0.0
    trs = []
    prev_close = float(candles[0]["close"])
    for c in candles[1:]:
        h = float(c["high"])
        l = float(c["low"])
        trs.append(max(h - l, abs(h - prev_close), abs(l - prev_close)))
        prev_close = float(c["close"])
    if not trs:
        return 0.0
    w = trs[-period:]
    return sum(w) / len(w)


def rsi(candles, period=14):
    cs = closes(candles)
    if len(cs) <= period:
        return 50.0
    gains, losses = [], []
    for i in range(1, len(cs)):
        d = cs[i] - cs[i - 1]
        gains.append(max(d, 0.0))
        losses.append(max(-d, 0.0))
    gains = gains[-period:]
    losses = losses[-period:]
    ag = sum(gains) / period
    al = sum(losses) / period
    if al == 0:
        return 100.0 if ag > 0 else 50.0
    rs = ag / al
    return 100.0 - 100.0 / (1.0 + rs)


def adx(candles, period=14):
    if len(candles) < period + 2:
        return 0.0

    trs, plus_dm, minus_dm = [], [], []
    ph = float(candles[0]["high"])
    pl = float(candles[0]["low"])
    pc = float(candles[0]["close"])

    for c in candles[1:]:
        h = float(c["high"])
        l = float(c["low"])
        cl = float(c["close"])
        up = h - ph
        down = pl - l

        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
        plus_dm.append(up if up > down and up > 0 else 0.0)
        minus_dm.append(down if down > up and down > 0 else 0.0)

        ph, pl, pc = h, l, cl

    tr = trs[-period:]
    pdm = plus_dm[-period:]
    mdm = minus_dm[-period:]

    avtr = sum(tr) / period if tr else 0.0
    if avtr <= 0:
        return 0.0

    pdi = 100.0 * (sum(pdm) / period) / avtr
    mdi = 100.0 * (sum(mdm) / period) / avtr
    denom = pdi + mdi

    return 100.0 * abs(pdi - mdi) / denom if denom > 0 else 0.0


def session_vwap(candles):
    """VWAP using only candles up to the current candle's session."""
    if not candles:
        return 0.0

    session_date = candles[-1]["candle_timestamp"].astimezone(IST).date()
    pv = 0.0
    vv = 0.0

    for c in candles:
        dt = c["candle_timestamp"].astimezone(IST)
        if dt.date() != session_date:
            continue

        h = float(c["high"])
        l = float(c["low"])
        cl = float(c["close"])
        vol = max(float(c["volume"]), 1.0)

        pv += ((h + l + cl) / 3.0) * vol
        vv += vol

    return pv / vv if vv else float(candles[-1]["close"])


def rvol(candles, period=20):
    if len(candles) < period + 1:
        return 0.0

    current = max(float(candles[-1]["volume"]), 0.0)
    previous = [
        max(float(x["volume"]), 0.0)
        for x in candles[-period - 1:-1]
    ]

    avg = sum(previous) / period if previous else 0.0
    return current / avg if avg > 0 else 0.0


def bar_stats(c):
    o = float(c["open"])
    h = float(c["high"])
    l = float(c["low"])
    cl = float(c["close"])
    rng = max(h - l, 1e-9)
    body = abs(cl - o)
    upper = h - max(o, cl)
    lower = min(o, cl) - l
    return o, h, l, cl, rng, body, upper, lower


# =============================================================================
# STRATEGY - based on the attached KRAKEN Precision 3R file
# =============================================================================

def evaluate_signal(candles, index_bias, market_regime, target_rr=3.0,
                     t1_rr=1.2):
    """
    Evaluate ONLY the current candle.

    candles contains data through the current candle and never beyond it.
    """
    if len(candles) < 60:
        return None

    c = candles[-1]
    prev = candles[-2]

    o, h, l, cl, rng, body, upper, lower = bar_stats(c)
    _, ph, pl, _, _, _, _, _ = bar_stats(prev)

    avtr = atr(candles, 14)
    if avtr <= 0:
        return None

    cs = closes(candles)
    ema20 = ema(cs, 20)
    ema50 = ema(cs, 50)

    # The attached strategy uses EMA100 as the fallback when fewer than
    # 200 candles are available. We preserve that behavior.
    ema200 = ema(cs, 200) if len(cs) >= 200 else ema(cs, min(100, len(cs)))

    vwap = session_vwap(candles)
    adx_value = adx(candles, 14)
    rvol_value = rvol(candles, 20)
    rsi_value = rsi(candles, 14)

    dt = c["candle_timestamp"].astimezone(IST)
    tm = dt.time()

    # Requested complete NSE session.
    if tm < dtime(9, 15) or tm > dtime(15, 15):
        return None

    # Macro confirmation at THIS candle only.
    if market_regime != "TRENDING":
        return None

    if index_bias not in ("BULLISH", "BEARISH"):
        return None

    if adx_value < 22.0:
        return None

    if rvol_value < 1.30:
        return None

    if abs(cl - vwap) > 1.25 * avtr:
        return None

    bullish_structure = (
        cl > ema20 > ema50
        and ema50 >= ema200
        and cl > vwap
    )

    bearish_structure = (
        cl < ema20 < ema50
        and ema50 <= ema200
        and cl < vwap
    )

    bull_rejection = (
        cl > o
        and lower >= max(body * 0.75, rng * 0.25)
        and cl >= l + rng * 0.65
    )

    bear_rejection = (
        cl < o
        and upper >= max(body * 0.75, rng * 0.25)
        and cl <= l + rng * 0.35
    )

    long_trigger = cl > ph
    short_trigger = cl < pl

    # Pullback test. Each historical pullback candle is evaluated using
    # information available at that pullback candle only.
    recent = candles[-5:-1]
    long_pullback = False
    short_pullback = False

    for j, x in enumerate(recent):
        x_end = len(candles) - 4 + j
        hist = candles[:x_end + 1]

        x_atr = atr(hist, 14)
        if x_atr <= 0:
            x_atr = avtr

        x_ema20 = ema(closes(hist), 20)
        x_vwap = session_vwap(hist)

        zone_long = max(x_ema20, x_vwap)
        zone_short = min(x_ema20, x_vwap)

        if float(x["low"]) <= zone_long + 0.35 * x_atr:
            long_pullback = True

        if float(x["high"]) >= zone_short - 0.35 * x_atr:
            short_pullback = True

    if (
        index_bias == "BULLISH"
        and bullish_structure
        and bull_rejection
        and long_trigger
        and long_pullback
    ):
        sl = min(float(x["low"]) for x in candles[-6:]) - 0.15 * avtr
        risk = cl - sl

        if 0.35 * avtr <= risk <= 1.50 * avtr:
            return {
                "direction": "LONG",
                "entry": cl,
                "sl": sl,
                "risk": risk,
                "t1": cl + risk * t1_rr,
                "t2": cl + risk * target_rr,
                "rr": target_rr,
                "signal_time": dt,
                "adx": adx_value,
                "rvol": rvol_value,
                "rsi": rsi_value,
            }

    if (
        index_bias == "BEARISH"
        and bearish_structure
        and bear_rejection
        and short_trigger
        and short_pullback
    ):
        sl = max(float(x["high"]) for x in candles[-6:]) + 0.15 * avtr
        risk = sl - cl

        if 0.35 * avtr <= risk <= 1.50 * avtr:
            return {
                "direction": "SHORT",
                "entry": cl,
                "sl": sl,
                "risk": risk,
                "t1": cl - risk * t1_rr,
                "t2": cl - risk * target_rr,
                "rr": target_rr,
                "signal_time": dt,
                "adx": adx_value,
                "rvol": rvol_value,
                "rsi": rsi_value,
            }

    return None


# =============================================================================
# SQLITE SCHEMA / DATA LOADING
# =============================================================================

def quote_ident(name):
    return '"' + str(name).replace('"', '""') + '"'


def get_tables(conn):
    rows = conn.execute("""
        SELECT name
        FROM sqlite_master
        WHERE type='table'
          AND name NOT LIKE 'sqlite_%'
        ORDER BY name
    """).fetchall()
    return [r[0] for r in rows]


def get_columns(conn, table):
    return [r[1] for r in conn.execute(
        f"PRAGMA table_info({quote_ident(table)})"
    ).fetchall()]


def normalize_name(x):
    return "".join(ch for ch in str(x).lower() if ch.isalnum())


def find_column(columns, candidates):
    norm = {normalize_name(c): c for c in columns}

    for candidate in candidates:
        n = normalize_name(candidate)
        if n in norm:
            return norm[n]

    # Fuzzy fallback.
    for c in columns:
        nc = normalize_name(c)
        for candidate in candidates:
            n = normalize_name(candidate)
            if n in nc or nc in n:
                return c

    return None


def detect_market_table(conn):
    tables = get_tables(conn)

    scored = []

    for table in tables:
        cols = get_columns(conn, table)

        symbol_col = find_column(cols, [
            "symbol", "ticker", "tradingsymbol", "instrument", "scrip",
            "stock_symbol", "security"
        ])
        time_col = find_column(cols, [
            "candle_timestamp", "timestamp", "datetime", "date_time",
            "candle_time", "time", "ts", "epoch", "epoch_time"
        ])
        open_col = find_column(cols, ["open", "open_price", "o"])
        high_col = find_column(cols, ["high", "high_price", "h"])
        low_col = find_column(cols, ["low", "low_price", "l"])
        close_col = find_column(cols, ["close", "close_price", "c"])
        volume_col = find_column(cols, ["volume", "vol", "v"])

        score = sum(x is not None for x in [
            symbol_col, time_col, open_col, high_col, low_col, close_col,
            volume_col
        ])

        if score >= 5:
            scored.append((
                score, table, symbol_col, time_col,
                open_col, high_col, low_col, close_col, volume_col
            ))

    if not scored:
        return None, None

    scored.sort(reverse=True)
    return scored[0][1], scored[0][2:]


def parse_timestamp(value):
    if value is None:
        return None

    if isinstance(value, (int, float)):
        x = float(value)
        # FYERS epoch timestamps are seconds. Support milliseconds too.
        if x > 10_000_000_000:
            x /= 1000.0
        return datetime.fromtimestamp(x, tz=timezone.utc).astimezone(IST)

    s = str(value).strip()

    # Numeric string epoch.
    try:
        x = float(s)
        if x > 10_000_000_000:
            x /= 1000.0
        if x > 1_000_000_000:
            return datetime.fromtimestamp(x, tz=timezone.utc).astimezone(IST)
    except ValueError:
        pass

    s = s.replace("Z", "+00:00")

    formats = [
        "%Y-%m-%d %H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d-%m-%Y %H:%M:%S",
        "%d-%m-%Y %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
    ]

    for fmt in formats:
        try:
            dt = datetime.strptime(s, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=IST)
            return dt.astimezone(IST)
        except ValueError:
            continue

    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=IST)
        return dt.astimezone(IST)
    except ValueError:
        return None


def load_market_data(conn, table, mapping):
    (
        symbol_col, time_col, open_col, high_col, low_col, close_col,
        volume_col
    ) = mapping

    sql = f"""
        SELECT
            {quote_ident(symbol_col)},
            {quote_ident(time_col)},
            {quote_ident(open_col)},
            {quote_ident(high_col)},
            {quote_ident(low_col)},
            {quote_ident(close_col)},
            {quote_ident(volume_col)}
        FROM {quote_ident(table)}
    """

    rows = conn.execute(sql).fetchall()

    data = defaultdict(list)

    for row in rows:
        symbol = str(row[0]).strip()
        dt = parse_timestamp(row[1])
        if dt is None:
            continue

        try:
            item = {
                "candle_timestamp": dt,
                "open": float(row[2]),
                "high": float(row[3]),
                "low": float(row[4]),
                "close": float(row[5]),
                "volume": float(row[6] or 0),
            }
        except (TypeError, ValueError):
            continue

        data[symbol].append(item)

    for symbol in data:
        data[symbol].sort(key=lambda x: x["candle_timestamp"])

    return data


# =============================================================================
# NIFTY MACRO - NO LOOK-AHEAD
# =============================================================================

def canonical_is_nifty(symbol):
    s = str(symbol).strip().upper()
    s = s.replace("-EQ", "")
    return (
        s in NIFTY_SYMBOL_ALIASES
        or "NIFTY50" in s
        or "NIFTY50-INDEX" in s
        or "NIFTY_50" in s
    )


def find_nifty_series(data):
    for symbol, candles in data.items():
        if canonical_is_nifty(symbol):
            return symbol, candles

    return None, []


def build_nifty_states(nifty_candles):
    """
    Create a macro state for every NIFTY candle.

    Critical:
        The state at 10:00 uses only NIFTY candles <= 10:00.
        It does not know the eventual day's high/low.
    """
    states = {}

    by_date = defaultdict(list)
    for c in nifty_candles:
        by_date[c["candle_timestamp"].date()].append(c)

    for day, day_candles in by_date.items():
        cum_pv = 0.0
        cum_vol = 0.0
        day_high = None
        day_low = None
        day_open = None

        for i, c in enumerate(day_candles):
            dt = c["candle_timestamp"].astimezone(IST)

            if dt.time() < dtime(9, 15) or dt.time() > dtime(15, 15):
                continue

            o = float(c["open"])
            h = float(c["high"])
            l = float(c["low"])
            cl = float(c["close"])
            vol = max(float(c["volume"]), 1.0)

            if day_open is None:
                day_open = o

            day_high = h if day_high is None else max(day_high, h)
            day_low = l if day_low is None else min(day_low, l)

            tp = (h + l + cl) / 3.0
            cum_pv += tp * vol
            cum_vol += vol

            vwap = cum_pv / cum_vol if cum_vol else cl
            diff = cl - vwap
            pct_diff = diff / vwap if vwap else 0.0

            if abs(pct_diff) <= 0.0003:
                bias = "NEUTRAL"
            elif diff > 0:
                bias = "BULLISH"
            else:
                bias = "BEARISH"

            day_range_pct = (
                (day_high - day_low) / day_open * 100.0
                if day_open else 0.0
            )

            regime = (
                "RANGEBOUND"
                if day_range_pct < 0.85
                else "TRENDING"
            )

            key = dt.strftime("%Y-%m-%d %H:%M")
            states[key] = {
                "bias": bias,
                "regime": regime,
                "price": cl,
                "vwap": vwap,
                "range_pct": day_range_pct,
            }

    return states


# =============================================================================
# TRADE LIFECYCLE
# =============================================================================

def run_symbol_backtest(symbol, candles, nifty_states, target_rr, t1_rr,
                        selected_date):
    """
    Replay one symbol one candle at a time.

    Entry uses candles[:idx+1].
    Exit starts from candles AFTER the signal candle, avoiding any assumption
    about the intrabar order of entry versus the entry candle's high/low.
    """
    session = [
        c for c in candles
        if c["candle_timestamp"].date() == selected_date
        and dtime(9, 15) <= c["candle_timestamp"].time() <= dtime(15, 15)
    ]

    if not session:
        return []

    # Need pre-session historical candles for EMA/ATR/ADX/RVOL warm-up.
    history = [
        c for c in candles
        if c["candle_timestamp"] < session[0]["candle_timestamp"]
    ]

    # At least 60 candles are required by the strategy.
    if len(history) < 60:
        return []

    working = history + session
    session_start_idx = len(history)

    trades = []
    active = None

    for idx in range(session_start_idx, len(working)):
        c = working[idx]
        dt = c["candle_timestamp"].astimezone(IST)

        key = dt.strftime("%Y-%m-%d %H:%M")
        macro = nifty_states.get(key)

        if macro is None:
            continue

        # -------------------------------------------------------------
        # ENTRY
        # -------------------------------------------------------------
        if active is None:
            signal = evaluate_signal(
                working[:idx + 1],
                macro["bias"],
                macro["regime"],
                target_rr=target_rr,
                t1_rr=t1_rr,
            )

            if signal is None:
                continue

            active = {
                "symbol": symbol,
                "direction": signal["direction"],
                "entry": signal["entry"],
                "initial_sl": signal["sl"],
                "sl": signal["sl"],
                "t1": signal["t1"],
                "t2": signal["t2"],
                "risk": signal["risk"],
                "rr": signal["rr"],
                "entry_time": dt,
                "exit_time": None,
                "status": "ACTIVE",
                "t1_hit": False,
                "bars_held": 0,
                "adx": signal["adx"],
                "rvol": signal["rvol"],
                "rsi": signal["rsi"],
                "macro_bias": macro["bias"],
                "macro_regime": macro["regime"],
            }

            continue

        # -------------------------------------------------------------
        # MANAGE OPEN TRADE
        # -------------------------------------------------------------
        # Entry candle itself is not used for exit because we enter at its
        # close. This avoids using the candle's earlier high/low after entry.
        if dt <= active["entry_time"]:
            continue

        active["bars_held"] += 1

        high = float(c["high"])
        low = float(c["low"])

        if active["direction"] == "LONG":
            hit_t1 = (not active["t1_hit"]) and high >= active["t1"]
            hit_t2 = high >= active["t2"]
            hit_sl = low <= active["sl"]

            # Conservative OHLC rule: if both are touched, SL wins.
            if hit_sl and (hit_t1 or hit_t2):
                if active["t1_hit"]:
                    active["status"] = "BREAKEVEN"
                else:
                    active["status"] = "STOP LOSS"
                active["exit_price"] = active["sl"]
                active["exit_time"] = dt
                trades.append(active)
                active = None

            elif hit_t1:
                active["t1_hit"] = True
                active["sl"] = active["entry"]

                # If T2 is also hit, count the full 3R target.
                if hit_t2:
                    active["status"] = "TARGET 2"
                    active["exit_price"] = active["t2"]
                    active["exit_time"] = dt
                    trades.append(active)
                    active = None
                else:
                    active["status"] = "T1 / BREAKEVEN"

            elif hit_t2:
                active["status"] = "TARGET 2"
                active["exit_price"] = active["t2"]
                active["exit_time"] = dt
                trades.append(active)
                active = None

            elif hit_sl:
                active["status"] = (
                    "BREAKEVEN" if active["t1_hit"] else "STOP LOSS"
                )
                active["exit_price"] = active["sl"]
                active["exit_time"] = dt
                trades.append(active)
                active = None

        else:
            hit_t1 = (not active["t1_hit"]) and low <= active["t1"]
            hit_t2 = low <= active["t2"]
            hit_sl = high >= active["sl"]

            if hit_sl and (hit_t1 or hit_t2):
                if active["t1_hit"]:
                    active["status"] = "BREAKEVEN"
                else:
                    active["status"] = "STOP LOSS"
                active["exit_price"] = active["sl"]
                active["exit_time"] = dt
                trades.append(active)
                active = None

            elif hit_t1:
                active["t1_hit"] = True
                active["sl"] = active["entry"]

                if hit_t2:
                    active["status"] = "TARGET 2"
                    active["exit_price"] = active["t2"]
                    active["exit_time"] = dt
                    trades.append(active)
                    active = None
                else:
                    active["status"] = "T1 / BREAKEVEN"

            elif hit_t2:
                active["status"] = "TARGET 2"
                active["exit_price"] = active["t2"]
                active["exit_time"] = dt
                trades.append(active)
                active = None

            elif hit_sl:
                active["status"] = (
                    "BREAKEVEN" if active["t1_hit"] else "STOP LOSS"
                )
                active["exit_price"] = active["sl"]
                active["exit_time"] = dt
                trades.append(active)
                active = None

    # Any position still open at 15:15 is marked OPEN AT CLOSE, not fabricated
    # as a win/loss. Its mark-to-market result is calculated separately.
    if active is not None:
        last = session[-1]
        active["status"] = "OPEN AT 15:15"
        active["exit_price"] = float(last["close"])
        active["exit_time"] = last["candle_timestamp"].astimezone(IST)
        trades.append(active)

    return trades


def trade_r_multiple(t):
    entry = t["entry"]
    exit_price = t["exit_price"]
    risk = t["risk"]

    if risk <= 0:
        return 0.0

    if t["direction"] == "LONG":
        return (exit_price - entry) / risk

    return (entry - exit_price) / risk


# =============================================================================
# REPORTING
# =============================================================================

def print_header(db_path, selected_date, table, nifty_symbol, total_symbols):
    print("=" * 120)
    print(" KRAKEN PRECISION 3R - HISTORICAL BACKTEST")
    print("=" * 120)
    print(f" Database       : {db_path}")
    print(f" Backtest date  : {selected_date}")
    print(" Timeframe      : 5 minutes")
    print(" Session        : 09:15 AM - 03:15 PM IST")
    print(" Target         : +3.0R")
    print(" T1             : +1.2R")
    print(" Look-ahead     : DISABLED")
    print(f" Data table     : {table}")
    print(f" NIFTY series   : {nifty_symbol or 'NOT FOUND'}")
    print(f" Stock universe : {total_symbols}")
    print("=" * 120)


def print_trades(trades):
    print("\n" + "=" * 145)
    print(" TRADE-BY-TRADE RESULTS")
    print("=" * 145)

    if not trades:
        print(" No trades generated.")
        return

    print(
        f"{'SYMBOL':<13} {'DIR':<6} {'ENTRY TIME':<17} "
        f"{'ENTRY':>10} {'SL':>10} {'T1':>10} {'T2':>10} "
        f"{'EXIT TIME':<17} {'EXIT':>10} {'RESULT':<17} {'R':>8}"
    )
    print("-" * 145)

    for t in sorted(trades, key=lambda x: x["entry_time"]):
        result_r = trade_r_multiple(t)
        print(
            f"{t['symbol']:<13} "
            f"{t['direction']:<6} "
            f"{t['entry_time'].strftime('%H:%M'):<17} "
            f"{t['entry']:>10.2f} "
            f"{t['initial_sl']:>10.2f} "
            f"{t['t1']:>10.2f} "
            f"{t['t2']:>10.2f} "
            f"{t['exit_time'].strftime('%H:%M'):<17} "
            f"{t['exit_price']:>10.2f} "
            f"{t['status']:<17} "
            f"{result_r:>+8.2f}"
        )


def print_summary(trades):
    total = len(trades)
    targets = sum(t["status"] == "TARGET 2" for t in trades)
    sl = sum(t["status"] == "STOP LOSS" for t in trades)
    be = sum(t["status"] == "BREAKEVEN" for t in trades)
    open_close = sum(t["status"] == "OPEN AT 15:15" for t in trades)
    t1_be = sum(t["status"] == "T1 / BREAKEVEN" for t in trades)

    # Closed trades only for win-rate.
    closed = [t for t in trades if t["status"] != "OPEN AT 15:15"]
    decisive = [
        t for t in closed
        if t["status"] in ("TARGET 2", "STOP LOSS")
    ]

    wins = sum(t["status"] == "TARGET 2" for t in decisive)
    losses = sum(t["status"] == "STOP LOSS" for t in decisive)

    win_rate = wins / len(decisive) * 100.0 if decisive else 0.0

    r_values = [trade_r_multiple(t) for t in trades]
    closed_r_values = [
        trade_r_multiple(t) for t in closed
        if t["status"] != "T1 / BREAKEVEN"
    ]

    total_r = sum(r_values)
    avg_r = sum(r_values) / len(r_values) if r_values else 0.0

    gross_profit = sum(x for x in r_values if x > 0)
    gross_loss = abs(sum(x for x in r_values if x < 0))
    profit_factor = (
        gross_profit / gross_loss
        if gross_loss > 0 else float("inf")
    )

    print("\n" + "=" * 120)
    print(" BACKTEST SUMMARY")
    print("=" * 120)
    print(f" Total trades             : {total}")
    print(f" Target 2 (+3R)           : {targets}")
    print(f" Stop loss                : {sl}")
    print(f" Breakeven after T1       : {be}")
    print(f" T1 reached / still open  : {t1_be}")
    print(f" Open at 15:15            : {open_close}")
    print(f" Decisive trades          : {len(decisive)}")
    print(f" Win rate (T2 vs SL)      : {win_rate:.2f}%")
    print(f" Total R                  : {total_r:+.2f}R")
    print(f" Average R / trade        : {avg_r:+.2f}R")
    print(
        f" Profit factor            : "
        f"{profit_factor:.2f}" if math.isfinite(profit_factor)
        else " Profit factor            : INF"
    )
    print("=" * 120)

    print("\n IMPORTANT:")
    print(" - 70-80% win rate is a target for validation, NOT a forced result.")
    print(" - A trade is only generated when the full setup existed at that candle.")
    print(" - No future candle is used to create the signal.")
    print(" - Same-candle SL/target conflicts are handled conservatively.")
    print(" - OPEN AT 15:15 is not counted as a fabricated win or loss.")


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="KRAKEN Precision 3R SQLite historical backtester"
    )

    parser.add_argument(
        "--db",
        default=DEFAULT_DB,
        help=f"SQLite database path (default: {DEFAULT_DB})"
    )

    parser.add_argument(
        "--date",
        default=None,
        help="Backtest date YYYY-MM-DD. Default: latest date in database."
    )

    parser.add_argument(
        "--rr",
        type=float,
        default=3.0,
        help="Target R multiple (default: 3.0)"
    )

    parser.add_argument(
        "--t1",
        type=float,
        default=1.2,
        help="T1 R multiple (default: 1.2)"
    )

    parser.add_argument(
        "--all-symbols",
        action="store_true",
        help="Backtest every non-NIFTY symbol found in the database."
    )

    parser.add_argument(
        "--symbols",
        nargs="*",
        default=None,
        help="Optional explicit stock symbols."
    )

    args = parser.parse_args()

    if not os.path.exists(args.db):
        print("\n[ERROR] SQLite database not found:")
        print(f"        {args.db}")
        print("\nUse:")
        print("  python kraken_strategy_backtest.py --db D:\\path\\smm_trading.db")
        sys.exit(1)

    conn = sqlite3.connect(args.db)

    try:
        table, mapping = detect_market_table(conn)

        if table is None:
            print("\n[ERROR] Could not automatically identify an OHLCV market-data table.")
            print("\nAvailable SQLite tables and columns:")
            for t in get_tables(conn):
                print(f"\n  {t}")
                print(f"    {get_columns(conn, t)}")
            sys.exit(2)

        print(f"[INFO] Market data table detected: {table}")
        print(f"[INFO] Columns: {mapping}")

        data = load_market_data(conn, table, mapping)

        if not data:
            print("[ERROR] No usable OHLCV rows found.")
            sys.exit(2)

        nifty_symbol, nifty_candles = find_nifty_series(data)

        if not nifty_candles:
            print("\n[ERROR] NIFTY 50 5-minute data was not found in the database.")
            print("The strategy requires NIFTY macro bias/regime confirmation.")
            print("\nDetected symbols (sample):")
            for s in sorted(data)[:100]:
                print(f"  {s}")
            sys.exit(3)

        nifty_states = build_nifty_states(nifty_candles)

        all_dates = sorted({
            c["candle_timestamp"].date()
            for candles in data.values()
            for c in candles
        })

        if not all_dates:
            print("[ERROR] No valid dates found.")
            sys.exit(2)

        if args.date:
            try:
                selected_date = datetime.strptime(
                    args.date, "%Y-%m-%d"
                ).date()
            except ValueError:
                print("[ERROR] --date must be YYYY-MM-DD")
                sys.exit(2)
        else:
            selected_date = all_dates[-1]

        if selected_date not in all_dates:
            print(
                f"[ERROR] Date {selected_date} is not present in the database."
            )
            print(
                "Available dates:",
                ", ".join(str(x) for x in all_dates[-20:])
            )
            sys.exit(2)

        if args.symbols:
            wanted = {x.upper() for x in args.symbols}
            selected_symbols = [
                s for s in data
                if s.upper().replace("-EQ", "") in wanted
            ]
        elif args.all_symbols:
            selected_symbols = [
                s for s in data
                if not canonical_is_nifty(s)
            ]
        else:
            # Prefer the same 43-symbol universe as the live scanner.
            wanted = {x.upper() for x in STOCK_SYMBOLS}
            selected_symbols = [
                s for s in data
                if s.upper().replace("-EQ", "") in wanted
            ]

        if not selected_symbols:
            print("\n[ERROR] None of the requested stock symbols were found.")
            print("Use --all-symbols to test every symbol in the database.")
            print("\nDatabase symbols:")
            for s in sorted(data):
                print(f"  {s}")
            sys.exit(4)

        print_header(
            args.db,
            selected_date,
            table,
            nifty_symbol,
            len(selected_symbols)
        )

        # Show macro state at the start, middle and end of the session.
        day_macro = {
            k: v for k, v in nifty_states.items()
            if k.startswith(str(selected_date))
        }

        print("\nNIFTY MACRO STATES FROM DATABASE")
        print("-" * 120)

        if day_macro:
            for hhmm in ("09:15", "10:00", "12:00", "14:00", "15:15"):
                key = f"{selected_date} {hhmm}"
                if key in nifty_states:
                    m = nifty_states[key]
                    print(
                        f" {hhmm} | Bias={m['bias']:<7} | "
                        f"Regime={m['regime']:<10} | "
                        f"NIFTY={m['price']:.2f} | "
                        f"VWAP={m['vwap']:.2f} | "
                        f"Range={m['range_pct']:.2f}%"
                    )

        all_trades = []
        symbol_stats = []

        print("\n[INFO] Running candle-by-candle backtest...")

        for n, symbol in enumerate(sorted(selected_symbols), 1):
            candles = data[symbol]

            trades = run_symbol_backtest(
                symbol,
                candles,
                nifty_states,
                target_rr=args.rr,
                t1_rr=args.t1,
                selected_date=selected_date,
            )

            all_trades.extend(trades)

            if trades:
                targets = sum(t["status"] == "TARGET 2" for t in trades)
                stops = sum(t["status"] == "STOP LOSS" for t in trades)
                rs = sum(trade_r_multiple(t) for t in trades)

                symbol_stats.append(
                    (symbol, len(trades), targets, stops, rs)
                )

        print_trades(all_trades)
        print_summary(all_trades)

        print("\n" + "=" * 90)
        print(" SYMBOL SUMMARY")
        print("=" * 90)

        if symbol_stats:
            print(
                f"{'SYMBOL':<15} {'TRADES':>8} "
                f"{'T2':>8} {'SL':>8} {'NET R':>12}"
            )
            print("-" * 90)

            for row in sorted(
                symbol_stats,
                key=lambda x: (-x[4], x[0])
            ):
                print(
                    f"{row[0]:<15} {row[1]:>8} "
                    f"{row[2]:>8} {row[3]:>8} {row[4]:>+12.2f}"
                )
        else:
            print(" No symbols generated a trade.")

        print("\n[BACKTEST COMPLETE]")
        print(
            "The result above is based only on the OHLCV data stored in "
            "smm_trading.db."
        )

    finally:
        conn.close()


if __name__ == "__main__":
    main()
