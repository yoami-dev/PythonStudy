@echo off
setlocal
cd /d "%~dp0\.."

set "PYTHON_EXE=%~dp0..\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    set "PYTHON_EXE=python"
)

echo ===============================================================================
echo  FYERS INSTANT OAUTH2 LOGIN
echo ===============================================================================

"%PYTHON_EXE%" -u script\fyers_login_helper.py
pause
