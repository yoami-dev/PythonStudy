@echo off
setlocal
chcp 65001 > nul
set PYTHONIOENCODING=utf-8
cd /d "%~dp0\.."

set "PYTHON_EXE=%~dp0..\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    set "PYTHON_EXE=python"
)

echo ===============================================================================
echo  KRAKEN STANDALONE LIVE FYERS POLLER DAEMON
echo ===============================================================================

"%PYTHON_EXE%" -u script\scan_kraken_fyers_live.py --loop --interval 60 --rr 3.0 --t1 1.2 %*
pause

