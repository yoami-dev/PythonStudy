<#
.SYNOPSIS
    SMM Strategy Multi-Timeframe (Tide, Wave, Ripple) Grid Optimizer & Backtesting Runner
.DESCRIPTION
    Runs systematic multi-timeframe backtesting across Nifty 50 instruments to rank combinations.
.EXAMPLE
    .\optimize_timeframes.ps1 -Symbol BENCHMARK -StartDate 2026-09-01 -Open
    .\optimize_timeframes.ps1 -Symbol INFY,TCS,RELIANCE -StartDate 2026-09-01
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$Symbol = "BENCHMARK",

    [Parameter(Mandatory=$false)]
    [string]$StartDate = "2026-09-01",

    [Parameter(Mandatory=$false)]
    [string]$StartTime = "09:30:00",

    [Parameter(Mandatory=$false)]
    [string]$EndDate = "",

    [Parameter(Mandatory=$false)]
    [int]$Workers = 4,

    [Parameter(Mandatory=$false)]
    [switch]$Open,

    [Parameter(Mandatory=$false)]
    [switch]$NoHtml
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path "$ScriptDir\.."
$VenvPython = "$ProjectRoot\venv\Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    $VenvPython = "python"
}

$PyScript = "$ScriptDir\optimize_timeframes.py"

$ArgsList = @(
    "$PyScript",
    "--symbol", $Symbol,
    "--start-date", $StartDate,
    "--start-time", $StartTime,
    "--workers", "$Workers"
)

if ($EndDate -ne "") {
    $ArgsList += @("--end-date", $EndDate)
}

if ($Open) {
    $ArgsList += "--open"
}

if ($NoHtml) {
    $ArgsList += "--no-html"
}

& $VenvPython @ArgsList
