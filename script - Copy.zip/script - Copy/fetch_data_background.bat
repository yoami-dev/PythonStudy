@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Background Nifty 50 Historical Data Fetcher (Batch)
:: Location: D:\Milind\MyTradingPlatform\script\fetch_data_background.bat
:: ============================================================================

title SMM Trading Platform - Background Data Fetcher

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%fetch_data_background.ps1" %*

endlocal
