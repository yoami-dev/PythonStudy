<#
.SYNOPSIS
    ZENITH High Risk-Reward Strategy Discovery & Universe Backtester (PowerShell Runner).

.EXAMPLE
    .\research_zenith.ps1 -Symbol ALL -Timeframe 5m -StartDate 2026-09-01 -RR 2.0 -Open
#>

param(
    [string]$Symbol = "ALL",
    [string]$Timeframe = "5m",
    [string]$StartDate = "2026-09-01",
    [string]$StartTime = "09:30:00",
    [string]$EndDate = "",
    [float]$RR = 2.0,
    [float]$SL = 1.0,
    [switch]$Open
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent $scriptDir
$venvPython = Join-Path $projectRoot "venv\Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    $venvPython = "python"
}

$discoverScript = Join-Path $scriptDir "discover_zenith_strategy.py"

$argsList = @(
    $discoverScript,
    "--symbol", $Symbol,
    "--timeframe", $Timeframe,
    "--start-date", $StartDate,
    "--start-time", $StartTime,
    "--rr-ratio", $RR,
    "--sl-atr-mult", $SL
)

if ($EndDate -ne "") {
    $argsList += @("--end-date", $EndDate)
}

if ($Open) {
    $argsList += "--open"
}

Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " ZENITH High Risk-Reward Strategy Discovery (R:R 1:$RR)" -ForegroundColor Yellow
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host "  Symbol:     $Symbol"
Write-Host "  Timeframe:  $Timeframe"
Write-Host "  Start Date: $StartDate $StartTime"
Write-Host "  R:R Target: 1:$RR"
Write-Host "===============================================================================" -ForegroundColor Cyan

& $venvPython $argsList
