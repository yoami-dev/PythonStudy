@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Application Start Script
:: Location: D:\Milind\MyTradingPlatform\script\start_app.bat
:: ============================================================================

title SMM Trading Platform - Server

:: Navigate to project root directory
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%.."
set "PROJECT_ROOT=%CD%"

echo ============================================================================
echo   Starting SMM Trading Platform
echo ============================================================================
echo Project Root : %PROJECT_ROOT%

:: Check Virtual Environment Python
set "PYTHON_EXE=%PROJECT_ROOT%\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    echo [WARNING] Virtual environment python not found at:
    echo           %PYTHON_EXE%
    echo Falling back to system python...
    set "PYTHON_EXE=python"
)

:: Server configuration
set "HOST=127.0.0.1"
set "PORT=8000"

:: Check if port is already in use
set "PORT_PID="
for /f "tokens=*" %%a in ('powershell -NoProfile -Command "(Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue).OwningProcess"') do (
    set "PORT_PID=%%a"
)

if defined PORT_PID (
    echo.
    echo [ERROR] Port %PORT% is already in use by process PID %PORT_PID%!
    echo To stop the currently running application, please run:
    echo   script\stop_app.bat
    echo.
    pause
    exit /b 1
)

echo.
echo Application Configuration:
echo   - Host          : %HOST%
echo   - Port          : %PORT%
echo   - Python        : %PYTHON_EXE%
echo   - Reload        : Enabled
echo.
echo Available Endpoints:
echo   - Application Root    : http://%HOST%:%PORT%/
echo   - System Dashboard    : http://%HOST%:%PORT%/static/index.html
echo   - Research Dashboard  : http://%HOST%:%PORT%/static/research.html
echo   - Interactive API Docs: http://%HOST%:%PORT%/docs
echo.
echo Press Ctrl+C in this console to stop the server, or run script\stop_app.bat.
echo ============================================================================
echo.

:: Start Uvicorn
"%PYTHON_EXE%" -m uvicorn app.main:app --host %HOST% --port %PORT% --reload

if errorlevel 1 (
    echo.
    echo [ERROR] Application exited with error code %errorlevel%.
    pause
)

endlocal
