@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Market Data Inventory & Coverage Reporter (Batch)
:: Location: E:\Milind\MyTradingPlatform\script\report_market_data.bat
:: ============================================================================

title SMM Trading Platform - Market Data Inventory Report

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%report_market_data.ps1" %*

endlocal
