Here is the complete trader’s playbook to identify and execute the KRAKEN Two-Stage Asymmetric Strategy manually on live charts (TradingView, Zerodha Kite, Upstox, Fyers, etc.).

Step 1: Chart Setup & Required Indicators
Configure your live chart as follows:

Element	Setting	Visual Purpose
Primary Timeframe	5-Minute Candles	Core execution & candle close confirmations
Session VWAP	Daily Reset (09:15 AM IST)	Institutional fair-value bias
Exponential MAs (EMA)	9, 21, and 50 EMA	Dynamic trend slope & value pullbacks
Volume Indicator	Default Volume + 20 SMA Line	When the volume bar towers above the 20 SMA line, $\text{RVOL} \ge 1.15\times$
RSI	14-Period	Filter: Longs $\ge 28$, Shorts $\le 72$
Opening Range Lines	09:15 to 09:30 AM High & Low	Horizontal price rays marking the session liquidity boundary
Step 2: The Golden Trading Clock (When to Look)
Do not look for trades all day. KRAKEN operates exclusively in two institutional volume windows:

[09:15 - 09:30] ──► Mark Opening Range High (ORH) and Low (ORL)
[09:30 - 11:15] ──► WINDOW 1: Morning Liquidity Trap & Trend Expansion (High Probability)
[11:15 - 13:15] ──► NO TRADING: Dead Midday Chop Zone (Do not trade)
[13:15 - 14:15] ──► WINDOW 2: Afternoon European Drive (High Momentum)
[14:15 - 15:30] ──► No New Entries: Trade management & trailing only
Step 3: Visual Setup Identification
There are two primary playbooks in KRAKEN:

PLAYBOOK A: The Institutional Liquidity Sweep & Trap (Highest Win Rate)
This setup exploits institutional stop hunts around key swing levels.

1. Bullish Bear Trap (BUY):
Context: Higher-timeframe trend is upward (Price is above Session VWAP or 50 EMA).
The Sweep: A 5-minute candle dives below the Opening Range Low (ORL) or the lowest low of the last 20 candles, triggering retail breakout stops.
The Rejection (Wick): Smart money steps in and aggressively absorbs the selling. The candle rallies back and closes ABOVE the reference level as a green candle.
Wick Ratio ($\ge 25%$): The lower tail/wick must make up at least a quarter of the candle's total height (showing bottom rejection).
Volume Surge: The volume bar on this candle must be noticeably higher than its 20-period average ($\text{RVOL} \ge 1.15\times$).
           [Candle Anatomy: Bear Trap Long]
                 ┌───┐  <-- Close (Green candle, closes ABOVE ORL)
                 │   │
  ORL Level ─────┼───┼────────────────────────────
                 │   │  <-- Open
                 └───┘
                   │
                   │    <-- Long Rejection Wick (>= 25% of range)
                   │
                   ▼    <-- Swept liquidity below ORL
2. Bearish Bull Trap (SELL / SHORT):
Context: Price is below Session VWAP or 50 EMA.
The Sweep: A 5-minute candle spikes above the Opening Range High (ORH) or the highest high of the last 20 candles.
The Rejection (Wick): Price rejects and closes back BELOW the level as a red candle.
Wick Ratio ($\ge 25%$): The upper tail/wick must be at least 25% of the total candle range.
Volume Surge: $\text{RVOL} \ge 1.15\times$ (elevated institutional volume).
PLAYBOOK B: Dynamic Value Pullback (Trend Continuation)
For stocks already trending strongly in one direction:

Alignment: 9 EMA is above 21 EMA, and 21 EMA is above 50 EMA (bullish fan), and price is above VWAP.
The Pullback: Price pulls back into the 21 EMA / VWAP zone on lighter volume.
The Trigger Candle: A fresh 5-minute green candle rejects the 21 EMA, closes above the previous candle’s high, and displays volume pickup.
Step 4: Two-Stage Trade Execution & Invalidation Math
Once you spot a valid candle close, execute using this exact risk geometry:

                                  [TARGET 2: +3.0R RUNNER]
                                  50% position exits here
                                            ▲
                                            │
                                            │ (+1.8R Asymmetric ride)
                                            │
               [TARGET 1: +1.2R] ───────────┘
               50% position exits here.
               SL moves to BREAKEVEN (0.0R).
                     ▲
                     │
                     │ (+1.2R quick harvest)
                     │
 [ENTRY: 0.0R] ──────┴─────────────────────── (Close of 5m trigger candle)
       │
       │ (Risk = 1.0R, typically 0.20% - 0.35%)
       ▼
 [STOP LOSS: -1.0R] (Anchored 2-3 ticks below the rejection wick low)
Order Management Protocol:
Calculate Risk Unit (1R): $$\text{Risk (1R)} = \text{Entry Price} - \text{Stop Loss}$$
Set Initial Stop Loss: Place strictly below the trigger candle's wick low (plus a small buffer).
Stage 1 Target ($\mathbf{T1 = \text{Entry} + 1.2R}$):
As soon as price reaches +1.2R, close 50% of your position.
Immediately move your Stop Loss on the remaining 50% to Entry Price (0.0R).
Result: Downside risk is completely eliminated. The worst-case outcome is now a guaranteed positive net trade ($+0.60\text{R}$ net).
Stage 2 Target ($\mathbf{T2 = \text{Entry} + 3.0R}$):
Let the remaining 50% runner attempt to reach +3.0R.
If it hits T2: Full trade delivers $+2.10\text{R}$ net profit.
If it reverses and hits Breakeven: Full trade delivers $+0.60\text{R}$ net profit.
Step 5: 5-Second Pre-Flight Checklist
Before clicking Buy or Sell on your terminal, verify:

 Time: Is it between 09:30 - 11:15 or 13:15 - 14:15?
 Sweep & Wick: Did the 5m candle poke beyond a key level (ORH/ORL or 20-bar pivot) and reject with a $\ge 25%$ wick?
 Close: Did the candle close back on the correct side of the level?
 Volume: Is the current 5m volume bar higher than the 20-period volume SMA?
 Macro Side: Are you trading in the direction of the Session VWAP / 50 EMA?
If all 5 boxes are checked, the setup qualifies as a high-probability KRAKEN Two-Stage trade.

10:29 AM
create this strategy as a indicator using pine script