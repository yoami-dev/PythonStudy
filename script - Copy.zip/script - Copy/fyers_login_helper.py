#!/usr/bin/env python3
"""
===============================================================================
 FYERS OAUTH2 AUTOMATED LOGIN & CALLBACK SERVER
===============================================================================
 Location: D:\\Milind\\MyTradingPlatform\\script\\fyers_login_helper.py

 Spins up a local HTTP server on port 8000 to listen for the FYERS callback:
   http://127.0.0.1:8000/api/v1/auth/fyers/callback
 
 1. Generates the official FYERS OAuth authorization URL.
 2. Automatically launches your default web browser to the FYERS login page.
 3. Captures the auth_code upon login redirect.
 4. Exchanges auth_code for access_token and validates with FYERS profile.
 5. Automatically saves the valid token into smm_trading.db for all tools.
===============================================================================
"""

import os
import sys
import time
import sqlite3
import webbrowser
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime, timezone, timedelta
from typing import Optional

# Ensure project root is on sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.config import settings

try:
    from fyers_apiv3 import fyersModel
except ImportError:
    print("[ERROR] 'fyers_apiv3' is required. Run: pip install fyers-apiv3")
    sys.exit(1)

DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")
SUCCESS_HTML = """<!DOCTYPE html>
<html>
<head>
    <title>FYERS Authentication Successful</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0d1117; color: #c9d1d9; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .card { background: #161b22; padding: 40px 50px; border-radius: 12px; border: 1px solid #30363d; text-align: center; max-width: 480px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        .badge { display: inline-block; background: rgba(35, 134, 54, 0.2); color: #3fb950; font-weight: bold; font-size: 48px; border-radius: 50%; width: 80px; height: 80px; line-height: 80px; margin-bottom: 20px; }
        h1 { color: #f0f6fc; margin-bottom: 10px; font-size: 24px; }
        p { color: #8b949e; line-height: 1.6; }
        .info { background: #21262d; border-radius: 8px; padding: 12px; margin: 20px 0; font-family: monospace; color: #58a6ff; }
    </style>
</head>
<body>
    <div class="card">
        <div class="badge">✓</div>
        <h1>FYERS Login Successful!</h1>
        <p>Your session has been authenticated and saved securely to the trading platform.</p>
        <div class="info">Account: {account_name}</div>
        <p>You can close this tab and return to your terminal.</p>
    </div>
</body>
</html>"""

ERROR_HTML = """<!DOCTYPE html>
<html>
<head>
    <title>FYERS Authentication Failed</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0d1117; color: #c9d1d9; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .card { background: #161b22; padding: 40px; border-radius: 12px; border: 1px solid #da3633; text-align: center; max-width: 480px; }
        h1 { color: #f85149; }
        p { color: #8b949e; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Authentication Error</h1>
        <p>{error_msg}</p>
        <p>Please return to the console and try again.</p>
    </div>
</body>
</html>"""


class FyersCallbackHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Suppress default HTTP server logging

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != "/api/v1/auth/fyers/callback":
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")
            return

        query = urllib.parse.parse_qs(parsed.query)
        auth_code_list = query.get("auth_code") or query.get("code") or query.get("s_id")

        if not auth_code_list:
            self.send_response(400)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            err_body = ERROR_HTML.replace("{error_msg}", "Missing auth_code in callback query parameters.")
            self.wfile.write(err_body.encode("utf-8"))
            return

        auth_code = auth_code_list[0]

        # Exchange auth_code for access_token
        try:
            session_model = fyersModel.SessionModel(
                client_id=settings.FYERS_CLIENT_ID,
                secret_key=settings.FYERS_SECRET_KEY,
                redirect_uri=settings.FYERS_REDIRECT_URI,
                response_type="code",
                grant_type="authorization_code"
            )
            session_model.set_token(auth_code)
            res = session_model.generate_token()

            if not isinstance(res, dict) or res.get("s") != "ok" or "access_token" not in res:
                err_msg = res.get("message", "Token generation failed from FYERS") if isinstance(res, dict) else str(res)
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                err_body = ERROR_HTML.replace("{error_msg}", err_msg)
                self.wfile.write(err_body.encode("utf-8"))
                return

            access_token = res["access_token"]

            # Validate access token with profile
            fyers_client = fyersModel.FyersModel(
                token=access_token,
                is_async=False,
                client_id=settings.FYERS_CLIENT_ID
            )
            profile = fyers_client.get_profile()
            account_name = profile.get("data", {}).get("name", "FYERS Trader") if isinstance(profile, dict) else "FYERS Account"

            # Save into smm_trading.db
            save_token_to_db(access_token, account_name)

            self.server.access_token = access_token
            self.server.account_name = account_name

            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            succ_body = SUCCESS_HTML.replace("{account_name}", account_name)
            self.wfile.write(succ_body.encode("utf-8"))

        except Exception as e:
            print(f"[AUTH ERROR] Callback exchange error: {e}")
            self.send_response(500)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            err_body = ERROR_HTML.replace("{error_msg}", str(e))
            self.wfile.write(err_body.encode("utf-8"))


def save_token_to_db(token: str, account_name: str):
    if not os.path.exists(DB_PATH):
        return
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        now = datetime.now(timezone.utc)
        now_str = now.strftime("%Y-%m-%d %H:%M:%S.%f")
        exp_str = (now + timedelta(hours=18)).strftime("%Y-%m-%d %H:%M:%S.%f")

        c.execute("""
            INSERT INTO fyers_tokens (client_id, access_token, status, account_id, issued_at, expires_at, last_checked_at)
            VALUES (?, ?, 'VALID', ?, ?, ?, ?)
        """, (settings.FYERS_CLIENT_ID, token, account_name, now_str, exp_str, now_str))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[WARNING] Could not persist token to database: {e}")


def run_oauth_flow() -> Optional[str]:
    """Starts local callback server on port 8000, opens browser, and returns access_token."""
    client_id = settings.FYERS_CLIENT_ID
    secret_key = settings.FYERS_SECRET_KEY
    redirect_uri = settings.FYERS_REDIRECT_URI

    if not client_id or not secret_key:
        print("[ERROR] FYERS_CLIENT_ID or FYERS_SECRET_KEY is missing from .env")
        return None

    # Generate auth URL
    session_model = fyersModel.SessionModel(
        client_id=client_id,
        secret_key=secret_key,
        redirect_uri=redirect_uri,
        response_type="code",
        grant_type="authorization_code"
    )
    auth_url = session_model.generate_authcode()

    # Parse port from redirect URI (default 8000)
    parsed_uri = urllib.parse.urlparse(redirect_uri)
    port = parsed_uri.port or 8000

    print("===============================================================================")
    print(" FYERS ONE-CLICK OAUTH LOGIN SERVICE")
    print("===============================================================================")
    print(f" Callback URL : {redirect_uri}")
    print(f" Local Port   : {port}")
    print("===============================================================================")
    print("[INFO] Starting temporary local callback listener on port 8000...")

    try:
        server = HTTPServer(("127.0.0.1", port), FyersCallbackHandler)
    except OSError as e:
        print(f"[ERROR] Port {port} is busy or in use: {e}")
        print(" If the application server is running, you can open http://127.0.0.1:8000/api/v1/auth/fyers/login directly in your browser.")
        return None

    server.access_token = None
    server.account_name = None

    print("\n[INFO] Opening FYERS login page in your default browser...")
    print(f"URL: {auth_url}\n")
    try:
        webbrowser.open(auth_url)
    except Exception:
        print("Please copy and paste the URL above into your browser.")

    print("Waiting for login authorization callback from browser (Press Ctrl+C to abort)...")
    try:
        while server.access_token is None:
            server.handle_request()
    except KeyboardInterrupt:
        print("\n[INFO] Login cancelled by user.")
        server.server_close()
        return None

    server.server_close()
    token = server.access_token
    account = server.account_name

    if token:
        print("\n" + "=" * 80)
        print(f" ✅ [LOGIN SUCCESS] Connected as: {account}")
        print(f" Token automatically saved to database: {DB_PATH}")
        print("=" * 80 + "\n")
        return token
    else:
        print("[ERROR] Login failed to generate access token.")
        return None


if __name__ == "__main__":
    token = run_oauth_flow()
    if token:
        print("FYERS authentication complete. You can now run your scanners.")
    else:
        sys.exit(1)
