<#
================================================================================
SMM Trading Platform - Background Nifty 50 Historical Data Fetcher (PowerShell)
Location: D:\Milind\MyTradingPlatform\script\fetch_data_background.ps1
================================================================================
Runs the historical data ingestion engine in the background, logging progress
to script\fetch_data.log.
#>

param (
    [string]$Timeframes = "ALL",
    [string]$Symbols = "ALL",
    [string]$StartDate = "",
    [string]$EndDate = "",
    [int]$Concurrency = 3
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$PythonExe = Join-Path $ProjectRoot "venv\Scripts\python.exe"

if (-not (Test-Path $PythonExe)) {
    $PythonExe = "python"
}

$FetcherScript = Join-Path $ScriptDir "fetch_nifty50_data.py"
$LogFile = Join-Path $ScriptDir "fetch_data.log"
$PidFile = Join-Path $ScriptDir ".fetch_data.pid"

# Check if already running
if (Test-Path $PidFile) {
    $ExistingPid = Get-Content $PidFile -ErrorAction SilentlyContinue
    if ($ExistingPid) {
        $Process = Get-Process -Id $ExistingPid -ErrorAction SilentlyContinue
        if ($Process -and ($Process.ProcessName -match "python")) {
            Write-Host "[WARNING] Data fetcher is already running in background (PID: $ExistingPid)." -ForegroundColor Yellow
            Write-Host "To view real-time status: script\status_fetch_data.bat" -ForegroundColor Cyan
            Write-Host "To stop the running job: script\stop_fetch_data.bat" -ForegroundColor Cyan
            exit 0
        }
    }
}

Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "  Launching SMM Background Data Fetcher" -ForegroundColor Cyan
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "Project Root : $ProjectRoot"
Write-Host "Timeframes   : $Timeframes"
Write-Host "Symbols      : $Symbols"
if ($StartDate) { Write-Host "Start Date   : $StartDate" }
if ($EndDate) { Write-Host "End Date     : $EndDate" }
Write-Host "Concurrency  : $Concurrency"
Write-Host "Log Output   : $LogFile"
Write-Host ""

# Construct clean argument list array for python execution
$PyArgs = @(
    $FetcherScript,
    "--timeframes", $Timeframes,
    "--symbols", $Symbols,
    "--concurrency", "$Concurrency",
    "--log-file", $LogFile
)
if ($StartDate) {
    $PyArgs += @("--start-date", $StartDate)
}
if ($EndDate) {
    $PyArgs += @("--end-date", $EndDate)
}

$StdOutLog = Join-Path $ScriptDir "fetch_stdout.log"
$StdErrLog = Join-Path $ScriptDir "fetch_stderr.log"

# Start process in background detached
$Process = Start-Process -FilePath $PythonExe -ArgumentList $PyArgs -WorkingDirectory $ProjectRoot -PassThru

if ($Process) {
    $NewPid = $Process.Id
    Set-Content -Path $PidFile -Value $NewPid
    Write-Host "[SUCCESS] Historical Data Fetcher launched in background (PID: $NewPid)." -ForegroundColor Green
    Write-Host "Real-time log is streaming to: $LogFile"
    Write-Host ""
    Write-Host "Helpful commands:" -ForegroundColor White
    Write-Host "  - Check progress : script\status_fetch_data.bat" -ForegroundColor Gray
    Write-Host "  - Stop fetcher   : script\stop_fetch_data.bat" -ForegroundColor Gray
    Write-Host "  - Stream log     : Get-Content -Wait `"$LogFile`"" -ForegroundColor Gray
} else {
    Write-Host "[ERROR] Failed to start background fetch process." -ForegroundColor Red
    exit 1
}

Write-Host "============================================================================" -ForegroundColor Cyan
