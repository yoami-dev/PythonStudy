@echo off
setlocal

:: ============================================================================
:: SMM Trading Platform — Multi-Timeframe Optimization & Backtesting CLI
:: ============================================================================
:: Usage Examples:
::   optimize_timeframes.bat -Symbol BENCHMARK -StartDate 2026-09-01
::   optimize_timeframes.bat -Symbol INFY,TCS,RELIANCE,LT -StartDate 2026-09-01 -Open
::   optimize_timeframes.bat -Symbol ALL -StartDate 2026-09-01 -Workers 6
:: ============================================================================

set SCRIPT_DIR=%~dp0
set PROJECT_ROOT=%SCRIPT_DIR%..
set PS_SCRIPT=%SCRIPT_DIR%optimize_timeframes.ps1

if not exist "%PS_SCRIPT%" (
    echo [ERROR] PowerShell script not found at %PS_SCRIPT%
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" %*

endlocal
