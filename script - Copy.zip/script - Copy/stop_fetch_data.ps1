$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$PidFile = Join-Path $ScriptDir ".fetch_data.pid"

Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "  Stopping SMM Background Data Fetcher" -ForegroundColor Cyan
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "Project Root : $ProjectRoot"
Write-Host ""

$stoppedAny = $false

if (Test-Path $PidFile) {
    $procId = Get-Content $PidFile -ErrorAction SilentlyContinue
    if ($procId) {
        $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
        if ($p) {
            Write-Host ("Terminating fetcher process PID " + $procId + "...") -ForegroundColor Yellow
            Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
            $stoppedAny = $true
        }
    }
    Remove-Item $PidFile -Force -ErrorAction SilentlyContinue
}

# Catch any remaining python processes running fetch_nifty50_data.py
$extraProcs = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*fetch_nifty50_data.py*' }
foreach ($ep in $extraProcs) {
    Write-Host ("Terminating related process PID " + $ep.ProcessId + "...") -ForegroundColor Yellow
    Stop-Process -Id $ep.ProcessId -Force -ErrorAction SilentlyContinue
    $stoppedAny = $true
}

if ($stoppedAny) {
    Write-Host "[SUCCESS] Background data fetcher terminated successfully." -ForegroundColor Green
} else {
    Write-Host "[INFO] No running data fetcher process was found." -ForegroundColor Yellow
}

Write-Host "============================================================================" -ForegroundColor Cyan
