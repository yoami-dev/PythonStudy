#!/usr/bin/env python3
"""KRAKEN 5m historical backtest using native 5m SQLite candles only."""
from __future__ import annotations
import argparse,csv,importlib.util,os,sqlite3
from dataclasses import dataclass
from datetime import datetime,time as dtime
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

IST=ZoneInfo("Asia/Kolkata"); UTC=ZoneInfo("UTC")
DB_DEFAULT=r"D:\Milind\MyTradingPlatform\smm_trading.db"
OUT_DEFAULT=r"D:\Milind\MyTradingPlatform\script\backtest_results"
SS=dtime(9,15); SE=dtime(15,15)
SYMBOLS=["SUNPHARMA","SBIN","MARUTI","BRITANNIA","WIPRO","BAJAJ-AUTO","BAJAJFINSV","BAJFINANCE","BHARTIARTL","BPCL","CIPLA","COALINDIA","DRREDDY","EICHERMOT","GRASIM","HCLTECH","HDFCBANK","HDFCLIFE","HEROMOTOCO","HINDALCO","HINDUNILVR","ICICIBANK","INDUSINDBK","INFY","ITC","JSWSTEEL","KOTAKBANK","LT","M&M","NESTLEIND","NTPC","ONGC","POWERGRID","RELIANCE","SBILIFE","SHRIRAMFIN","TATACONSUM","TATASTEEL","TCS","TECHM","TITAN","TRENT","ULTRACEMCO"]

def canon(x):
    s=str(x).strip().upper()
    if s.startswith("NSE:"): s=s[4:]
    if s.endswith("-EQ"): s=s[:-3]
    return s

def dbts(x):
    if isinstance(x,(int,float)): return datetime.fromtimestamp(float(x),tz=UTC)
    s=str(x).strip()
    if s.endswith("Z"): s=s[:-1]+"+00:00"
    try: d=datetime.fromisoformat(s)
    except ValueError:
        for f in ("%Y-%m-%d %H:%M:%S","%Y-%m-%d %H:%M"):
            try: d=datetime.strptime(s,f); break
            except ValueError: pass
        else: raise
    if d.tzinfo is None: d=d.replace(tzinfo=UTC)
    return d.astimezone(UTC)

def load_source():
    here=Path(__file__).resolve().parent
    for p in (here/"scan_kraken_precision_3R_no_lookahead.py",here/"scan_kraken_precision_3R_no_lookahead(2).py"):
        if p.exists():
            spec=importlib.util.spec_from_file_location("kraken_source",p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
    raise FileNotFoundError("Original KRAKEN strategy file not found beside this backtest file.")

class DB:
    def __init__(self,path):
        if not os.path.exists(path): raise FileNotFoundError(path)
        self.cx=sqlite3.connect(f"file:{Path(path).resolve()}?mode=ro",uri=True); self.cx.row_factory=sqlite3.Row
        self.table="market_candles"; cols=[r[1] for r in self.cx.execute(f'PRAGMA table_info("{self.table}")')]
        self.symcol=next((c for c in cols if c.lower() in {"symbol","ticker","trading_symbol","fyers_symbol"}),None); self.map=self._map()
    def close(self): self.cx.close()
    def _map(self):
        m={}
        if self.symcol:
            for r in self.cx.execute(f'SELECT DISTINCT "{self.symcol}" s FROM "{self.table}"'): m[canon(r["s"])]=r["s"]
            return m
        names=[r[0] for r in self.cx.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for t in names:
            if t==self.table: continue
            cols=[r[1] for r in self.cx.execute(f'PRAGMA table_info("{t}")')]; low={c.lower():c for c in cols}
            if "instrument_id" not in low: continue
            sc=next((low[x] for x in ("symbol","ticker","trading_symbol","fyers_symbol","name") if x in low),None)
            if not sc: continue
            try:
                for r in self.cx.execute(f'SELECT instrument_id,"{sc}" s FROM "{t}"'): m[canon(r["s"])]=int(r["instrument_id"])
                if m:return m
            except Exception: pass
        return m
    def ident(self,s,p):
        if self.symcol: p.append(self.map.get(canon(s),s)); return f'"{self.symcol}"=?'
        iid=self.map.get(canon(s))
        if iid is None: raise KeyError(f"Instrument ID not found: {s}")
        p.append(iid); return "instrument_id=?"
    def load(self,s,tf="5m",end=None):
        p=[tf]; ident=self.ident(s,p); q=["timeframe=?",ident]
        if end:q.append("candle_timestamp<=?");p.append(end)
        sql=f'SELECT candle_timestamp,open,high,low,close,volume FROM "{self.table}" WHERE {" AND ".join(q)} ORDER BY candle_timestamp'
        return [{"candle_timestamp":dbts(r[0]),"open":float(r[1]),"high":float(r[2]),"low":float(r[3]),"close":float(r[4]),"volume":float(r[5])} for r in self.cx.execute(sql,p).fetchall()]
    def symbols(self): return set(self.map)

def ema_series(c,p):
    out=[0.0]*len(c)
    if not c:return out
    a=2/(p+1);e=float(c[0]["close"]);out[0]=e
    for i in range(1,len(c)):e=a*float(c[i]["close"])+(1-a)*e;out[i]=e
    return out

def atr_series(c,p=14):
    out=[0.0]*len(c);tr=[0.0]*len(c)
    for i in range(1,len(c)):
        x,q=c[i],c[i-1];tr[i]=max(x["high"]-x["low"],abs(x["high"]-q["close"]),abs(x["low"]-q["close"]))
        if i>=p:out[i]=sum(tr[i-p+1:i+1])/p
        else:out[i]=sum(tr[1:i+1])/len(tr[1:i+1]) if i else 0
    return out

def adx_series(c,p=14):
    n=len(c);out=[0.0]*n;tr=[0.0]*n;pd=[0.0]*n;md=[0.0]*n
    for i in range(1,n):
        x,q=c[i],c[i-1];up=x["high"]-q["high"];dn=q["low"]-x["low"];tr[i]=max(x["high"]-x["low"],abs(x["high"]-q["close"]),abs(x["low"]-q["close"]));pd[i]=up if up>dn and up>0 else 0;md[i]=dn if dn>up and dn>0 else 0
        if i>=p+1:
            a=sum(tr[i-p+1:i+1])/p
            if a:
                pdi=100*(sum(pd[i-p+1:i+1])/p)/a;mdi=100*(sum(md[i-p+1:i+1])/p)/a;out[i]=100*abs(pdi-mdi)/(pdi+mdi) if pdi+mdi else 0
    return out

def rvol_series(c,p=20):
    out=[0.0]*len(c)
    for i in range(p,len(c)):
        a=sum(max(x["volume"],0) for x in c[i-p:i])/p;out[i]=max(c[i]["volume"],0)/a if a else 0
    return out

def vwap_series(c):
    out=[0.0]*len(c);day=None;pv=vv=0
    for i,x in enumerate(c):
        d=x["candle_timestamp"].astimezone(IST).date()
        if d!=day:day=d;pv=vv=0
        vol=max(x["volume"],1);pv+=((x["high"]+x["low"]+x["close"])/3)*vol;vv+=vol;out[i]=pv/vv if vv else x["close"]
    return out

class Ind:
    def __init__(self,c):
        self.e20=ema_series(c,20);self.e50=ema_series(c,50);self.e200=ema_series(c,200);self.atr=atr_series(c);self.adx=adx_series(c);self.rvol=rvol_series(c);self.vwap=vwap_series(c)

def nifty_states(c):
    ind=Ind(c);out={};day=None;hi=lo=op=None;pv=vv=0
    for i,x in enumerate(c):
        dt=x["candle_timestamp"].astimezone(IST);d=dt.date()
        if d!=day:day=d;hi=x["high"];lo=x["low"];op=x["open"];pv=vv=0
        else:hi=max(hi,x["high"]);lo=min(lo,x["low"])
        vol=max(x["volume"],1);pv+=((x["high"]+x["low"]+x["close"])/3)*vol;vv+=vol;vw=pv/vv if vv else x["close"];diff=x["close"]-vw;pct=diff/vw if vw else 0
        bias="NEUTRAL" if abs(pct)<=.0003 else ("BULLISH" if diff>0 else "BEARISH");rp=((hi-lo)/op*100) if op else 0
        out[x["candle_timestamp"]]=(bias,"RANGEBOUND" if rp<.85 else "TRENDING")
    return out

@dataclass
class Trade:
    id:int;symbol:str;direction:str;signal_ts:datetime;entry:float;initial_sl:float;sl:float;t1:float;target:float;risk:float;t1_hit:bool=False;exit_ts:Optional[datetime]=None;exit_price:Optional[float]=None;outcome:str="OPEN_AT_END";realized_R:Optional[float]=None;bars:int=0

def update(t,c):
    t.bars+=1;h=c["high"];l=c["low"]
    if t.direction=="LONG": ht1=not t.t1_hit and h>=t.t1;ht2=h>=t.target;hsl=l<=t.sl
    else: ht1=not t.t1_hit and l<=t.t1;ht2=l<=t.target;hsl=h>=t.sl
    if hsl and (ht1 or ht2):
        t.exit_ts=c["candle_timestamp"];t.exit_price=t.sl;t.outcome="BREAKEVEN" if t.t1_hit else "STOP_LOSS";t.realized_R=0 if t.t1_hit else -1;return True
    if ht1:
        t.t1_hit=True;t.sl=t.entry
        if ht2:t.exit_ts=c["candle_timestamp"];t.exit_price=t.target;t.outcome="TARGET_2";t.realized_R=3;return True
    elif ht2:t.exit_ts=c["candle_timestamp"];t.exit_price=t.target;t.outcome="TARGET_2";t.realized_R=3;return True
    elif hsl:t.exit_ts=c["candle_timestamp"];t.exit_price=t.sl;t.outcome="BREAKEVEN" if t.t1_hit else "STOP_LOSS";t.realized_R=0 if t.t1_hit else -1;return True
    return False

def run_symbol(mod,s,cs,nifty,start,end,tid):
    ind=Ind(cs);active=None;trades=[]
    for i,c in enumerate(cs):
        dt=c["candle_timestamp"].astimezone(IST)
        if dt.date()<start or dt.date()>end or not(SS<=dt.time()<=SE):continue
        if active:
            if update(active,c):trades.append(active);active=None
            continue
        state=nifty.get(c["candle_timestamp"])
        if not state:continue
        bias,regime=state
        # Necessary-condition prefilter; the exact supplied engine is called
        # only for candidates that can possibly become VALID.
        if regime!="TRENDING" or bias not in ("BULLISH","BEARISH") or i+1<60 or ind.atr[i]<=0 or ind.adx[i]<22 or ind.rvol[i]<1.30:continue
        if abs(c["close"]-ind.vwap[i])>1.25*ind.atr[i]:continue
        bull=c["close"]>ind.e20[i]>ind.e50[i]>=ind.e200[i] and c["close"]>ind.vwap[i]
        bear=c["close"]<ind.e20[i]<ind.e50[i]<=ind.e200[i] and c["close"]<ind.vwap[i]
        rng=max(c["high"]-c["low"],1e-9);body=abs(c["close"]-c["open"]);upper=c["high"]-max(c["open"],c["close"]);lower=min(c["open"],c["close"])-c["low"]
        bullrej=c["close"]>c["open"] and lower>=max(body*.75,rng*.25) and c["close"]>=c["low"]+rng*.65
        bearrej=c["close"]<c["open"] and upper>=max(body*.75,rng*.25) and c["close"]<=c["low"]+rng*.35
        p=cs[i-1]
        if bias=="BULLISH" and not(bull and bullrej and c["close"]>p["high"]):continue
        if bias=="BEARISH" and not(bear and bearrej and c["close"]<p["low"]):continue
        # Exact supplied strategy engine decides the final signal.
        eng=mod.KrakenStrategyEngine()
        res=eng.evaluate(symbol=s,instrument="NSE_EQ",current_price=c["close"],candles=cs[:i+1],timeframe="5m",index_bias=bias,market_regime=regime,macro_state=None)
        if res.get("status")!="VALID":continue
        entry=float(res["entry_price"]);sl=float(res["stop_loss_price"]);risk=abs(entry-sl)
        active=Trade(tid,s,res["direction"],c["candle_timestamp"],entry,sl,sl,float(res["t1_target_price"]),float(res["target_price"]),risk);tid+=1
    if active:trades.append(active)
    return trades,tid

def write_csv(path,rows):
    if not rows:path.write_text("No rows produced.\\n",encoding="utf-8");return
    with path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(description="KRAKEN native 5m DB backtest")
    ap.add_argument("--db",default=DB_DEFAULT);ap.add_argument("--output",default=OUT_DEFAULT);ap.add_argument("--start");ap.add_argument("--end");ap.add_argument("--symbols",nargs="+")
    a=ap.parse_args();mod=load_source();db=DB(a.db)
    try:
        available=db.symbols();symbols=[canon(x) for x in (a.symbols or SYMBOLS) if canon(x) in available]
        if "NIFTY50" not in available:raise RuntimeError("NIFTY50 5m data not found in DB.")
        nifty=db.load("NIFTY50","5m")
        if not nifty:raise RuntimeError("NIFTY50 5m query returned no rows.")
        states=nifty_states(nifty);dates=[x["candle_timestamp"].astimezone(IST).date() for x in nifty]
        start=datetime.strptime(a.start,"%Y-%m-%d").date() if a.start else min(dates);end=datetime.strptime(a.end,"%Y-%m-%d").date() if a.end else max(dates)
        if end<start:raise ValueError("--end is earlier than --start")
        print("="*90);print("KRAKEN 5m HISTORICAL BACKTEST");print(f"DB: {a.db}");print("Native 5m only | FYERS: NO | Resampling: NO | Session: 09:15-15:15 IST");print(f"Range: {start} -> {end} | Symbols: {len(symbols)}");print("="*90)
        alltr=[];tid=1
        for n,s in enumerate(symbols,1):
            print(f"[{n:02d}/{len(symbols):02d}] {s} ...",end=" ",flush=True)
            cs=db.load(s,"5m",f"{end.isoformat()}T23:59:59+05:30");ts,tid=run_symbol(mod,s,cs,states,start,end,tid);alltr.extend(ts);print(f"{len(cs):,} candles | {len(ts)} trades")
        alltr.sort(key=lambda x:(x.signal_ts,x.symbol))
        for i,t in enumerate(alltr,1):t.id=i
        t2=sum(t.outcome=="TARGET_2" for t in alltr);sl=sum(t.outcome=="STOP_LOSS" for t in alltr);be=sum(t.outcome=="BREAKEVEN" for t in alltr);op=sum(t.outcome=="OPEN_AT_END" for t in alltr);win=t2/(t2+sl)*100 if t2+sl else 0;totalr=sum(t.realized_R for t in alltr if t.realized_R is not None)
        out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
        rows=[]
        for t in alltr:rows.append({"trade_id":t.id,"symbol":t.symbol,"direction":t.direction,"signal_time_ist":t.signal_ts.astimezone(IST).strftime("%Y-%m-%d %H:%M:%S"),"entry":t.entry,"initial_sl":t.initial_sl,"t1_1R":t.t1,"target_3R":t.target,"risk":t.risk,"t1_hit":t.t1_hit,"exit_time_ist":t.exit_ts.astimezone(IST).strftime("%Y-%m-%d %H:%M:%S") if t.exit_ts else "","exit_price":t.exit_price if t.exit_price is not None else "","outcome":t.outcome,"realized_R":t.realized_R if t.realized_R is not None else "","bars_held":t.bars})
        summary={"start":str(start),"end":str(end),"timeframe":"5m native DB","session":"09:15-15:15 IST inclusive","symbols":len(symbols),"trades":len(alltr),"target_2_3R":t2,"stop_loss":sl,"breakeven":be,"open_at_end":op,"resolved":t2+sl+be,"target2_vs_stop_win_rate_pct":round(win,2),"total_realized_R":round(totalr,4)}
        write_csv(out/"kraken_backtest_trades.csv",rows);write_csv(out/"kraken_backtest_summary.csv",[summary])
        print("="*90);print("BACKTEST COMPLETE");print(summary);print(f"Output: {out}");print("="*90)
    finally:db.close()

if __name__=="__main__":main()
