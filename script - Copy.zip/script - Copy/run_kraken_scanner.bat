@echo off
setlocal
cd /d "%~dp0\.."

set "PYTHON_EXE=%~dp0..\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    set "PYTHON_EXE=python"
)

echo ===============================================================================
echo  KRAKEN NIFTY 50 REAL-TIME LIVE SCANNER DAEMON
echo ===============================================================================

"%PYTHON_EXE%" -u script\scan_kraken_live.py --loop --interval 60 --timeframe 5m --rr 3.0 --t1 1.2
pause
