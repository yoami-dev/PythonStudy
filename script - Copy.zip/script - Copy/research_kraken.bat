@echo off
setlocal enabledelayedexpansion

REM ============================================================================
REM KRAKEN Two-Stage Asymmetric Strategy Discovery & Research Runner
REM ============================================================================

set SCRIPT_DIR=%~dp0
set PROJECT_ROOT=%SCRIPT_DIR%..
set VENV_PYTHON=%PROJECT_ROOT%\venv\Scripts\python.exe

if not exist "%VENV_PYTHON%" (
    set VENV_PYTHON=python
)
set PYTHONPATH=%PROJECT_ROOT%;%PYTHONPATH%

REM Default parameters
set SYMBOL=ALL
set TIMEFRAME=5m
set START_DATE=2026-09-01
set START_TIME=09:30:00
set RR_RATIO=3.0
set T1_RATIO=1.2
set SL_BUFFER=0.08
set OPEN_FLAG=
set EXTRA_ARGS=

:parse_args
if "%~1"=="" goto run_script

if /i "%~1"=="-Symbol" (
    set SYMBOL=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--symbol" (
    set SYMBOL=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-Timeframe" (
    set TIMEFRAME=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--timeframe" (
    set TIMEFRAME=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-StartDate" (
    set START_DATE=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--start-date" (
    set START_DATE=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-StartTime" (
    set START_TIME=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--start-time" (
    set START_TIME=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-RR" (
    set RR_RATIO=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--rr-ratio" (
    set RR_RATIO=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-T1" (
    set T1_RATIO=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--t1-rr" (
    set T1_RATIO=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-SL" (
    set SL_BUFFER=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--sl-buffer" (
    set SL_BUFFER=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-Open" (
    set OPEN_FLAG=--open
    shift
    goto parse_args
)
if /i "%~1"=="--open" (
    set OPEN_FLAG=--open
    shift
    goto parse_args
)

set EXTRA_ARGS=%EXTRA_ARGS% %1
shift
goto parse_args

:run_script
echo ===============================================================================
echo  KRAKEN Two-Stage Asymmetric Strategy Discovery (T1: +%T1_RATIO%R ^| T2: +%RR_RATIO%R)
echo ===============================================================================
echo  Symbol:     %SYMBOL%
echo  Timeframe:  %TIMEFRAME%
echo  Start Date: %START_DATE% %START_TIME%
echo  T1 Harvest: +%T1_RATIO%R  ^|  T2 Runner: +%RR_RATIO%R
echo ===============================================================================

"%VENV_PYTHON%" -u "%SCRIPT_DIR%discover_kraken_strategy.py" ^
    --symbol "%SYMBOL%" ^
    --timeframe "%TIMEFRAME%" ^
    --start-date "%START_DATE%" ^
    --start-time "%START_TIME%" ^
    --rr-ratio "%RR_RATIO%" ^
    --t1-rr "%T1_RATIO%" ^
    --sl-buffer-atr "%SL_BUFFER%" ^
    %OPEN_FLAG% %EXTRA_ARGS%

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] KRAKEN Strategy Discovery script exited with error code %ERRORLEVEL%.
    exit /b %ERRORLEVEL%
)

exit /b 0
