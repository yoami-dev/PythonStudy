<#
================================================================================
SMM Trading Platform - Market Data Inventory & Coverage Reporter (PowerShell)
Location: E:\Milind\MyTradingPlatform\script\report_market_data.ps1
================================================================================
Inspects 'smm_trading.db' and generates comprehensive inventory reports in:
- Interactive HTML Dashboard (Tabular, Searchable, Sortable, Heatmap Matrix)
- Terminal ASCII Tables
- CSV Spreadsheet
- Markdown Report

Parameters:
  -Breakdown       : summary | monthly | yearly | matrix | missing | all (Default: all)
  -Symbols         : ALL | INFY,TCS,RELIANCE (Default: ALL)
  -Timeframes      : ALL | 1m,5m,15m,1h,1D (Default: ALL)
  -TargetStartDate : YYYY-MM-DD (Default: 2017-07-03)
  -ExportHtml      : Generate interactive HTML report (Default: true)
  -Open            : Automatically open the generated HTML report in browser
  -ExportCsv       : Switch to export detailed CSV report to script\reports\
  -ExportMd        : Switch to export formatted Markdown report to script\reports\
  -HtmlPath        : Optional custom path for HTML export
  -CsvPath         : Optional custom path for CSV export
  -MdPath          : Optional custom path for Markdown export

Examples:
  .\script\report_market_data.ps1
  .\script\report_market_data.ps1 -Open
  .\script\report_market_data.ps1 -Breakdown matrix
  .\script\report_market_data.ps1 -Breakdown missing
  .\script\report_market_data.ps1 -Symbols INFY,TCS -Timeframes 1m,15m,1h,1D
  .\script\report_market_data.ps1 -ExportCsv -ExportMd
#>

param (
    [ValidateSet("summary", "monthly", "yearly", "matrix", "missing", "all")]
    [string]$Breakdown = "all",

    [string]$Symbols = "ALL",

    [string]$Timeframes = "ALL",

    [string]$TargetStartDate = "2017-07-03",

    [switch]$NoHtml,

    [switch]$Open,

    [switch]$ExportCsv,

    [switch]$ExportMd,

    [string]$HtmlPath = "",

    [string]$CsvPath = "",

    [string]$MdPath = ""
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$PythonExe = Join-Path $ProjectRoot "venv\Scripts\python.exe"

if (-not (Test-Path $PythonExe)) {
    $PythonExe = "python"
}

$ReporterScript = Join-Path $ScriptDir "report_market_data.py"

if (-not (Test-Path $ReporterScript)) {
    Write-Host "[ERROR] Reporter script not found: $ReporterScript" -ForegroundColor Red
    exit 1
}

$DbPath = Join-Path $ProjectRoot "smm_trading.db"
if (-not (Test-Path $DbPath)) {
    Write-Host "[ERROR] Database file not found: $DbPath" -ForegroundColor Red
    exit 1
}

# Construct argument list
$PyArgs = @(
    $ReporterScript,
    "--db-path", $DbPath,
    "--breakdown", $Breakdown,
    "--symbols", $Symbols,
    "--timeframes", $Timeframes,
    "--target-start-date", $TargetStartDate
)

if (-not $NoHtml) {
    if ($HtmlPath) {
        $PyArgs += @("--export-html", $HtmlPath)
    } else {
        $PyArgs += @("--export-html")
    }
}

if ($Open) {
    $PyArgs += @("--open")
}

if ($ExportCsv) {
    if ($CsvPath) {
        $PyArgs += @("--export-csv", $CsvPath)
    } else {
        $PyArgs += @("--export-csv")
    }
}

if ($ExportMd) {
    if ($MdPath) {
        $PyArgs += @("--export-md", $MdPath)
    } else {
        $PyArgs += @("--export-md")
    }
}

# Run python script
& $PythonExe -u @PyArgs
