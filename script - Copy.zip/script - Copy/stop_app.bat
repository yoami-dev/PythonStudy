@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Application Stop Script
:: Location: D:\Milind\MyTradingPlatform\script\stop_app.bat
:: ============================================================================

title SMM Trading Platform - Stopping Server

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%.."
set "PROJECT_ROOT=%CD%"

echo ============================================================================
echo   Stopping SMM Trading Platform
echo ============================================================================
echo Project Root : %PROJECT_ROOT%

set "PORT=8000"
set "KILLED=0"

:: 1. Check for process listening on port 8000
echo Checking port %PORT% for active listeners...
for /f "tokens=*" %%a in ('powershell -NoProfile -Command "(Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue).OwningProcess"') do (
    set "FOUND_PID=%%a"
    if defined FOUND_PID (
        if not "!FOUND_PID!"=="0" (
            echo Found active listener process PID: !FOUND_PID!
            echo Terminating process tree for PID !FOUND_PID!...
            taskkill /F /T /PID !FOUND_PID! >nul 2>&1
            powershell -NoProfile -Command "Stop-Process -Id !FOUND_PID! -Force -ErrorAction SilentlyContinue" >nul 2>&1
            echo [SUCCESS] Terminated PID !FOUND_PID! on port %PORT%.
            set "KILLED=1"
        )
    )
)

:: 2. Find and terminate any remaining uvicorn/python worker processes related to app.main:app
echo Checking for any remaining uvicorn/python workers for this platform...
for /f "tokens=*" %%i in ('powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { ($_.CommandLine -like '*uvicorn*app.main:app*') -or ($_.CommandLine -like '*spawn_main*' -and $_.CommandLine -like '*python*') } | Select-Object -ExpandProperty ProcessId"') do (
    set "PID_EXTRA=%%i"
    if defined PID_EXTRA (
        echo Found related worker process PID: !PID_EXTRA!
        taskkill /F /T /PID !PID_EXTRA! >nul 2>&1
        powershell -NoProfile -Command "Stop-Process -Id !PID_EXTRA! -Force -ErrorAction SilentlyContinue" >nul 2>&1
        set "KILLED=1"
    )
)

:: 3. Verification of port release (using ping for delay without redirection error)
ping 127.0.0.1 -n 3 >nul
set "PORT_STILL_OPEN=0"
for /f "tokens=*" %%a in ('powershell -NoProfile -Command "(Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue).OwningProcess"') do (
    set "PORT_STILL_OPEN=1"
)

echo.
if "!PORT_STILL_OPEN!"=="0" (
    if "!KILLED!"=="1" (
        echo ============================================================================
        echo [SUCCESS] SMM Trading Platform stopped successfully. Port %PORT% is now free.
        echo ============================================================================
    ) else (
        echo ============================================================================
        echo [INFO] No running instance of SMM Trading Platform found on port %PORT%.
        echo ============================================================================
    )
) else (
    echo ============================================================================
    echo [WARNING] Port %PORT% still appears to be occupied. Please check manually:
    echo           netstat -ano ^| findstr :%PORT%
    echo ============================================================================
)

echo.
endlocal
