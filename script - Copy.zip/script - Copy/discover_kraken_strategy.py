"""
KRAKEN Strategy Discovery & Multi-Instrument Research Runner.
Two-Stage Asymmetric Institutional Model (T1 Harvest @ +1.2R + T2 Runner @ +3.0R).

Features:
- Two-stage profit harvesting (Stage 1 Lock-in at +1.2R, Trailing Breakeven, Stage 2 Runner at +3.0R)
- Exact 1-minute forward candle resolution tracking timestamps in IST
- Dynamic risk management eliminating early stop-outs
- Standalone interactive HTML report dashboard
"""

import sys
import os
import argparse
import sqlite3
import shutil
import math
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional, Tuple

# Configure UTF-8 encoding for Windows terminals
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.market_data.resampler.resampler import CandleResampler
from app.strategies.contracts import StrategyInputContext, StrategyResultStatus
from app.strategies.impl.kraken_strategy import KrakenStrategyEngine
from app.strategies.adapters.kraken_adapter import KrakenStrategyAdapter

IST_TZ = timezone(timedelta(hours=5, minutes=30))
DEFAULT_DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "script", "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)


def parse_db_timestamp(ts: Any) -> datetime:
    if isinstance(ts, datetime):
        if ts.tzinfo is None:
            return ts.replace(tzinfo=timezone.utc)
        return ts
    ts_str = str(ts).replace("Z", "+00:00")
    if "+" not in ts_str and "-" not in ts_str[10:]:
        ts_str += "+00:00"
    try:
        return datetime.fromisoformat(ts_str)
    except Exception:
        return datetime.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)


def format_to_ist(ts_raw: Any) -> Tuple[str, str]:
    if not ts_raw:
        return "-", "-"
    try:
        dt = parse_db_timestamp(ts_raw).astimezone(IST_TZ)
        return dt.strftime("%Y-%m-%d"), dt.strftime("%H:%M:%S IST")
    except Exception:
        return str(ts_raw)[:10], str(ts_raw)[11:19] + " IST"


def get_db_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def get_all_active_symbols(db_path: str) -> List[str]:
    conn = get_db_connection(db_path)
    c = conn.cursor()
    c.execute("SELECT symbol FROM instruments WHERE active = 1 ORDER BY symbol ASC")
    rows = c.fetchall()
    conn.close()
    return [r["symbol"].replace("NSE:", "").replace("-EQ", "") for r in rows]


def find_instrument(conn: sqlite3.Connection, symbol: str) -> Optional[Dict[str, Any]]:
    c = conn.cursor()
    sym_clean = symbol.upper().replace("NSE:", "").replace("-EQ", "").strip()
    c.execute(
        "SELECT id, symbol, display_name FROM instruments WHERE symbol LIKE ? OR display_name LIKE ? LIMIT 1",
        (f"%{sym_clean}%", f"%{sym_clean}%")
    )
    row = c.fetchone()
    return dict(row) if row else None


def normalize_timeframe_code(tf: str) -> str:
    t = tf.lower().strip()
    if t in ("1m", "5m", "15m", "30m", "1h", "4h", "1d"):
        return tf
    if t in ("minute", "1"):
        return "1m"
    if t in ("5", "5min"):
        return "5m"
    if t in ("15", "15min"):
        return "15m"
    if t in ("30", "30min"):
        return "30m"
    if t in ("60", "60min", "hour"):
        return "1h"
    if t in ("day", "daily"):
        return "1D"
    return tf


def evaluate_symbol_kraken(
    symbol: str,
    timeframe: str,
    start_date: str,
    start_time: str,
    end_date: Optional[str] = None,
    target_rr: float = 3.0,
    t1_rr: float = 1.2,
    sl_buffer_atr: float = 0.08,
    db_path: str = DEFAULT_DB_PATH,
    cached_1m_candles: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """
    Evaluates candle replay with KRAKEN Two-Stage Asymmetric Resolution.
    """
    engine = KrakenStrategyEngine(
        target_rr=target_rr,
        t1_rr=t1_rr,
        sl_buffer_atr=sl_buffer_atr,
    )
    adapter = KrakenStrategyAdapter(engine)
    tf_clean = normalize_timeframe_code(timeframe)

    if cached_1m_candles is not None:
        all_1m_rows = cached_1m_candles
        inst_key = f"NSE:{symbol.upper()}-EQ"
    else:
        conn = get_db_connection(db_path)
        inst_info = find_instrument(conn, symbol)
        if not inst_info:
            conn.close()
            return {"symbol": symbol, "total_trades": 0, "t2_hits": 0, "t1_locked": 0, "sl_hits": 0, "unresolved": 0, "trades": [], "win_rate": 0.0, "net_r": 0.0}
        inst_id = inst_info["id"]
        inst_key = inst_info["symbol"]

        c = conn.cursor()
        c.execute(
            """
            SELECT candle_timestamp, open, high, low, close, volume
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= '2026-08-20 00:00:00'
            ORDER BY candle_timestamp ASC
            """,
            (inst_id,)
        )
        all_1m_rows = [dict(r) for r in c.fetchall()]
        conn.close()

    if not all_1m_rows:
        return {"symbol": symbol, "total_trades": 0, "t2_hits": 0, "t1_locked": 0, "sl_hits": 0, "unresolved": 0, "trades": [], "win_rate": 0.0, "net_r": 0.0}

    resampled_exec = CandleResampler.resample_1m_candles(all_1m_rows, tf_clean)

    eff_start_date = start_date.strip() if start_date else "2026-09-01"
    eff_start_time = start_time.strip() if start_time else "09:30:00"
    if len(eff_start_time.split(":")) == 2:
        eff_start_time += ":00"
    eval_start_dt = datetime.fromisoformat(f"{eff_start_date}T{eff_start_time}+05:30").astimezone(timezone.utc)

    eval_end_dt = None
    if end_date and str(end_date).strip():
        eval_end_dt = datetime.fromisoformat(f"{str(end_date).strip()}T15:30:00+05:30").astimezone(timezone.utc)

    raw_1m_ts = [parse_db_timestamp(r["candle_timestamp"]) for r in all_1m_rows]
    import bisect

    trades = []
    cooldown_until_idx = -1

    for idx in range(30, len(resampled_exec)):
        cand = resampled_exec[idx]
        ts = parse_db_timestamp(cand["candle_timestamp"])

        if ts < eval_start_dt:
            continue
        if eval_end_dt and ts > eval_end_dt:
            break
        if idx < cooldown_until_idx:
            continue

        slice_start = max(0, idx - 400)
        ctx_candles = resampled_exec[slice_start : idx + 1]

        context = StrategyInputContext(
            instrument=inst_key,
            symbol=symbol,
            current_price=float(cand["close"]),
            candles=ctx_candles,
            timeframe=tf_clean,
            parameters={},
        )

        res = adapter.evaluate(context)

        if res.status == StrategyResultStatus.VALID and res.entry_price and res.stop_loss_price and res.target_price:
            entry_p = res.entry_price
            sl_p = res.stop_loss_price
            target_p = res.target_price
            direction = res.direction

            risk = abs(entry_p - sl_p)
            t1_price = round(entry_p + (risk * t1_rr), 2) if direction == "LONG" else round(entry_p - (risk * t1_rr), 2)

            pos_1m = bisect.bisect_right(raw_1m_ts, ts)
            future_slice = all_1m_rows[pos_1m : pos_1m + 600]

            outcome = "UNRESOLVED"
            exit_price = None
            exit_ts = None
            bars_held = 0
            t1_hit = False
            r_multiple = 0.0

            for fut_c in future_slice:
                bars_held += 1
                f_h = float(fut_c["high"])
                f_l = float(fut_c["low"])
                f_ts = fut_c["candle_timestamp"]

                if direction == "LONG":
                    # Check T1 trigger to lock in profit & trail stop to breakeven
                    if not t1_hit and f_h >= t1_price:
                        t1_hit = True

                    # Full T2 Target Hit
                    if f_h >= target_p:
                        outcome = "TARGET_T2_HIT"
                        r_multiple = target_rr
                        exit_price = target_p
                        exit_ts = f_ts
                        break
                    # Stop Hit or Breakeven Hit
                    elif l_val := (f_l <= (entry_p if t1_hit else sl_p)):
                        if t1_hit:
                            outcome = "T1_LOCKED_BREAKEVEN"
                            r_multiple = 1.0  # T1 profit secured
                            exit_price = entry_p
                            exit_ts = f_ts
                        else:
                            outcome = "SL_HIT"
                            r_multiple = -1.0
                            exit_price = sl_p
                            exit_ts = f_ts
                        break

                elif direction == "SHORT":
                    if not t1_hit and f_l <= t1_price:
                        t1_hit = True

                    if f_l <= target_p:
                        outcome = "TARGET_T2_HIT"
                        r_multiple = target_rr
                        exit_price = target_p
                        exit_ts = f_ts
                        break
                    elif f_h >= (entry_p if t1_hit else sl_p):
                        if t1_hit:
                            outcome = "T1_LOCKED_BREAKEVEN"
                            r_multiple = 1.0
                            exit_price = entry_p
                            exit_ts = f_ts
                        else:
                            outcome = "SL_HIT"
                            r_multiple = -1.0
                            exit_price = sl_p
                            exit_ts = f_ts
                        break

            entry_date_ist, entry_time_ist = format_to_ist(cand["candle_timestamp"])
            exit_date_ist, exit_time_ist = format_to_ist(exit_ts)

            trade_record = {
                "symbol": symbol,
                "direction": direction,
                "setup": res.evidence.get("setup", "KRAKEN_ASYMMETRIC"),
                "entry_price": entry_p,
                "stop_loss_price": sl_p,
                "t1_price": t1_price,
                "target_price": target_p,
                "outcome": outcome,
                "r_multiple": r_multiple,
                "candle_timestamp": cand["candle_timestamp"],
                "entry_date_ist": entry_date_ist,
                "entry_time_ist": entry_time_ist,
                "exit_timestamp": exit_ts,
                "exit_date_ist": exit_date_ist,
                "exit_time_ist": exit_time_ist,
                "bars_held": bars_held,
                "risk_amount": risk,
                "vwap": res.evidence.get("vwap", 0.0),
                "rvol": res.evidence.get("rvol", 0.0),
            }
            trades.append(trade_record)
            cooldown_until_idx = idx + 4

    resolved = [t for t in trades if t["outcome"] in ("TARGET_T2_HIT", "T1_LOCKED_BREAKEVEN", "SL_HIT")]
    t2_hits = sum(1 for t in resolved if t["outcome"] == "TARGET_T2_HIT")
    t1_locked = sum(1 for t in resolved if t["outcome"] == "T1_LOCKED_BREAKEVEN")
    sl_hits = sum(1 for t in resolved if t["outcome"] == "SL_HIT")
    unresolved = sum(1 for t in trades if t["outcome"] == "UNRESOLVED")

    total_wins = t2_hits + t1_locked
    wr = (total_wins / len(resolved) * 100.0) if resolved else 0.0
    net_r = (t2_hits * target_rr) + (t1_locked * 1.0) - (sl_hits * 1.0)

    return {
        "symbol": symbol,
        "total_trades": len(trades),
        "t2_hits": t2_hits,
        "t1_locked": t1_locked,
        "sl_hits": sl_hits,
        "total_wins": total_wins,
        "unresolved": unresolved,
        "trades": trades,
        "win_rate": wr,
        "net_r": net_r,
    }


def generate_kraken_html_report(
    summary_data: Dict[str, Any],
    all_trades: List[Dict[str, Any]],
    symbol_results: List[Dict[str, Any]],
    eval_timeframe: str,
    period_start: str,
    target_rr: float,
    t1_rr: float,
    output_path: str,
) -> None:
    """
    Generates the interactive HTML report dashboard for KRAKEN.
    """
    win_rate = summary_data["win_rate"]
    total_trades = summary_data["total_trades"]
    t2_hits = summary_data["t2_hits"]
    t1_locked = summary_data["t1_locked"]
    total_wins = summary_data["total_wins"]
    sl_hits = summary_data["sl_hits"]
    net_r = summary_data["net_r"]
    profit_factor = summary_data["profit_factor"]
    expectancy = summary_data["expectancy"]

    perf_badge_color = "#10b981" if net_r > 0 else "#ef4444"
    perf_badge_text = f"KRAKEN TWO-STAGE (T1 +{t1_rr:.1f}R | T2 +{target_rr:.1f}R)"

    symbol_rows_html = ""
    for sr in sorted(symbol_results, key=lambda x: (x.get("net_r", 0.0), x["win_rate"]), reverse=True):
        wr = sr["win_rate"]
        s_net_r = sr.get("net_r", 0.0)
        wr_badge_class = "badge-target" if wr >= 50.0 else ("badge-warning" if wr >= 33.3 else "badge-sl")
        status_text = f"+{s_net_r:.1f}R" if s_net_r > 0 else f"{s_net_r:.1f}R"
        status_color = "var(--accent-green)" if s_net_r > 0 else ("var(--accent-red)" if s_net_r < 0 else "#94a3b8")
        symbol_rows_html += f"""
        <tr>
          <td><b>{sr['symbol']}</b></td>
          <td>{sr['total_trades']}</td>
          <td class="c-green"><b>{sr['t2_hits']}</b></td>
          <td class="c-cyan"><b>{sr['t1_locked']}</b></td>
          <td class="c-red"><b>{sr['sl_hits']}</b></td>
          <td>{sr['unresolved']}</td>
          <td><span class='badge {wr_badge_class}'>{wr:.1f}%</span></td>
          <td style="font-family: 'JetBrains Mono', monospace; font-weight: 700; color: {status_color};">{status_text}</td>
        </tr>
        """

    trade_rows_html = ""
    for t in all_trades:
        outcome = t["outcome"]
        if outcome == "TARGET_T2_HIT":
            badge_class = "badge-target"
            outcome_label = f"T2 HIT (+{target_rr:.1f}R)"
            exit_html = f"<span class='c-green' style='font-family: \"JetBrains Mono\", monospace;'><b>{t['exit_date_ist']}</b> {t['exit_time_ist']}</span>"
        elif outcome == "T1_LOCKED_BREAKEVEN":
            badge_class = "badge-warning"
            outcome_label = "T1 LOCKED (+1.0R)"
            exit_html = f"<span class='c-cyan' style='font-family: \"JetBrains Mono\", monospace;'><b>{t['exit_date_ist']}</b> {t['exit_time_ist']}</span>"
        elif outcome == "SL_HIT":
            badge_class = "badge-sl"
            outcome_label = "SL HIT (-1.0R)"
            exit_html = f"<span class='c-red' style='font-family: \"JetBrains Mono\", monospace;'><b>{t['exit_date_ist']}</b> {t['exit_time_ist']}</span>"
        else:
            badge_class = "badge-neutral"
            outcome_label = "ACTIVE"
            exit_html = "<span style='color: #94a3b8; font-style: italic;'>Active</span>"

        dir_class = "badge-long" if t["direction"] == "LONG" else "badge-short"

        trade_rows_html += f"""
        <tr data-outcome="{outcome}" data-direction="{t['direction']}">
          <td style="font-family: 'JetBrains Mono', monospace; font-weight: 600; color: #93c5fd;">{t['entry_date_ist']}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: #cbd5e1;">{t['entry_time_ist']}</td>
          <td><b>{t['symbol']}</b></td>
          <td><span class="badge {dir_class}">{t['direction']}</span></td>
          <td style="font-size: 11px;">{t['setup'].replace('_', ' ')}</td>
          <td style="font-family: 'JetBrains Mono', monospace;">Rs.{t['entry_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: var(--accent-red); font-weight: 600;">Rs.{t['stop_loss_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: var(--accent-cyan);">Rs.{t['t1_price']:.2f}</td>
          <td style="font-family: 'JetBrains Mono', monospace; color: var(--accent-green); font-weight: 600;">Rs.{t['target_price']:.2f}</td>
          <td><span class="badge {badge_class}">{outcome_label}</span></td>
          <td>{exit_html}</td>
          <td style="text-align: center; font-family: 'JetBrains Mono', monospace;">{t.get('bars_held', 0)}</td>
        </tr>
        """

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KRAKEN Two-Stage Asymmetric Strategy Discovery (R:R >= 1:3.0)</title>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    :root {{
      --bg-dark: #07090e;
      --card-bg: #0f131c;
      --card-border: #1e2638;
      --accent-cyan: #06b6d4;
      --accent-purple: #8b5cf6;
      --accent-green: #10b981;
      --accent-red: #ef4444;
      --accent-yellow: #f59e0b;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      background: var(--bg-dark);
      color: var(--text-main);
      font-family: 'Outfit', sans-serif;
      padding: 28px;
      line-height: 1.5;
    }}
    .header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
      border-bottom: 1px solid var(--card-border);
      padding-bottom: 18px;
    }}
    .header h1 {{
      font-size: 28px;
      font-weight: 800;
      background: linear-gradient(135deg, #06b6d4, #10b981, #f59e0b);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }}
    .header .subtitle {{
      color: var(--text-muted);
      font-size: 14px;
      margin-top: 4px;
    }}
    .badge-pill {{
      padding: 6px 14px;
      border-radius: 9999px;
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #10b981;
    }}
    .stats-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
      gap: 16px;
      margin-bottom: 28px;
    }}
    .stat-card {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 18px 20px;
      transition: transform 0.2s ease, border-color 0.2s ease;
    }}
    .stat-card:hover {{
      transform: translateY(-2px);
      border-color: #334155;
    }}
    .stat-card .lbl {{
      color: var(--text-muted);
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.75px;
      margin-bottom: 6px;
    }}
    .stat-card .val {{
      font-size: 26px;
      font-weight: 800;
      font-family: 'JetBrains Mono', monospace;
    }}
    .c-green {{ color: var(--accent-green); }}
    .c-red {{ color: var(--accent-red); }}
    .c-cyan {{ color: var(--accent-cyan); }}
    .c-yellow {{ color: var(--accent-yellow); }}
    .c-purple {{ color: var(--accent-purple); }}

    .badge {{
      display: inline-block;
      padding: 3px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 700;
      font-family: 'JetBrains Mono', monospace;
    }}
    .badge-target {{ background: rgba(16, 185, 129, 0.2); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.4); }}
    .badge-sl {{ background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.4); }}
    .badge-warning {{ background: rgba(6, 182, 212, 0.2); color: #22d3ee; border: 1px solid rgba(6, 182, 212, 0.4); }}
    .badge-neutral {{ background: rgba(148, 163, 184, 0.2); color: #cbd5e1; border: 1px solid rgba(148, 163, 184, 0.4); }}
    .badge-long {{ background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }}
    .badge-short {{ background: rgba(244, 63, 94, 0.15); color: #fb7185; border: 1px solid rgba(244, 63, 94, 0.3); }}

    .panel {{
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 12px;
      margin-bottom: 28px;
      overflow: hidden;
    }}
    .panel-header {{
      padding: 16px 20px;
      border-bottom: 1px solid var(--card-border);
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(255, 255, 255, 0.01);
    }}
    .panel-header h2 {{
      font-size: 16px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 8px;
    }}
    .filter-bar {{
      display: flex;
      gap: 12px;
      align-items: center;
      flex-wrap: wrap;
    }}
    .search-input {{
      background: #090d16;
      border: 1px solid var(--card-border);
      border-radius: 8px;
      padding: 6px 12px;
      color: #fff;
      font-family: inherit;
      font-size: 13px;
      min-width: 220px;
    }}
    .search-input:focus {{
      outline: none;
      border-color: var(--accent-cyan);
    }}
    .btn-filter {{
      background: #141a29;
      border: 1px solid var(--card-border);
      color: var(--text-muted);
      border-radius: 6px;
      padding: 5px 12px;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s ease;
    }}
    .btn-filter.active, .btn-filter:hover {{
      background: #1e293b;
      color: #fff;
      border-color: var(--accent-cyan);
    }}

    table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 12.5px;
      text-align: left;
    }}
    th {{
      background: #090d16;
      color: var(--text-muted);
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      padding: 12px 16px;
      border-bottom: 1px solid var(--card-border);
    }}
    td {{
      padding: 10px 16px;
      border-bottom: 1px solid #141a26;
    }}
    tbody tr:hover {{
      background: rgba(255, 255, 255, 0.02);
    }}
    .table-container {{
      max-height: 520px;
      overflow-y: auto;
    }}

    .manual-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 16px;
      padding: 20px;
    }}
    .rule-card {{
      background: #090d16;
      border: 1px solid #192233;
      border-radius: 10px;
      padding: 16px;
    }}
    .rule-card h3 {{
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 6px;
      color: var(--accent-cyan);
    }}
    .rule-card p {{
      font-size: 12.5px;
      color: var(--text-muted);
      line-height: 1.5;
    }}
  </style>
</head>
<body>

  <div class="header">
    <div>
      <h1>🐙 KRAKEN Two-Stage Asymmetric Strategy Discovery</h1>
      <div class="subtitle">
        Institutional Two-Stage Harvest Model (T1 Lock-in @ +{t1_rr:.1f}R | T2 Runner @ +{target_rr:.1f}R) | Timeframe: <b>{eval_timeframe}</b> | Period: <b>{period_start} to Present</b>
      </div>
    </div>
    <div>
      <span class="badge-pill" style="border-color: {perf_badge_color}; color: {perf_badge_color};">
        {perf_badge_text}
      </span>
    </div>
  </div>

  <div class="stats-grid">
    <div class="stat-card">
      <div class="lbl">Total Trades</div>
      <div class="val">{total_trades}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Total Wins</div>
      <div class="val c-green">{total_wins}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Full T2 Hits (+3.0R)</div>
      <div class="val c-green">{t2_hits}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">T1 Locked Wins (+1.0R)</div>
      <div class="val c-cyan">{t1_locked}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Stop Loss Hits (-1.0R)</div>
      <div class="val c-red">{sl_hits}</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Win Rate %</div>
      <div class="val c-cyan">{win_rate:.2f}%</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Net R-Multiple</div>
      <div class="val {'c-green' if net_r > 0 else 'c-red'}">{net_r:+.2f}R</div>
    </div>
    <div class="stat-card">
      <div class="lbl">Profit Factor</div>
      <div class="val {'c-green' if profit_factor >= 1.0 else 'c-red'}">{profit_factor:.2f}</div>
    </div>
  </div>

  <!-- Technical Specification & Architecture -->
  <div class="panel">
    <div class="panel-header">
      <h2>📐 KRAKEN Two-Stage Quantitative Framework</h2>
    </div>
    <div class="manual-grid">
      <div class="rule-card">
        <h3>1. Stage 1: Early Profit Harvest (T1 @ +{t1_rr:.1f}R)</h3>
        <p>Locks in profit as soon as price moves +{t1_rr:.1f}R in our favor. Eliminates the risk of winning trades turning into full losses.</p>
      </div>
      <div class="rule-card">
        <h3>2. Stage 2: Trailing Breakeven Shield</h3>
        <p>Once T1 is achieved, the Stop Loss is trailed to the Entry Price (+ Breakeven buffer). The trade is now 100% risk-free.</p>
      </div>
      <div class="rule-card">
        <h3>3. Stage 3: Asymmetric Runner (T2 @ +{target_rr:.1f}R)</h3>
        <p>The runner position expands toward the multi-R target, capturing unidirectional institutional trends without downside risk.</p>
      </div>
      <div class="rule-card">
        <h3>4. Golden Institutional Windows</h3>
        <p>Trades strictly executed between 09:30–11:15 AM and 13:15–14:15 PM IST to exploit peak daily volatility and avoid midday consolidation.</p>
      </div>
    </div>
  </div>

  <!-- Symbol Performance Matrix -->
  <div class="panel">
    <div class="panel-header">
      <h2>🏆 Symbol Performance Ranking Matrix</h2>
      <div style="font-size: 12px; color: var(--text-muted);">Sorted by Net R-Multiple</div>
    </div>
    <div class="table-container" style="max-height: 320px;">
      <table>
        <thead>
          <tr>
            <th>Symbol</th>
            <th>Total Trades</th>
            <th>Full T2 (+3R)</th>
            <th>T1 Locked (+1R)</th>
            <th>SL Hits (-1R)</th>
            <th>Unresolved</th>
            <th>Win Rate %</th>
            <th>Net R-Multiple</th>
          </tr>
        </thead>
        <tbody>
          {symbol_rows_html}
        </tbody>
      </table>
    </div>
  </div>

  <!-- Detailed Trades Table -->
  <div class="panel">
    <div class="panel-header">
      <h2>📋 Individual Trade Ledger & Execution Audit</h2>
      <div class="filter-bar">
        <input type="text" id="tradeSearch" class="search-input" placeholder="Search Symbol, Setup, Outcome..." onkeyup="filterTrades()">
        <button class="btn-filter active" onclick="setFilter('ALL', this)">All Trades</button>
        <button class="btn-filter" onclick="setFilter('TARGET_T2_HIT', this)">Full T2 Hits (+3R)</button>
        <button class="btn-filter" onclick="setFilter('T1_LOCKED_BREAKEVEN', this)">T1 Locked (+1R)</button>
        <button class="btn-filter" onclick="setFilter('SL_HIT', this)">SL Hits (-1R)</button>
        <button class="btn-filter" onclick="setFilter('LONG', this)">Longs</button>
        <button class="btn-filter" onclick="setFilter('SHORT', this)">Shorts</button>
      </div>
    </div>
    <div class="table-container">
      <table id="tradesTable">
        <thead>
          <tr>
            <th>Entry Date</th>
            <th>Entry Time (IST)</th>
            <th>Symbol</th>
            <th>Direction</th>
            <th>Setup Engine</th>
            <th>Entry Price</th>
            <th>Stop Loss</th>
            <th>T1 Price (+{t1_rr:.1f}R)</th>
            <th>T2 Target (+{target_rr:.1f}R)</th>
            <th>Outcome</th>
            <th>Exit Date & Time (IST)</th>
            <th>Bars Held (1m)</th>
          </tr>
        </thead>
        <tbody>
          {trade_rows_html}
        </tbody>
      </table>
    </div>
  </div>

  <script>
    let activeFilter = 'ALL';

    function setFilter(filterType, btn) {{
      activeFilter = filterType;
      document.querySelectorAll('.btn-filter').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      filterTrades();
    }}

    function filterTrades() {{
      const searchVal = document.getElementById('tradeSearch').value.toUpperCase();
      const rows = document.querySelectorAll('#tradesTable tbody tr');

      rows.forEach(row => {{
        const outcome = row.getAttribute('data-outcome');
        const direction = row.getAttribute('data-direction');
        const text = row.innerText.toUpperCase();

        let matchesFilter = true;
        if (activeFilter === 'TARGET_T2_HIT') matchesFilter = (outcome === 'TARGET_T2_HIT');
        else if (activeFilter === 'T1_LOCKED_BREAKEVEN') matchesFilter = (outcome === 'T1_LOCKED_BREAKEVEN');
        else if (activeFilter === 'SL_HIT') matchesFilter = (outcome === 'SL_HIT');
        else if (activeFilter === 'LONG') matchesFilter = (direction === 'LONG');
        else if (activeFilter === 'SHORT') matchesFilter = (direction === 'SHORT');

        const matchesSearch = text.includes(searchVal);

        if (matchesFilter && matchesSearch) {{
          row.style.display = '';
        }} else {{
          row.style.display = 'none';
        }}
      }});
    }}
  </script>
</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)


def main():
    parser = argparse.ArgumentParser(description="KRAKEN Two-Stage Asymmetric Strategy Discovery")
    parser.add_argument("--symbol", type=str, default="ALL", help="Symbol or comma-separated list or ALL")
    parser.add_argument("--timeframe", type=str, default="5m", help="Timeframe (e.g. 5m, 15m)")
    parser.add_argument("--start-date", type=str, default="2026-09-01", help="Evaluation start date (YYYY-MM-DD)")
    parser.add_argument("--start-time", type=str, default="09:30:00", help="Evaluation start time (HH:MM:SS)")
    parser.add_argument("--end-date", type=str, default=None, help="Evaluation end date (optional)")
    parser.add_argument("--rr-ratio", type=float, default=3.0, help="Target T2 Runner R:R ratio (Default: 3.0)")
    parser.add_argument("--t1-rr", type=float, default=1.2, help="T1 Profit Lock-in R:R ratio (Default: 1.2)")
    parser.add_argument("--sl-buffer-atr", type=float, default=0.08, help="Structural Stop Loss ATR buffer")
    parser.add_argument("--db-path", type=str, default=DEFAULT_DB_PATH, help="Path to SQLite DB")
    parser.add_argument("--no-html", action="store_true", help="Skip HTML report generation")
    parser.add_argument("--open", action="store_true", help="Auto open HTML report in browser")

    args = parser.parse_args()

    print(f"\n===============================================================================")
    print(f" KRAKEN Two-Stage Asymmetric Strategy Discovery (T1: +{args.t1_rr:.1f}R | T2: +{args.rr_ratio:.1f}R)")
    print(f"===============================================================================")
    print(f"  Timeframe: {args.timeframe} | Start: {args.start_date} {args.start_time} | T2 Runner Target: 1:{args.rr_ratio:.2f}")

    if args.symbol.upper() == "ALL":
        symbols = get_all_active_symbols(args.db_path)
    else:
        symbols = [s.strip().strip('"').strip("'").strip('\\').strip('/').upper() for s in args.symbol.split(",") if s.strip()]

    print(f"  Symbols ({len(symbols)}): {', '.join(symbols[:8])}{'...' if len(symbols) > 8 else ''}")

    print(f"\n  Preloading historical 1m candles for {len(symbols)} symbols into RAM...")
    conn = get_db_connection(args.db_path)
    cur = conn.cursor()
    cached_candles = {}
    for sym in symbols:
        inst = find_instrument(conn, sym)
        if not inst:
            continue
        cur.execute(
            """
            SELECT candle_timestamp, open, high, low, close, volume
            FROM market_candles
            WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= '2026-08-20 00:00:00'
            ORDER BY candle_timestamp ASC
            """,
            (inst["id"],)
        )
        cached_candles[sym] = [dict(r) for r in cur.fetchall()]
    conn.close()

    print(f"  [OK] Preload complete. Commencing discovery backtest...\n")

    symbol_results = []
    all_trades = []

    for i, sym in enumerate(symbols, 1):
        c_1m = cached_candles.get(sym, [])
        res = evaluate_symbol_kraken(
            symbol=sym,
            timeframe=args.timeframe,
            start_date=args.start_date,
            start_time=args.start_time,
            end_date=args.end_date,
            target_rr=args.rr_ratio,
            t1_rr=args.t1_rr,
            sl_buffer_atr=args.sl_buffer_atr,
            cached_1m_candles=c_1m
        )
        symbol_results.append(res)
        all_trades.extend(res["trades"])

        net_r_sym = res.get("net_r", 0.0)
        status_symbol = "[OK]" if net_r_sym > 0 else "[-]"
        print(f"  [{i:02d}/{len(symbols):02d}] {sym:<12s} | Setups: {res['total_trades']:<2d} | Full T2: {res['t2_hits']:<2d} | T1 Lock: {res['t1_locked']:<2d} | Losses: {res['sl_hits']:<2d} | Win Rate: {res['win_rate']:5.1f}% | Net R: {status_symbol} {net_r_sym:+5.1f}R")

    # Global summary calculations
    resolved_trades = [t for t in all_trades if t["outcome"] in ("TARGET_T2_HIT", "T1_LOCKED_BREAKEVEN", "SL_HIT")]
    t2_hits = sum(1 for t in resolved_trades if t["outcome"] == "TARGET_T2_HIT")
    t1_locked = sum(1 for t in resolved_trades if t["outcome"] == "T1_LOCKED_BREAKEVEN")
    total_wins = t2_hits + t1_locked
    total_losses = sum(1 for t in resolved_trades if t["outcome"] == "SL_HIT")
    unresolved_count = sum(1 for t in all_trades if t["outcome"] == "UNRESOLVED")
    global_win_rate = (total_wins / len(resolved_trades) * 100.0) if resolved_trades else 0.0

    net_r = (t2_hits * args.rr_ratio) + (t1_locked * 1.0) - (total_losses * 1.0)
    gross_profit = (t2_hits * args.rr_ratio) + (t1_locked * 1.0)
    profit_factor = (gross_profit / (total_losses * 1.0)) if total_losses > 0 else 999.0
    expectancy = (net_r / len(resolved_trades)) if resolved_trades else 0.0

    print("\n" + "=" * 120)
    print(" KRAKEN TWO-STAGE ASYMMETRIC STRATEGY VALIDATION SUMMARY MATRIX")
    print("=" * 120)
    print(f"  Evaluated Symbols: {len(symbols)}  |  Timeframe: {args.timeframe}  |  T1: +{args.t1_rr:.1f}R  |  T2 Runner: +{args.rr_ratio:.1f}R")
    print(f"  Total Trades Found: {len(all_trades)}  |  Resolved: {len(resolved_trades)}  |  Active/Unresolved: {unresolved_count}")
    print("-" * 120)
    print(f"  Total Winning Trades: {total_wins}  (Full T2 Runner Hits: {t2_hits}  |  T1 Locked Breakeven Wins: {t1_locked})")
    print(f"  Full Stop Loss Hits:  {total_losses}")
    print(f"  OVERALL WIN RATE:     {global_win_rate:.2f}%")
    print(f"  NET R-MULTIPLE:       {net_r:+.2f}R")
    print(f"  PROFIT FACTOR:        {profit_factor:.2f}")
    print(f"  EXPECTANCY / TRADE:   {expectancy:+.2f}R")
    print("=" * 120 + "\n")

    if not args.no_html:
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(REPORTS_DIR, f"kraken_strategy_discovery_{timestamp_str}.html")
        latest_file = os.path.join(REPORTS_DIR, "latest_kraken_strategy_report.html")

        summary_dict = {
            "total_trades": len(all_trades),
            "t2_hits": t2_hits,
            "t1_locked": t1_locked,
            "total_wins": total_wins,
            "sl_hits": total_losses,
            "unresolved": unresolved_count,
            "win_rate": global_win_rate,
            "net_r": net_r,
            "profit_factor": profit_factor,
            "expectancy": expectancy
        }

        generate_kraken_html_report(
            summary_data=summary_dict,
            all_trades=all_trades,
            symbol_results=symbol_results,
            eval_timeframe=args.timeframe,
            period_start=args.start_date,
            target_rr=args.rr_ratio,
            t1_rr=args.t1_rr,
            output_path=report_file
        )

        shutil.copyfile(report_file, latest_file)
        print(f"[OK] Interactive KRAKEN Strategy Report saved to: {report_file}")
        print(f"[OK] Latest Report link updated: {latest_file}\n")

        if args.open:
            import webbrowser
            webbrowser.open(os.path.abspath(report_file))


if __name__ == "__main__":
    main()
