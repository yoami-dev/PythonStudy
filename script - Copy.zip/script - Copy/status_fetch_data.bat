@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Background Data Fetcher Status Check (Batch)
:: Location: D:\Milind\MyTradingPlatform\script\status_fetch_data.bat
:: ============================================================================

title SMM Trading Platform - Fetcher Status Check

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%status_fetch_data.ps1" %*

endlocal
