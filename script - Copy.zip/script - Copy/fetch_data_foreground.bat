@echo off
setlocal enabledelayedexpansion

:: ============================================================================
:: SMM Trading Platform - Interactive Nifty 50 Historical Data Fetcher
:: Location: D:\Milind\MyTradingPlatform\script\fetch_data_foreground.bat
:: ============================================================================

title SMM Trading Platform - Interactive Data Fetcher

set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%.."
set "PROJECT_ROOT=%CD%"

set "PYTHON_EXE=%PROJECT_ROOT%\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    set "PYTHON_EXE=python"
)

echo ============================================================================
echo   Starting Interactive Historical Data Ingestion
echo ============================================================================
echo Project Root : %PROJECT_ROOT%
echo Python Exe   : %PYTHON_EXE%
echo.

"%PYTHON_EXE%" "%SCRIPT_DIR%fetch_nifty50_data.py" %*

echo.
echo ============================================================================
echo Fetch execution finished. Press any key to close this console.
echo ============================================================================
pause

endlocal
