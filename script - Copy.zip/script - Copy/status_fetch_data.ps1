$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$PidFile = Join-Path $ScriptDir ".fetch_data.pid"
$LogFile = Join-Path $ScriptDir "fetch_data.log"

Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "  SMM Background Data Fetcher Status Check" -ForegroundColor Cyan
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "Project Root : $ProjectRoot"
Write-Host "PID File     : $PidFile"
Write-Host "Log File     : $LogFile"
Write-Host ""

$running = $false

if (Test-Path $PidFile) {
    $procId = Get-Content $PidFile -ErrorAction SilentlyContinue
    if ($procId) {
        $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
        if ($p) {
            $running = $true
            $wsMb = [math]::Round($p.WorkingSet64 / 1MB, 2)
            Write-Host "[STATUS] Background Data Fetcher is RUNNING" -ForegroundColor Green
            Write-Host ("  - PID         : " + $p.Id)
            Write-Host ("  - Memory Usage: " + $wsMb + " MB")
            Write-Host ("  - Start Time  : " + $p.StartTime)
        }
    }
}

if (-not $running) {
    $extraProcs = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*fetch_nifty50_data.py*' }
    if ($extraProcs) {
        Write-Host "[STATUS] Background Data Fetcher is RUNNING (Discovered by command line)" -ForegroundColor Green
        foreach ($ep in $extraProcs) {
            Write-Host ("  - PID: " + $ep.ProcessId)
        }
    } else {
        Write-Host "[STATUS] Background Data Fetcher is STOPPED / IDLE" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "------------------------------------------------------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "  Recent Ingestion Log (Last 20 entries):" -ForegroundColor White
Write-Host "------------------------------------------------------------------------------------------------------------" -ForegroundColor DarkGray
if (Test-Path $LogFile) {
    Get-Content $LogFile -Tail 20 | ForEach-Object { Write-Host $_ }
} else {
    Write-Host "(Log file does not exist yet.)" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "==============================================================================================================" -ForegroundColor Cyan
