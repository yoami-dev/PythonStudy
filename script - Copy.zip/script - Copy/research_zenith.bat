@echo off
setlocal enabledelayedexpansion

REM ============================================================================
REM ZENITH Strategy Discovery & Multi-Instrument Research Batch Runner (R:R >= 1:2.0)
REM ============================================================================

set SCRIPT_DIR=%~dp0
set PROJECT_ROOT=%SCRIPT_DIR%..
set VENV_PYTHON=%PROJECT_ROOT%\venv\Scripts\python.exe

if not exist "%VENV_PYTHON%" (
    set VENV_PYTHON=python
)
set PYTHONPATH=%PROJECT_ROOT%;%PYTHONPATH%

REM Default parameters
set SYMBOL=ALL
set TIMEFRAME=5m
set START_DATE=2026-09-01
set START_TIME=09:30:00
set RR_RATIO=2.0
set SL_ATR_MULT=1.0
set OPEN_FLAG=
set EXTRA_ARGS=

:parse_args
if "%~1"=="" goto run_script

if /i "%~1"=="-Symbol" (
    set SYMBOL=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--symbol" (
    set SYMBOL=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-Timeframe" (
    set TIMEFRAME=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--timeframe" (
    set TIMEFRAME=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-StartDate" (
    set START_DATE=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--start-date" (
    set START_DATE=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-StartTime" (
    set START_TIME=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--start-time" (
    set START_TIME=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-RR" (
    set RR_RATIO=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--rr-ratio" (
    set RR_RATIO=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-SL" (
    set SL_ATR_MULT=%~2
    shift
    shift
    goto parse_args
)
if /i "%~1"=="--sl-atr-mult" (
    set SL_ATR_MULT=%~2
    shift
    shift
    goto parse_args
)

if /i "%~1"=="-Open" (
    set OPEN_FLAG=--open
    shift
    goto parse_args
)
if /i "%~1"=="--open" (
    set OPEN_FLAG=--open
    shift
    goto parse_args
)

set EXTRA_ARGS=%EXTRA_ARGS% %1
shift
goto parse_args

:run_script
echo ===============================================================================
echo  ZENITH High Risk-Reward Strategy Discovery (R:R 1:%RR_RATIO%)
echo ===============================================================================
echo  Symbol:     %SYMBOL%
echo  Timeframe:  %TIMEFRAME%
echo  Start Date: %START_DATE% %START_TIME%
echo  R:R Target: 1:%RR_RATIO%
echo ===============================================================================

"%VENV_PYTHON%" "%SCRIPT_DIR%discover_zenith_strategy.py" ^
    --symbol "%SYMBOL%" ^
    --timeframe "%TIMEFRAME%" ^
    --start-date "%START_DATE%" ^
    --start-time "%START_TIME%" ^
    --rr-ratio "%RR_RATIO%" ^
    --sl-atr-mult "%SL_ATR_MULT%" ^
    %OPEN_FLAG% %EXTRA_ARGS%

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] ZENITH Strategy Discovery script exited with error code %ERRORLEVEL%.
    exit /b %ERRORLEVEL%
)

exit /b 0
