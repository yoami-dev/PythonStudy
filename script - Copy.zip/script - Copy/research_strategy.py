#!/usr/bin/env python3
"""
================================================================================
SMM Trading Platform - Strategy Research & Historical Outcome CLI Evaluator
Location: E:\\Milind\\MyTradingPlatform\\script\\research_strategy.py
================================================================================

Executes multi-strategy historical evaluation and outcome resolution for strategies:
- SMM  : Smart Money Model (Production Active: multi-timeframe Tide/Wave/Ripple + indicators)
- PAPA : Price Action Pattern Analysis (Future Roadmap Track: pending development)
- FOME : Flow Order Momentum Evaluation (Future Roadmap Track: pending development)
- GUE  : Gap-Unfill Execution (Future Roadmap Track: pending development)
- SMC  : Smart Money Concepts (Future Roadmap Track: pending development)

Supports:
- Specific Symbol or ALL Symbols (e.g. -Symbol INFY or -Symbol ALL or -Symbol INFY,TCS)
- Specific Timeframe or ALL Timeframes (e.g. -Timeframe 15m or -Timeframe ALL or -Timeframe 1m,15m,1h,1D)
- Strategy Filter (e.g. -Strategies SMM or -Strategies ALL)
- Terminal Matrix & Deep Dive Output
- Interactive Standalone HTML Report Dashboard with Live Search & Filtering
"""

import os
import sys
import csv
import json
import time
import math
import sqlite3
import argparse
import webbrowser
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional, Tuple, Sequence
from concurrent.futures import ThreadPoolExecutor, as_completed

# Configure UTF-8 encoding for Windows terminals
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

if sys.stderr and hasattr(sys.stderr, "reconfigure"):
    try:
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

# Configure Project Root
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

DEFAULT_DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "script", "reports")

# Import Core Domain Models & Strategy Framework
from app.utils.datetime_utils import ensure_utc, utc_now
from app.strategies.contracts import (
    StrategyInputContext,
    StrategyResult,
    StrategyResultStatus,
)
from app.strategies.registry import (
    StrategyRegistry,
    get_research_strategy_registry,
    get_default_strategy_registry,
)
from app.strategies.runner import (
    MultiStrategyResearchRunner,
    ResearchEvaluationResult,
)
from app.strategies.confluence import (
    CommonConfluenceEngine,
    ConfluenceResult,
    ConfluenceStatus,
)
from app.research.replay import (
    HistoricalReplayEngine,
    _extract_candle_timestamp,
)
from app.research.outcome_evaluator import (
    HistoricalOutcome,
    HistoricalOutcomeResult,
    HistoricalOutcomeEvaluator,
)
from app.research.level_resolvers import (
    get_level_resolver_for_strategy,
    smm_level_resolver,
    default_level_resolver,
)
from app.smm.config.timeframe_profiles import (
    SMM_TIMEFRAME_PROFILES,
    get_smm_timeframe_profile,
)
from app.api.research_router import (
    get_smm_timeframe_chain,
    get_minimum_smm_1m_lookback,
    PRESET_SCENARIOS,
)
from app.market_data.resampler.resampler import CandleResampler

ALL_KNOWN_STRATEGIES = ["SMM", "PAPA", "FOME", "GUE", "SMC"]
ALL_RESEARCH_TIMEFRAMES = ["1m", "2m", "3m", "5m", "15m", "30m", "1h", "1D"]


def resolve_smm_timeframe_hierarchy(
    timeframe: str,
    custom_tide: Optional[str] = None,
    custom_wave: Optional[str] = None
) -> Dict[str, str]:
    """
    Resolves TIDE, WAVE, and RIPPLE screen timeframes for any given execution timeframe
    using SMM Triple-Screen Factor-of-5 methodology with support for custom Tide & Wave overrides.
    """
    tf_norm = (timeframe or "15m").strip().upper()
    smm_hierarchy_map = {
        "1M": {"tide": "30M", "wave": "5M", "ripple": "1M"},
        "2M": {"tide": "1H", "wave": "10M", "ripple": "2M"},
        "3M": {"tide": "1H", "wave": "15M", "ripple": "3M"},
        "5M": {"tide": "1H", "wave": "15M", "ripple": "5M"},
        "10M": {"tide": "2H", "wave": "30M", "ripple": "10M"},
        "15M": {"tide": "1D", "wave": "1H", "ripple": "15M"},
        "30M": {"tide": "1D", "wave": "2H", "ripple": "30M"},
        "1H": {"tide": "1W", "wave": "1D", "ripple": "1H"},
        "2H": {"tide": "1W", "wave": "1D", "ripple": "2H"},
        "4H": {"tide": "1M", "wave": "1W", "ripple": "4H"},
        "1D": {"tide": "1M", "wave": "1W", "ripple": "1D"},
    }

    base_hier = smm_hierarchy_map.get(tf_norm)
    if not base_hier:
        chain = get_smm_timeframe_chain(timeframe)
        if chain:
            base_hier = {
                "tide": chain.get("tide_timeframe") or chain.get("tide", "1D"),
                "wave": chain.get("wave_timeframe") or chain.get("wave", "1h"),
                "ripple": chain.get("ripple_timeframe") or chain.get("ripple", timeframe),
            }
        else:
            base_hier = {"tide": "1D", "wave": "1h", "ripple": timeframe}

    return {
        "tide": (custom_tide.strip() if custom_tide and str(custom_tide).strip() else base_hier["tide"]),
        "wave": (custom_wave.strip() if custom_wave and str(custom_wave).strip() else base_hier["wave"]),
        "ripple": base_hier["ripple"],
    }


def get_timeframe_minute_multiplier(timeframe: str) -> int:
    """Returns number of 1-minute bars per 1 bar of the given timeframe."""
    tf = (timeframe or "15m").strip().lower()
    if tf == "1m": return 1
    if tf == "2m": return 2
    if tf == "3m": return 3
    if tf == "5m": return 5
    if tf == "10m": return 10
    if tf == "15m": return 15
    if tf == "20m": return 20
    if tf == "30m": return 30
    if tf in ("1h", "60m"): return 60
    if tf == "2h": return 120
    if tf == "4h": return 240
    if tf in ("1d", "1day"): return 375
    return 15


# -----------------------------------------------------------------------------
# Terminal Formatting Colors & Glyphs
# -----------------------------------------------------------------------------
class Term:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    UNDERLINE = "\033[4m"

    # Foreground
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    GRAY = "\033[90m"


def color_status(status: str) -> str:
    s = (status or "").upper()
    if s == "VALID":
        return f"{Term.GREEN}{Term.BOLD}VALID{Term.RESET}"
    elif s in ("BLOCKED", "ERROR"):
        return f"{Term.RED}{Term.BOLD}{s}{Term.RESET}"
    elif s == "NOT_EVALUATED":
        return f"{Term.YELLOW}NOT_EVALUATED{Term.RESET}"
    elif s == "UNDEFINED":
        return f"{Term.GRAY}UNDEFINED{Term.RESET}"
    return f"{Term.WHITE}{s}{Term.RESET}"


def color_direction(direction: Optional[str]) -> str:
    d = (direction or "—").upper()
    if d == "LONG":
        return f"{Term.GREEN}{Term.BOLD}▲ LONG{Term.RESET}"
    elif d == "SHORT":
        return f"{Term.RED}{Term.BOLD}▼ SHORT{Term.RESET}"
    elif d == "NEUTRAL":
        return f"{Term.YELLOW}◆ NEUTRAL{Term.RESET}"
    return f"{Term.GRAY}— NONE{Term.RESET}"


def color_outcome(outcome: str) -> str:
    o = (outcome or "").upper()
    if o == "TARGET_FIRST":
        return f"{Term.GREEN}{Term.BOLD}★ TARGET FIRST{Term.RESET}"
    elif o == "SL_FIRST":
        return f"{Term.RED}{Term.BOLD}✗ STOP LOSS FIRST{Term.RESET}"
    elif o == "AMBIGUOUS":
        return f"{Term.YELLOW}{Term.BOLD}⚠ AMBIGUOUS (DUAL HIT){Term.RESET}"
    elif o == "UNRESOLVED":
        return f"{Term.CYAN}⏱ UNRESOLVED (WINDOW EXP){Term.RESET}"
    elif o == "BLOCKED":
        return f"{Term.RED}⛔ BLOCKED{Term.RESET}"
    return f"{Term.GRAY}{o}{Term.RESET}"


def color_confluence(conf_status: str, direction: Optional[str]) -> str:
    cs = (conf_status or "").upper()
    dir_str = f" ({direction})" if direction else ""
    if cs == "ALIGNED":
        return f"{Term.GREEN}{Term.BOLD}✓ ALIGNED{dir_str}{Term.RESET}"
    elif cs == "CONFLICTED":
        return f"{Term.RED}{Term.BOLD}⚡ CONFLICTED / DIVERGENT{Term.RESET}"
    elif cs == "INSUFFICIENT_EVIDENCE":
        return f"{Term.YELLOW}ℹ INSUFFICIENT EVIDENCE{Term.RESET}"
    return f"{Term.GRAY}{cs}{Term.RESET}"


# -----------------------------------------------------------------------------
# Database Access Helpers
# -----------------------------------------------------------------------------
def get_db_connection(db_path: str) -> sqlite3.Connection:
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database not found at: {db_path}")
    conn = sqlite3.connect(f"file:{os.path.abspath(db_path)}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def get_all_active_instruments(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    c = conn.cursor()
    c.execute(
        "SELECT id, symbol, display_name, exchange, fyers_symbol, active FROM instruments WHERE active = 1 ORDER BY symbol ASC"
    )
    rows = c.fetchall()
    return [dict(r) for r in rows]


def find_instrument(conn: sqlite3.Connection, symbol: str) -> Dict[str, Any]:
    sym_clean = symbol.strip().upper()
    c = conn.cursor()
    c.execute(
        "SELECT id, symbol, display_name, exchange, fyers_symbol, active FROM instruments WHERE UPPER(symbol) = ? OR UPPER(fyers_symbol) = ?",
        (sym_clean, sym_clean)
    )
    row = c.fetchone()
    if row:
        return dict(row)

    c.execute(
        "SELECT id, symbol, display_name, exchange, fyers_symbol, active FROM instruments WHERE UPPER(symbol) LIKE ? OR UPPER(fyers_symbol) LIKE ?",
        (f"%{sym_clean}%", f"%{sym_clean}%")
    )
    row = c.fetchone()
    if row:
        return dict(row)

    raise ValueError(f"Instrument '{symbol}' not found in database.")


IST_TZ = timezone(timedelta(hours=5, minutes=30), name="IST")


def format_ist_timestamp(dt: Any) -> str:
    """Formats a datetime as an IST string YYYY-MM-DD HH:MM:SS."""
    if not dt:
        return "—"
    if isinstance(dt, str):
        try:
            dt = parse_db_timestamp(dt)
        except Exception:
            return dt[:19].replace("T", " ")
    if isinstance(dt, datetime):
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        ist_dt = dt.astimezone(IST_TZ)
        return ist_dt.strftime("%Y-%m-%d %H:%M:%S")
    return str(dt)


def parse_db_timestamp(ts_raw: Any) -> datetime:
    """Robustly parses DB timestamps with or without microseconds/timezones."""
    if isinstance(ts_raw, datetime):
        return ensure_utc(ts_raw)
    ts_str = str(ts_raw).strip()
    if not ts_str:
        return utc_now()
    ts_iso = ts_str.replace(" ", "T")
    if ts_iso.endswith("Z"):
        ts_iso = ts_iso[:-1] + "+00:00"
    elif "+" not in ts_iso and "-" not in ts_iso[10:]:
        ts_iso = ts_iso + "+00:00"
    try:
        return ensure_utc(datetime.fromisoformat(ts_iso))
    except Exception:
        try:
            clean_ts = ts_str.split(".")[0].replace("T", " ")
            return ensure_utc(datetime.strptime(clean_ts, "%Y-%m-%d %H:%M:%S"))
        except Exception:
            return utc_now()


def fetch_replay_candles(
    conn: sqlite3.Connection,
    instrument_id: int,
    base_timeframe: str,
    eval_dt: datetime,
    lookback_count: int,
    future_count: int,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    c = conn.cursor()
    eval_ts_str = eval_dt.strftime("%Y-%m-%d %H:%M:%S")

    c.execute(
        """
        SELECT candle_timestamp, open, high, low, close, volume
        FROM market_candles
        WHERE instrument_id = ? AND timeframe = ? AND candle_timestamp <= ?
        ORDER BY candle_timestamp DESC
        LIMIT ?
        """,
        (instrument_id, base_timeframe, eval_ts_str, lookback_count)
    )
    ctx_rows = list(reversed(c.fetchall()))

    c.execute(
        """
        SELECT candle_timestamp, open, high, low, close, volume
        FROM market_candles
        WHERE instrument_id = ? AND timeframe = ? AND candle_timestamp > ?
        ORDER BY candle_timestamp ASC
        LIMIT ?
        """,
        (instrument_id, base_timeframe, eval_ts_str, future_count)
    )
    fut_rows = c.fetchall()

    def parse_candle(row: sqlite3.Row) -> Dict[str, Any]:
        dt_utc = parse_db_timestamp(row["candle_timestamp"])
        return {
            "candle_timestamp": dt_utc,
            "timestamp": dt_utc.isoformat(),
            "open": float(row["open"]),
            "high": float(row["high"]),
            "low": float(row["low"]),
            "close": float(row["close"]),
            "volume": float(row["volume"]) if row["volume"] is not None else 0.0,
        }

    ctx_candles = [parse_candle(r) for r in ctx_rows]
    fut_candles = [parse_candle(r) for r in fut_rows]
    return ctx_candles, fut_candles


def resolve_default_evaluation_timestamp(
    conn: sqlite3.Connection,
    instrument_id: int,
    base_timeframe: str,
    future_count: int,
) -> datetime:
    c = conn.cursor()
    c.execute(
        """
        SELECT candle_timestamp
        FROM market_candles
        WHERE instrument_id = ? AND timeframe = ?
        ORDER BY candle_timestamp DESC
        LIMIT ?
        """,
        (instrument_id, base_timeframe, future_count + 1)
    )
    rows = c.fetchall()
    if not rows or len(rows) <= future_count:
        raise ValueError(f"Insufficient {base_timeframe} candles in DB to evaluate future outcomes.")
    target_ts_raw = rows[-1]["candle_timestamp"]
    return parse_db_timestamp(target_ts_raw)


# -----------------------------------------------------------------------------
# Single Pair Evaluation
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# Sequential Multi-Candle Historical Strategy Scanner & Outcome Resolver
# -----------------------------------------------------------------------------
def scan_symbol_historical_trades(
    symbol: str,
    timeframe: str,
    strategies: List[str],
    start_date: Optional[str] = None,
    start_time: Optional[str] = None,
    end_date: Optional[str] = None,
    lookback_candles: Optional[int] = None,
    future_candles_count: int = 20,
    db_path: str = DEFAULT_DB_PATH,
    scenario_id: Optional[str] = None,
    custom_tide: Optional[str] = None,
    custom_wave: Optional[str] = None,
    cached_1m_candles: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """
    Scans sequential candles starting from StartDate to discover and evaluate ALL trades
    for the specified symbol and timeframe, returning full trade details and outcome matrix.
    """
    tf_clean = (timeframe or "15m").strip().lower()
    tf_hier = resolve_smm_timeframe_hierarchy(tf_clean, custom_tide=custom_tide, custom_wave=custom_wave)

    if scenario_id:
        s_id = scenario_id.strip().upper()
        if s_id not in PRESET_SCENARIOS:
            raise ValueError(f"Unknown preset scenario: {scenario_id}. Available: {list(PRESET_SCENARIOS.keys())}")
        scenario = PRESET_SCENARIOS[s_id]
        eval_dt = datetime(2026, 9, 1, 10, 0, tzinfo=timezone.utc)
        current_price = scenario.get("entry_price") or 100.0

        context_candles = [
            {"candle_timestamp": eval_dt - timedelta(minutes=30), "timestamp": "2026-09-01T09:30:00Z", "open": 98.0, "high": 99.5, "low": 97.5, "close": 99.0, "volume": 1000},
            {"candle_timestamp": eval_dt - timedelta(minutes=15), "timestamp": "2026-09-01T09:45:00Z", "open": 99.0, "high": 100.5, "low": 98.5, "close": 99.5, "volume": 1200},
            {"candle_timestamp": eval_dt, "timestamp": "2026-09-01T10:00:00Z", "open": 99.5, "high": 101.0, "low": 99.0, "close": current_price, "volume": 1500},
        ]
        future_candles = []
        for fc in scenario["future_candles"]:
            ts = datetime.fromisoformat(fc["timestamp"].replace("Z", "+00:00"))
            future_candles.append({
                "candle_timestamp": ts,
                "timestamp": fc["timestamp"],
                "open": fc["open"],
                "high": fc["high"],
                "low": fc["low"],
                "close": fc["close"],
                "volume": fc["volume"],
            })

        replay_engine = HistoricalReplayEngine(
            instrument="NSE:DEMO-EQ",
            symbol="DEMO",
            timeframe=timeframe or "15m",
            candles=context_candles + future_candles,
        )
        context = replay_engine.get_context_at(eval_dt)
        if context:
            context = context.model_copy(update={"extra_metadata": {"tide_timeframe": tf_hier["tide"], "wave_timeframe": tf_hier["wave"]}})
        
        registry = get_research_strategy_registry()
        runner = MultiStrategyResearchRunner(registry=registry)
        target_strat_ids = [s.strip().upper() for s in strategies]
        if not target_strat_ids or "ALL" in target_strat_ids:
            target_strat_ids = registry.list_strategies()

        eval_result = runner.evaluate(context, strategy_ids=target_strat_ids)
        resolver = get_level_resolver_for_strategy("SMM")
        evaluator = HistoricalOutcomeEvaluator(level_resolver=resolver)

        smm_res = next((s for s in eval_result.strategy_results if s.strategy_id == "SMM"), None)
        out_res = evaluator.evaluate(context=context, strategy_result=smm_res, future_candles=future_candles, level_resolver=resolver)

        ev = smm_res.evidence if (smm_res and isinstance(smm_res.evidence, dict)) else {}
        tide_res = ev.get("tide_result") if isinstance(ev.get("tide_result"), dict) else {}
        wave_res = ev.get("wave_result") if isinstance(ev.get("wave_result"), dict) else {}
        ripple_res = ev.get("ripple_result") if isinstance(ev.get("ripple_result"), dict) else {}

        entry_p = smm_res.entry_price or current_price
        sl_p = smm_res.stop_loss_price or 95.0
        tgt_p = smm_res.target_price or 115.0
        risk = round(abs(entry_p - sl_p), 2)
        rew = round(abs(tgt_p - entry_p), 2)
        rr = round(rew / risk, 2) if risk > 1e-4 else 3.0

        single_trade = {
            "symbol": "DEMO",
            "timeframe": tf_clean,
            "strategy_id": "SMM",
            "entry_date": format_ist_timestamp(eval_dt),
            "entry_timestamp_iso": eval_dt.isoformat(),
            "direction": smm_res.direction if smm_res else "LONG",
            "status": smm_res.status.value if smm_res else "VALID",
            "tide_screen": {"timeframe": tf_hier["tide"], "trend": tide_res.get("trend", "BULLISH"), "status": "SUPPORTED"},
            "wave_screen": {"timeframe": tf_hier["wave"], "bias": wave_res.get("wave_bias", "PULLBACK"), "status": "SUPPORTED"},
            "ripple_screen": {"timeframe": tf_hier["ripple"], "trigger": ripple_res.get("trigger_signal", "BREAKOUT"), "status": "SUPPORTED"},
            "entry_price": entry_p,
            "stop_loss_price": sl_p,
            "target_price": tgt_p,
            "risk_amount": risk,
            "reward_amount": rew,
            "risk_reward_ratio": rr,
            "outcome": out_res.outcome.value if hasattr(out_res.outcome, "value") else str(out_res.outcome),
            "candles_evaluated": out_res.candles_evaluated,
            "resolving_date": format_ist_timestamp(out_res.resolving_timestamp) if out_res.resolving_timestamp else None,
            "explanation": smm_res.explanation if smm_res else "",
        }

        return {
            "status": "SUCCESS",
            "symbol": "DEMO",
            "timeframe": tf_clean,
            "trades": [single_trade],
            "total_trades": 1,
            "target_hits": 1 if single_trade["outcome"] == "TARGET_FIRST" else 0,
            "sl_hits": 1 if single_trade["outcome"] == "SL_FIRST" else 0,
            "unresolved": 1 if single_trade["outcome"] == "UNRESOLVED" else 0,
            "ambiguous": 1 if single_trade["outcome"] == "AMBIGUOUS" else 0,
        }

    conn = get_db_connection(db_path)
    inst_info = find_instrument(conn, symbol)
    inst_id = inst_info["id"]
    inst_key = inst_info.get("fyers_symbol") or f"NSE:{inst_info['symbol']}-EQ"

    min_1m_lookback = get_minimum_smm_1m_lookback(tf_clean)
    warmup_count = max(min_1m_lookback, 1050 + (26 * 375))
    tf_mult = get_timeframe_minute_multiplier(tf_clean)
    effective_future_count = max(future_candles_count * tf_mult, future_candles_count)

    eff_start_date = start_date.strip() if (start_date and str(start_date).strip()) else "2017-07-03"
    eff_start_time = start_time.strip() if (start_time and str(start_time).strip()) else "09:30:00"
    if len(eff_start_time.split(":")) == 2:
        eff_start_time += ":00"
    if "+" in eff_start_time or "-" in eff_start_time:
        eval_start_dt = ensure_utc(datetime.fromisoformat(f"{eff_start_date}T{eff_start_time}"))
    else:
        eval_start_dt = datetime.fromisoformat(f"{eff_start_date}T{eff_start_time}+05:30").astimezone(timezone.utc)
    eval_start_ts_str = eval_start_dt.strftime("%Y-%m-%d %H:%M:%S")

    if end_date and str(end_date).strip():
        eff_end_date = str(end_date).strip()
        eval_end_dt = datetime.fromisoformat(f"{eff_end_date}T15:30:00+05:30").astimezone(timezone.utc)
    else:
        eval_end_dt = None

    if cached_1m_candles is not None and len(cached_1m_candles) > 0:
        all_1m_rows = cached_1m_candles
    else:
        c = conn.cursor()
        # Find warm-up window start
        c.execute(
            """
            SELECT candle_timestamp 
            FROM market_candles 
            WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp <= ?
            ORDER BY candle_timestamp DESC
            LIMIT 1 OFFSET ?
            """,
            (inst_id, eval_start_ts_str, warmup_count)
        )
        w_row = c.fetchone()
        if w_row:
            window_start_ts = w_row["candle_timestamp"]
        else:
            c.execute("SELECT MIN(candle_timestamp) as min_ts FROM market_candles WHERE instrument_id = ? AND timeframe = '1m'", (inst_id,))
            min_r = c.fetchone()
            window_start_ts = min_r["min_ts"] if min_r else "2017-07-03 00:00:00"

        # Query bounded candles
        if eval_end_dt:
            c.execute(
                """
                SELECT candle_timestamp 
                FROM market_candles 
                WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= ?
                ORDER BY candle_timestamp ASC
                LIMIT 1 OFFSET ?
                """,
                (inst_id, eval_end_dt.strftime("%Y-%m-%d %H:%M:%S"), effective_future_count)
            )
            e_row = c.fetchone()
            window_end_ts = e_row["candle_timestamp"] if e_row else eval_end_dt.strftime("%Y-%m-%d %H:%M:%S")

            c.execute(
                """
                SELECT candle_timestamp, open, high, low, close, volume
                FROM market_candles
                WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= ? AND candle_timestamp <= ?
                ORDER BY candle_timestamp ASC
                """,
                (inst_id, window_start_ts, window_end_ts)
            )
        else:
            c.execute(
                """
                SELECT candle_timestamp, open, high, low, close, volume
                FROM market_candles
                WHERE instrument_id = ? AND timeframe = '1m' AND candle_timestamp >= ?
                ORDER BY candle_timestamp ASC
                """,
                (inst_id, window_start_ts)
            )

        all_1m_rows = [dict(r) for r in c.fetchall()]
        conn.close()

    if not all_1m_rows:
        raise ValueError(f"No historical candle data found for {symbol} at or before {eval_start_ts_str}.")

    # Resample to execution timeframe
    resampled_exec = CandleResampler.resample_1m_candles(all_1m_rows, tf_clean)

    # Filter execution candidates >= eval_start_dt
    eval_candidates = []
    for idx, ec in enumerate(resampled_exec):
        ts = parse_db_timestamp(ec["candle_timestamp"])
        if ts >= eval_start_dt:
            if eval_end_dt and ts > eval_end_dt:
                continue
            eval_candidates.append((idx, ec, ts))

    registry = get_research_strategy_registry()
    runner = MultiStrategyResearchRunner(registry=registry)
    resolver = get_level_resolver_for_strategy("SMM")
    evaluator = HistoricalOutcomeEvaluator(level_resolver=resolver)

    raw_1m_ts = [parse_db_timestamp(r["candle_timestamp"]) for r in all_1m_rows]
    import bisect

    trades = []
    target_strat_ids = [s.strip().upper() for s in strategies]
    if not target_strat_ids or "ALL" in target_strat_ids:
        target_strat_ids = registry.list_strategies()

    cand_idx = 0
    while cand_idx < len(eval_candidates):
        idx, ec, ts = eval_candidates[cand_idx]
        pos = bisect.bisect_right(raw_1m_ts, ts)
        if pos < min(1000, min_1m_lookback):
            cand_idx += 1
            continue

        slice_start = max(0, pos - warmup_count)
        ctx_slice = all_1m_rows[slice_start : pos]
        future_slice = all_1m_rows[pos : pos + effective_future_count]

        context = StrategyInputContext(
            instrument=inst_key,
            symbol=inst_info["symbol"],
            timeframe=tf_clean,
            current_price=float(ec["close"]),
            evaluation_timestamp=ts,
            candles=ctx_slice,
            extra_metadata={"tide_timeframe": tf_hier["tide"], "wave_timeframe": tf_hier["wave"]}
        )

        eval_res = runner.evaluate(context, strategy_ids=target_strat_ids)
        smm_res = next((s for s in eval_res.strategy_results if s.strategy_id == "SMM"), None)

        if smm_res and smm_res.status == StrategyResultStatus.VALID:
            # Level Resolution
            ev = smm_res.evidence if isinstance(smm_res.evidence, dict) else {}
            tide_res = ev.get("tide_result") if isinstance(ev.get("tide_result"), dict) else {}
            wave_res = ev.get("wave_result") if isinstance(ev.get("wave_result"), dict) else {}
            ripple_res = ev.get("ripple_result") if isinstance(ev.get("ripple_result"), dict) else {}
            risk_st = ev.get("risk_status") if isinstance(ev.get("risk_status"), dict) else {}
            trade_lvls = risk_st.get("trade_levels") or risk_st.get("derived_trade_levels") or {}
            if not isinstance(trade_lvls, dict):
                trade_lvls = {}

            smm_dir = smm_res.direction
            if not smm_dir:
                raw_dir = tide_res.get("trend") or ev.get("smm_direction")
                if raw_dir and "BULLISH" in str(raw_dir).upper():
                    smm_dir = "LONG"
                elif raw_dir and "BEARISH" in str(raw_dir).upper():
                    smm_dir = "SHORT"
                else:
                    smm_dir = "NEUTRAL"

            curr_p = float(ec["close"])

            res_entry, res_sl, res_target = resolver(smm_res)
            final_entry = res_entry or trade_lvls.get("entry_price") or smm_res.entry_price
            final_sl = res_sl or trade_lvls.get("stop_loss_price") or smm_res.stop_loss_price
            final_target = res_target or trade_lvls.get("target_price") or smm_res.target_price

            if final_entry is None or final_sl is None or final_target is None:
                for rip_ev in ripple_res.get("evidence", []):
                    if isinstance(rip_ev, dict):
                        if rip_ev.get("trigger_price") and float(rip_ev["trigger_price"]) > 0:
                            final_entry = float(rip_ev["trigger_price"])
                        elif rip_ev.get("breakout_price") and float(rip_ev["breakout_price"]) > 0:
                            final_entry = float(rip_ev["breakout_price"])
                if final_entry is None and curr_p > 0:
                    final_entry = curr_p

                if smm_dir == "LONG" and final_entry:
                    recent_low = None
                    for rip_ev in ripple_res.get("evidence", []):
                        if isinstance(rip_ev, dict) and rip_ev.get("recent_low"):
                            recent_low = float(rip_ev["recent_low"])
                    if recent_low and recent_low < final_entry:
                        final_sl = round(recent_low, 2)
                    else:
                        final_sl = round(final_entry * 0.99, 2)
                    final_target = round(final_entry + (3.0 * (final_entry - final_sl)), 2)
                elif smm_dir == "SHORT" and final_entry:
                    recent_high = None
                    for rip_ev in ripple_res.get("evidence", []):
                        if isinstance(rip_ev, dict) and rip_ev.get("recent_high"):
                            recent_high = float(rip_ev["recent_high"])
                    if recent_high and recent_high > final_entry:
                        final_sl = round(recent_high, 2)
                    else:
                        final_sl = round(final_entry * 1.01, 2)
                    final_target = round(final_entry - (3.0 * (final_sl - final_entry)), 2)

            risk_amount = round(abs(final_entry - final_sl), 2) if (final_entry and final_sl) else None
            reward_amount = round(abs(final_target - final_entry), 2) if (final_entry and final_target) else None
            rr = round(reward_amount / risk_amount, 2) if (risk_amount and reward_amount and risk_amount > 1e-4) else 3.0

            # Historical Outcome Resolution
            outcome_res = evaluator.evaluate(
                context=context,
                strategy_result=smm_res,
                future_candles=future_slice,
                level_resolver=resolver,
            )

            out_val = outcome_res.outcome.value if hasattr(outcome_res.outcome, "value") else str(outcome_res.outcome)

            trade_record = {
                "symbol": inst_info["symbol"],
                "timeframe": tf_clean,
                "strategy_id": "SMM",
                "entry_date": format_ist_timestamp(ts),
                "entry_timestamp_iso": ts.isoformat(),
                "direction": smm_dir,
                "status": "VALID",
                "tide_screen": {
                    "timeframe": tf_hier["tide"],
                    "trend": tide_res.get("trend", "UNDEFINED"),
                    "status": tide_res.get("status", "NOT_EVALUATED"),
                },
                "wave_screen": {
                    "timeframe": tf_hier["wave"],
                    "bias": wave_res.get("wave_bias", "UNDEFINED"),
                    "status": wave_res.get("status", "NOT_EVALUATED"),
                },
                "ripple_screen": {
                    "timeframe": tf_hier["ripple"],
                    "trigger": ripple_res.get("trigger_signal", "NONE"),
                    "status": ripple_res.get("status", "NOT_EVALUATED"),
                },
                "entry_price": final_entry,
                "stop_loss_price": final_sl,
                "target_price": final_target,
                "risk_amount": risk_amount,
                "reward_amount": reward_amount,
                "risk_reward_ratio": rr,
                "outcome": out_val,
                "candles_evaluated": outcome_res.candles_evaluated,
                "resolving_date": format_ist_timestamp(outcome_res.resolving_timestamp) if outcome_res.resolving_timestamp else None,
                "explanation": smm_res.explanation,
            }
            trades.append(trade_record)

            # Advance past resolving candle if resolved
            if outcome_res.resolving_timestamp:
                res_ts = outcome_res.resolving_timestamp
                while cand_idx < len(eval_candidates) and eval_candidates[cand_idx][2] <= res_ts:
                    cand_idx += 1
            else:
                cand_idx += 1
        else:
            cand_idx += 1

    target_count = sum(1 for t in trades if t["outcome"] == "TARGET_FIRST")
    sl_count = sum(1 for t in trades if t["outcome"] == "SL_FIRST")
    unresolved_count = sum(1 for t in trades if t["outcome"] == "UNRESOLVED")
    ambiguous_count = sum(1 for t in trades if t["outcome"] == "AMBIGUOUS")

    return {
        "status": "SUCCESS",
        "instrument": inst_info,
        "symbol": inst_info.get("symbol", symbol),
        "timeframe": tf_clean,
        "scan_start_date": eff_start_date,
        "scan_end_date": end_date,
        "total_candles_scanned": len(eval_candidates),
        "trades_count": len(trades),
        "total_trades": len(trades),
        "target_hits": target_count,
        "sl_hits": sl_count,
        "unresolved": unresolved_count,
        "ambiguous": ambiguous_count,
        "trades": trades,
    }


def evaluate_single_pair(
    symbol: str,
    timeframe: str,
    strategies: List[str],
    start_date: Optional[str] = None,
    start_time: Optional[str] = None,
    end_date: Optional[str] = None,
    lookback_candles: Optional[int] = None,
    future_candles_count: int = 20,
    db_path: str = DEFAULT_DB_PATH,
    scenario_id: Optional[str] = None,
    custom_tide: Optional[str] = None,
    custom_wave: Optional[str] = None,
) -> Dict[str, Any]:
    """Evaluates a single instrument symbol and timeframe pair across historical candles."""
    return scan_symbol_historical_trades(
        symbol=symbol,
        timeframe=timeframe,
        strategies=strategies,
        start_date=start_date,
        start_time=start_time,
        end_date=end_date,
        lookback_candles=lookback_candles,
        future_candles_count=future_candles_count,
        db_path=db_path,
        scenario_id=scenario_id,
        custom_tide=custom_tide,
        custom_wave=custom_wave,
    )


# -----------------------------------------------------------------------------
# Multi-Pair / Universe Research Evaluator
# -----------------------------------------------------------------------------
def run_universe_research_evaluation(
    symbols: List[str],
    timeframes: List[str],
    strategies: List[str],
    start_date: Optional[str] = None,
    start_time: Optional[str] = None,
    end_date: Optional[str] = None,
    lookback_candles: Optional[int] = None,
    future_candles_count: int = 20,
    db_path: str = DEFAULT_DB_PATH,
    scenario_id: Optional[str] = None,
    custom_tide: Optional[str] = None,
    custom_wave: Optional[str] = None,
) -> Dict[str, Any]:
    """Runs research evaluation across all requested (symbol, timeframe) combinations."""
    conn = get_db_connection(db_path)
    
    # Resolve Symbols
    if "ALL" in [s.upper() for s in symbols]:
        active_insts = get_all_active_instruments(conn)
        target_symbols = [inst["symbol"] for inst in active_insts]
    else:
        target_symbols = symbols

    # Resolve Timeframes
    if "ALL" in [tf.upper() for tf in timeframes]:
        target_timeframes = ALL_RESEARCH_TIMEFRAMES
    else:
        target_timeframes = timeframes

    total_tasks = len(target_symbols) * len(target_timeframes)
    print(f"\n{Term.CYAN}Initializing Multi-Candle Research Scan for {len(target_symbols)} Symbol(s) x {len(target_timeframes)} Timeframe(s) = {total_tasks} Combinations...{Term.RESET}")

    symbol_results = []
    all_trades = []
    errors = []
    completed_count = 0

    for sym in target_symbols:
        for tf in target_timeframes:
            completed_count += 1
            print(f"  [{completed_count:03d}/{total_tasks:03d}] Scanning {Term.BOLD}{sym:<10}{Term.RESET} on {Term.CYAN}{tf.upper():<4}{Term.RESET}... ", end="", flush=True)
            try:
                res = scan_symbol_historical_trades(
                    symbol=sym,
                    timeframe=tf,
                    strategies=strategies,
                    start_date=start_date,
                    start_time=start_time,
                    end_date=end_date,
                    lookback_candles=lookback_candles,
                    future_candles_count=future_candles_count,
                    db_path=db_path,
                    scenario_id=scenario_id,
                    custom_tide=custom_tide,
                    custom_wave=custom_wave,
                )
                symbol_results.append(res)
                t_list = res.get("trades", [])
                all_trades.extend(t_list)

                tgt_cnt = res.get("target_hits", 0)
                sl_cnt = res.get("sl_hits", 0)
                tot_cnt = len(t_list)
                if tot_cnt > 0:
                    win_pct = round((tgt_cnt / tot_cnt) * 100.0, 1)
                    print(f"{Term.GREEN}✔ Found {tot_cnt} Trade(s){Term.RESET} ({tgt_cnt} Target, {sl_cnt} SL | Win Rate: {win_pct}%)")
                else:
                    print(f"{Term.GRAY}— 0 Setups in Period{Term.RESET}")
            except Exception as e:
                errors.append({"symbol": sym, "timeframe": tf, "error": str(e)})
                print(f"{Term.RED}✗ {e}{Term.RESET}")

    # Compute Aggregate Universe KPIs
    total_trades_count = len(all_trades)
    target_hit_count = sum(1 for t in all_trades if t.get("outcome") == "TARGET_FIRST")
    sl_hit_count = sum(1 for t in all_trades if t.get("outcome") == "SL_FIRST")
    ambiguous_count = sum(1 for t in all_trades if t.get("outcome") == "AMBIGUOUS")
    unresolved_count = sum(1 for t in all_trades if t.get("outcome") == "UNRESOLVED")
    long_count = sum(1 for t in all_trades if t.get("direction") == "LONG")
    short_count = sum(1 for t in all_trades if t.get("direction") == "SHORT")

    total_valid_resolved = target_hit_count + sl_hit_count + ambiguous_count + unresolved_count
    win_rate_pct = round((target_hit_count / max(total_valid_resolved, 1)) * 100.0, 1) if total_valid_resolved > 0 else 0.0

    summary = {
        "total_symbols_evaluated": len(target_symbols),
        "total_pairs_evaluated": len(symbol_results),
        "total_candles_scanned": sum(s.get("total_candles_scanned", 0) for s in symbol_results),
        "total_errors": len(errors),
        "valid_smm_setups": total_trades_count,
        "long_setups": long_count,
        "short_setups": short_count,
        "target_hit_count": target_hit_count,
        "sl_hit_count": sl_hit_count,
        "ambiguous_count": ambiguous_count,
        "unresolved_count": unresolved_count,
        "win_rate_pct": win_rate_pct,
    }

    return {
        "status": "SUCCESS",
        "is_universe": True,
        "summary": summary,
        "symbols": target_symbols,
        "timeframes": target_timeframes,
        "strategies": strategies,
        "evaluations": symbol_results,
        "all_trades": all_trades,
        "errors": errors,
    }


# -----------------------------------------------------------------------------
# Terminal Reporting
# -----------------------------------------------------------------------------
def print_terminal_universe_report(payload: Dict[str, Any]) -> None:
    all_trades = payload.get("all_trades")
    if all_trades is None:
        # Fallback if single pair
        evals = payload.get("evaluations", [])
        all_trades = []
        for e in evals:
            all_trades.extend(e.get("trades", []))

    summary = payload.get("summary") or {}
    
    print("\n" + "=" * 165)
    print(f"{Term.BOLD}{Term.CYAN} SMM TRADING PLATFORM — MULTI-CANDLE HISTORICAL RESEARCH & OUTCOME MATRIX{Term.RESET}")
    print("=" * 165)
    print(f"  {Term.BOLD}Symbols Evaluated:{Term.RESET} {summary.get('total_symbols_evaluated', 1)}  |  "
          f"{Term.BOLD}Total Candles Scanned:{Term.RESET} {summary.get('total_candles_scanned', 0)}  |  "
          f"{Term.BOLD}Total Valid Trades Discovered:{Term.RESET} {summary.get('valid_smm_setups', len(all_trades))} (Long: {summary.get('long_setups', 0)}, Short: {summary.get('short_setups', 0)})  |  "
          f"{Term.BOLD}Target Hits:{Term.RESET} {summary.get('target_hit_count', 0)} ({summary.get('win_rate_pct', 0)}%)  |  "
          f"{Term.BOLD}SL Hits:{Term.RESET} {summary.get('sl_hit_count', 0)}")
    print("-" * 165)

    if not all_trades:
        print(f" {Term.YELLOW}No valid trade setups triggered across the scanned candles in the selected period.{Term.RESET}")
        print("=" * 165 + "\n")
        return

    print(f" {'SYMBOL':<9} | {'TF':<5} | {'ENTRY DATE & TIME':<19} | {'DIR':<6} | {'TIDE':<11} | {'WAVE':<13} | {'RIPPLE':<15} | {'ENTRY':<9} | {'STOP LOSS':<9} | {'TARGET':<9} | {'RISK':<7} | {'REWARD':<8} | {'R:R':<6} | {'HISTORICAL OUTCOME':<22} | {'RESOLVING DATE':<19}")
    print("-" * 180)

    for t in all_trades:
        sym = t.get("symbol", "N/A")
        tf_val = (t.get("timeframe") or "15m").upper()
        entry_dt_str = t.get("entry_date") or "—"
        res_dt_str = t.get("resolving_date") or "—"
        
        dir_str = t.get("direction", "—")
        dir_disp = f"{Term.GREEN}▲ LONG{Term.RESET}" if dir_str == "LONG" else (f"{Term.RED}▼ SHORT{Term.RESET}" if dir_str == "SHORT" else dir_str)

        tide_s = t.get("tide_screen", {})
        wave_s = t.get("wave_screen", {})
        rip_s = t.get("ripple_screen", {})

        tide_disp = "▲ BULLISH" if "BULLISH" in str(tide_s.get("trend")) else ("▼ BEARISH" if "BEARISH" in str(tide_s.get("trend")) else "—")
        wave_disp = "▲ PULLBACK" if "PULLBACK" in str(wave_s.get("bias")) else ("▼ RALLY" if "RALLY" in str(wave_s.get("bias")) else "⏳ WAITING")
        rip_disp = "⚡ BREAKOUT" if "BREAKOUT" in str(rip_s.get("trigger")) else ("⚡ BREAKDOWN" if "BREAKDOWN" in str(rip_s.get("trigger")) else "⏳ AWAITING")

        entry = f"{t['entry_price']:.2f}" if t.get("entry_price") is not None else "—"
        sl = f"{t['stop_loss_price']:.2f}" if t.get("stop_loss_price") is not None else "—"
        target = f"{t['target_price']:.2f}" if t.get("target_price") is not None else "—"
        risk_s = f"{t['risk_amount']:.2f}" if t.get("risk_amount") is not None else "—"
        rew_s = f"{t['reward_amount']:.2f}" if t.get("reward_amount") is not None else "—"
        rr = f"1:{t['risk_reward_ratio']}" if t.get("risk_reward_ratio") is not None else "—"
        outcome_str = color_outcome(t.get("outcome", "NOT_EVALUATED"))

        print(f" {Term.BOLD}{sym:<9}{Term.RESET} | {Term.CYAN}{tf_val:<5}{Term.RESET} | {entry_dt_str:<19} | {dir_disp:<15} | {tide_disp:<11} | {wave_disp:<13} | {rip_disp:<15} | {entry:<9} | {sl:<9} | {target:<9} | {risk_s:<7} | {rew_s:<8} | {rr:<6} | {outcome_str:<32} | {res_dt_str:<19}")

    print("=" * 180 + "\n")


# -----------------------------------------------------------------------------
# Comprehensive HTML Dashboard Generator (Single + Universe Mode)
# -----------------------------------------------------------------------------
def generate_html_research_report(payload: Dict[str, Any], output_path: str) -> str:
    all_trades = payload.get("all_trades")
    symbol_evals = payload.get("evaluations", [])
    if all_trades is None:
        all_trades = []
        for e in symbol_evals:
            all_trades.extend(e.get("trades", []))

    summary = payload.get("summary") or {}
    total_trades = len(all_trades)
    target_hit = summary.get("target_hit_count", sum(1 for t in all_trades if t.get("outcome") == "TARGET_FIRST"))
    sl_hit = summary.get("sl_hit_count", sum(1 for t in all_trades if t.get("outcome") == "SL_FIRST"))
    unresolved_hit = summary.get("unresolved_count", sum(1 for t in all_trades if t.get("outcome") == "UNRESOLVED"))
    ambiguous_hit = summary.get("ambiguous_count", sum(1 for t in all_trades if t.get("outcome") == "AMBIGUOUS"))
    
    tot_resolved = target_hit + sl_hit + unresolved_hit + ambiguous_hit
    win_rate = summary.get("win_rate_pct", round((target_hit / max(tot_resolved, 1)) * 100.0, 1) if tot_resolved > 0 else 0.0)
    
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    payload_json_str = json.dumps(payload, default=str)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SMM Trading Platform — Historical Strategy Research &amp; Outcome Report</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {{
      --bg-dark: #090d16;
      --bg-card: rgba(18, 24, 38, 0.85);
      --bg-card-hover: rgba(28, 36, 56, 0.95);
      --border-color: rgba(255, 255, 255, 0.08);
      --border-focus: #3b82f6;
      --primary: #3b82f6;
      --primary-glow: rgba(59, 130, 246, 0.25);
      --accent-cyan: #06b6d4;
      --accent-emerald: #10b981;
      --accent-emerald-glow: rgba(16, 185, 129, 0.2);
      --accent-amber: #f59e0b;
      --accent-rose: #f43f5e;
      --accent-purple: #a855f7;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --text-dim: #64748b;
      --font-sans: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      --font-mono: 'JetBrains Mono', Consolas, Monaco, monospace;
    }}

    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{
      background-color: var(--bg-dark);
      background-image: radial-gradient(circle at 15% 15%, rgba(59, 130, 246, 0.07) 0%, transparent 40%),
                        radial-gradient(circle at 85% 85%, rgba(16, 185, 129, 0.05) 0%, transparent 40%);
      color: var(--text-main);
      font-family: var(--font-sans);
      min-height: 100vh;
      padding: 24px;
      line-height: 1.5;
    }}
    .container {{ max-width: 1720px; margin: 0 auto; }}

    /* Header */
    header {{
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
      padding: 20px 28px;
      background: var(--bg-card);
      backdrop-filter: blur(16px);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      margin-bottom: 24px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }}
    .brand-title {{ display: flex; align-items: center; gap: 14px; }}
    .brand-logo {{
      width: 46px; height: 46px;
      background: linear-gradient(135deg, #2563eb, #06b6d4);
      border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; font-weight: 800; color: #fff;
      box-shadow: 0 0 20px var(--primary-glow);
    }}
    .brand-info h1 {{
      font-size: 22px; font-weight: 800; letter-spacing: -0.02em;
      background: linear-gradient(to right, #ffffff, #94a3b8);
      -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    }}
    .brand-info p {{ font-size: 13px; color: var(--text-muted); font-family: var(--font-mono); }}

    .header-actions {{ display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }}
    .badge {{
      display: inline-flex; align-items: center; gap: 6px;
      padding: 6px 12px; border-radius: 8px; font-size: 12px; font-weight: 600;
      font-family: var(--font-mono); background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border-color);
    }}
    .badge-live {{ background: rgba(16, 185, 129, 0.15); border-color: rgba(16, 185, 129, 0.4); color: #34d399; }}
    .pulse-dot {{
      width: 8px; height: 8px; background-color: #10b981; border-radius: 50%;
      box-shadow: 0 0 8px #10b981; animation: pulse 2s infinite;
    }}
    @keyframes pulse {{ 0%, 100% {{ opacity: 1; transform: scale(1); }} 50% {{ opacity: 0.5; transform: scale(0.85); }} }}

    .btn {{
      display: inline-flex; align-items: center; gap: 8px; padding: 8px 16px;
      background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border-color);
      border-radius: 8px; color: var(--text-main); font-size: 13px; font-weight: 600;
      cursor: pointer; text-decoration: none; transition: all 0.2s;
    }}
    .btn:hover {{ background: rgba(255, 255, 255, 0.1); border-color: rgba(255, 255, 255, 0.2); transform: translateY(-1px); }}
    .btn-primary {{ background: linear-gradient(135deg, #2563eb, #1d4ed8); border-color: #3b82f6; color: #fff; box-shadow: 0 0 15px var(--primary-glow); }}

    /* KPI Grid */
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }}
    .kpi-card {{
      background: var(--bg-card);
      backdrop-filter: blur(12px);
      border: 1px solid var(--border-color);
      border-radius: 14px;
      padding: 18px 20px;
      position: relative;
      overflow: hidden;
      transition: transform 0.2s;
    }}
    .kpi-card:hover {{ transform: translateY(-2px); }}
    .kpi-card::before {{ content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; }}
    .kpi-blue::before {{ background: linear-gradient(to right, #2563eb, #06b6d4); }}
    .kpi-green::before {{ background: linear-gradient(to right, #10b981, #059669); }}
    .kpi-purple::before {{ background: linear-gradient(to right, #a855f7, #7c3aed); }}
    .kpi-amber::before {{ background: linear-gradient(to right, #f59e0b, #d97706); }}

    .kpi-label {{ font-size: 11px; font-weight: 700; text-transform: uppercase; color: var(--text-muted); }}
    .kpi-value {{ font-size: 24px; font-weight: 800; font-family: var(--font-mono); margin: 4px 0; }}
    .kpi-subtext {{ font-size: 12px; color: var(--text-dim); font-family: var(--font-mono); }}

    /* Controls */
    .controls-panel {{
      display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;
      margin-bottom: 20px; padding: 16px 20px; background: var(--bg-card);
      border: 1px solid var(--border-color); border-radius: 14px;
    }}
    .tabs-nav {{ display: flex; gap: 8px; flex-wrap: wrap; }}
    .tab-btn {{
      padding: 8px 16px; background: rgba(255, 255, 255, 0.04); border: 1px solid var(--border-color);
      border-radius: 8px; color: var(--text-muted); font-size: 13px; font-weight: 600; cursor: pointer;
    }}
    .tab-btn.active {{ background: var(--primary); border-color: var(--primary); color: #fff; box-shadow: 0 0 12px var(--primary-glow); }}
    .search-input {{
      padding: 8px 14px 8px 36px; background: rgba(0, 0, 0, 0.3); border: 1px solid var(--border-color);
      border-radius: 8px; color: #fff; font-size: 13px; font-family: var(--font-mono); outline: none; width: 280px;
    }}

    /* Table */
    .section-box {{
      background: var(--bg-card); backdrop-filter: blur(12px); border: 1px solid var(--border-color);
      border-radius: 16px; padding: 24px; margin-bottom: 24px;
    }}
    .table-responsive {{ width: 100%; overflow-x: auto; border-radius: 10px; border: 1px solid var(--border-color); }}
    table.data-table {{ width: 100%; border-collapse: collapse; font-size: 12px; text-align: left; }}
    table.data-table th {{
      background: rgba(0, 0, 0, 0.4); color: var(--text-muted); padding: 10px 12px; font-weight: 700;
      font-size: 11px; text-transform: uppercase; border-bottom: 1px solid var(--border-color); white-space: nowrap;
    }}
    table.data-table td {{ padding: 10px 12px; border-bottom: 1px solid rgba(255, 255, 255, 0.04); font-family: var(--font-mono); white-space: nowrap; }}
    table.data-table tr:hover td {{ background: rgba(255, 255, 255, 0.03); }}

    /* Badges */
    .pill-long {{ background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #34d399; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }}
    .pill-short {{ background: rgba(244, 63, 94, 0.15); border: 1px solid rgba(244, 63, 94, 0.4); color: #fb7185; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }}
    .pill-neutral {{ background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.4); color: #fbbf24; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 700; }}
    .pill-target {{ background: rgba(16, 185, 129, 0.2); border: 1px solid #10b981; color: #34d399; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 11px; }}
    .pill-sl {{ background: rgba(244, 63, 94, 0.2); border: 1px solid #f43f5e; color: #fb7185; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 11px; }}
    .pill-unresolved {{ background: rgba(6, 182, 212, 0.2); border: 1px solid #06b6d4; color: #38bdf8; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 11px; }}

    .code-viewer {{
      background: rgba(0, 0, 0, 0.5); border: 1px solid var(--border-color); border-radius: 8px;
      padding: 12px; font-family: var(--font-mono); font-size: 11px; color: #93c5fd; max-height: 480px; overflow-y: auto;
    }}
    .toast {{
      position: fixed; bottom: 24px; right: 24px; background: #1e293b; border: 1px solid var(--primary);
      color: #fff; padding: 12px 20px; border-radius: 10px; font-size: 13px; font-weight: 600; display: none; z-index: 1000;
    }}
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="brand-title">
        <div class="brand-logo">SMM</div>
        <div class="brand-info">
          <h1>Historical Strategy Research &amp; Outcome Report</h1>
          <p>Multi-Instrument &amp; Multi-Candle Strategy Resolution Matrix</p>
        </div>
      </div>
      <div class="header-actions">
        <div class="badge badge-live">
          <span class="pulse-dot"></span>
          <span>{total_trades} TRADES DISCOVERED</span>
        </div>
        <button class="btn" onclick="copyCliCommand()">📋 Copy Command</button>
        <button class="btn" onclick="copyJsonPayload()">💾 Copy JSON</button>
        <button class="btn btn-primary" onclick="window.print()">🖨 Print / PDF</button>
      </div>
    </header>

    <!-- KPI Grid -->
    <div class="kpi-grid">
      <div class="kpi-card kpi-blue">
        <div class="kpi-label">Universe Scanned</div>
        <div class="kpi-value">{summary.get('total_symbols_evaluated', len(symbol_evals))} Symbols</div>
        <div class="kpi-subtext">{summary.get('total_candles_scanned', 0)} Candles Evaluated</div>
      </div>

      <div class="kpi-card kpi-green">
        <div class="kpi-label">Discovered SMM Setups</div>
        <div class="kpi-value" style="color: #34d399;">{total_trades}</div>
        <div class="kpi-subtext">{summary.get('long_setups', 0)} Long • {summary.get('short_setups', 0)} Short</div>
      </div>

      <div class="kpi-card kpi-purple">
        <div class="kpi-label">Target Hit Rate (Win Rate)</div>
        <div class="kpi-value" style="color: #c084fc;">{win_rate}%</div>
        <div class="kpi-subtext">{target_hit} Targets • {sl_hit} Stop Losses</div>
      </div>

      <div class="kpi-card kpi-amber">
        <div class="kpi-label">Unresolved / In-Flight</div>
        <div class="kpi-value" style="color: #fbbf24;">{unresolved_hit}</div>
        <div class="kpi-subtext">{ambiguous_hit} Ambiguous Hits</div>
      </div>
    </div>

    <!-- Controls -->
    <div class="controls-panel">
      <div class="tabs-nav">
        <button class="tab-btn active" onclick="switchSection('section-trades')">📊 All Discovered Trades ({total_trades})</button>
        <button class="tab-btn" onclick="switchSection('section-summary')">📈 Symbol Summary Matrix ({len(symbol_evals)})</button>
        <button class="tab-btn" onclick="switchSection('section-json')">💾 Raw JSON Payload</button>
      </div>
      <div style="position: relative;">
        <span style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-dim);">🔍</span>
        <input type="text" id="filter-input" class="search-input" placeholder="Filter symbol, timeframe, bias, outcome, date..." onkeyup="filterTable()">
      </div>
    </div>

    <!-- Trades Section -->
    <div id="section-trades" class="section-box">
      <div class="table-responsive">
        <table class="data-table" id="matrix-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Symbol</th>
              <th>Timeframe</th>
              <th>Entry Date &amp; Time (IST)</th>
              <th>Direction</th>
              <th>TIDE (Screen 1)</th>
              <th>WAVE (Screen 2)</th>
              <th>RIPPLE (Screen 3)</th>
              <th>Entry Price</th>
              <th>Stop Loss</th>
              <th>Target Price</th>
              <th>Risk (₹)</th>
              <th>Reward (₹)</th>
              <th>R:R</th>
              <th>Outcome</th>
              <th>Exit Date &amp; Time (IST)</th>
            </tr>
          </thead>
          <tbody>
"""

    for idx, t in enumerate(all_trades, 1):
        sym = t.get("symbol") or "N/A"
        tf_val = (t.get("timeframe") or "15m").upper()
        entry_dt_str = t.get("entry_date") or "—"
        res_dt_str = t.get("resolving_date") or "—"
        dir_val = t.get("direction", "LONG")

        dir_badge = f'<span class="pill-long">▲ LONG</span>' if dir_val == "LONG" else (
            f'<span class="pill-short">▼ SHORT</span>' if dir_val == "SHORT" else f'<span class="pill-neutral">{dir_val}</span>'
        )

        tide_s = t.get("tide_screen", {})
        wave_s = t.get("wave_screen", {})
        rip_s = t.get("ripple_screen", {})

        tide_trend = str(tide_s.get("trend") or "")
        wave_bias = str(wave_s.get("bias") or "")
        rip_trig = str(rip_s.get("trigger") or "")

        tide_tf = tide_s.get("timeframe", "1D")
        wave_tf = wave_s.get("timeframe", "1h")
        rip_tf = rip_s.get("timeframe", tf_val)

        tide_badge = f'<span class="pill-long">▲ BULLISH ({tide_tf})</span>' if "BULLISH" in tide_trend else (
            f'<span class="pill-short">▼ BEARISH ({tide_tf})</span>' if "BEARISH" in tide_trend else '<span style="color:var(--text-muted)">—</span>'
        )
        wave_badge = f'<span class="pill-long">▲ PULLBACK ({wave_tf})</span>' if "PULLBACK" in wave_bias else (
            f'<span class="pill-short">▼ RALLY ({wave_tf})</span>' if "RALLY" in wave_bias else f'<span class="badge">⏳ WAITING ({wave_tf})</span>'
        )
        rip_badge = f'<span class="pill-long" style="box-shadow: 0 0 8px rgba(16,185,129,0.3)">⚡ BREAKOUT ({rip_tf})</span>' if "BREAKOUT" in rip_trig else (
            f'<span class="pill-short" style="box-shadow: 0 0 8px rgba(244,63,94,0.3)">⚡ BREAKDOWN ({rip_tf})</span>' if "BREAKDOWN" in rip_trig else f'<span class="badge">⏳ AWAITING ({rip_tf})</span>'
        )

        out_val = t.get("outcome", "NOT_EVALUATED")
        out_badge = (
            f'<span class="pill-target">★ TARGET FIRST</span>' if out_val == "TARGET_FIRST" else (
                f'<span class="pill-sl">✗ STOP LOSS FIRST</span>' if out_val == "SL_FIRST" else (
                    f'<span class="pill-unresolved">⏱ UNRESOLVED</span>' if out_val == "UNRESOLVED" else f'<span class="badge">{out_val}</span>'
                )
            )
        )

        entry_s = f"₹{t['entry_price']:.2f}" if t.get("entry_price") is not None else "—"
        sl_s = f"₹{t['stop_loss_price']:.2f}" if t.get("stop_loss_price") is not None else "—"
        target_s = f"₹{t['target_price']:.2f}" if t.get("target_price") is not None else "—"
        risk_s = f"₹{t['risk_amount']:.2f}" if t.get("risk_amount") is not None else "—"
        rew_s = f"₹{t['reward_amount']:.2f}" if t.get("reward_amount") is not None else "—"
        rr_s = f"1:{t['risk_reward_ratio']}" if t.get("risk_reward_ratio") is not None else "—"

        html += f"""            <tr>
              <td style="color: var(--text-dim);">{idx:03d}</td>
              <td><strong style="color: #60a5fa; font-size: 13px;">{sym}</strong></td>
              <td><span class="badge" style="background: rgba(59, 130, 246, 0.15); color: #93c5fd;">{tf_val}</span></td>
              <td style="color: #fff; font-weight: 600;">{entry_dt_str}</td>
              <td>{dir_badge}</td>
              <td>{tide_badge}</td>
              <td>{wave_badge}</td>
              <td>{rip_badge}</td>
              <td style="font-weight: 700; color: #fff;">{entry_s}</td>
              <td style="color: #fb7185; font-weight: 600;">{sl_s}</td>
              <td style="color: #34d399; font-weight: 600;">{target_s}</td>
              <td style="color: #fb7185;">{risk_s}</td>
              <td style="color: #34d399;">{rew_s}</td>
              <td style="color: #38bdf8; font-weight: 700;">{rr_s}</td>
              <td>{out_badge}</td>
              <td style="color: var(--text-muted); font-size: 11px;">{res_dt_str}</td>
            </tr>
"""

    html += f"""          </tbody>
        </table>
      </div>
    </div>

    <!-- Summary Section -->
    <div id="section-summary" class="section-box" style="display: none;">
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Symbol</th>
              <th>Timeframe</th>
              <th>Candles Scanned</th>
              <th>Trades Discovered</th>
              <th>Target Hits</th>
              <th>SL Hits</th>
              <th>Unresolved</th>
              <th>Win Rate %</th>
            </tr>
          </thead>
          <tbody>
"""

    for s_eval in symbol_evals:
        sym = s_eval.get("symbol", "—")
        tf_val = (s_eval.get("timeframe") or "15m").upper()
        scanned = s_eval.get("total_candles_scanned", 0)
        t_cnt = s_eval.get("trades_count", len(s_eval.get("trades", [])))
        tgt_cnt = s_eval.get("target_hits", 0)
        sl_cnt = s_eval.get("sl_hits", 0)
        unres_cnt = s_eval.get("unresolved", 0)
        tot_res = tgt_cnt + sl_cnt
        sym_win = round((tgt_cnt / max(tot_res, 1)) * 100.0, 1) if tot_res > 0 else 0.0

        html += f"""            <tr>
              <td><strong style="color: #60a5fa;">{sym}</strong></td>
              <td><span class="badge">{tf_val}</span></td>
              <td>{scanned}</td>
              <td><strong>{t_cnt}</strong></td>
              <td style="color: #34d399; font-weight: 700;">{tgt_cnt}</td>
              <td style="color: #fb7185; font-weight: 700;">{sl_cnt}</td>
              <td style="color: #38bdf8;">{unres_cnt}</td>
              <td style="font-weight: 800; color: {'#34d399' if sym_win >= 50 else '#fbbf24'};">{sym_win}%</td>
            </tr>
"""

    html += f"""          </tbody>
        </table>
      </div>
    </div>

    <!-- JSON Section -->
    <div id="section-json" class="section-box" style="display: none;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
        <h2 style="font-size: 16px; font-weight: 700;">💾 Raw Evaluation JSON Payload</h2>
        <button class="btn" onclick="copyJsonPayload()">Copy JSON</button>
      </div>
      <div class="code-viewer">{payload_json_str}</div>
    </div>
  </div>

  <div id="toast" class="toast">Copied to clipboard!</div>

  <script>
    const RAW_PAYLOAD = {payload_json_str};

    function switchSection(id) {{
      document.querySelectorAll('.section-box').forEach(s => s.style.display = 'none');
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      const target = document.getElementById(id);
      if (target) target.style.display = 'block';
      event.target.classList.add('active');
    }}

    function filterTable() {{
      const query = document.getElementById('filter-input').value.toUpperCase();
      const rows = document.querySelectorAll('#matrix-table tbody tr');
      rows.forEach(r => {{
        const text = r.innerText.toUpperCase();
        r.style.display = text.includes(query) ? '' : 'none';
      }});
    }}

    function copyToClipboard(text, successMsg) {{
      if (navigator.clipboard && window.isSecureContext) {{
        navigator.clipboard.writeText(text).then(() => showToast(successMsg)).catch(() => fallbackCopy(text, successMsg));
      }} else {{
        fallbackCopy(text, successMsg);
      }}
    }}

    function fallbackCopy(text, successMsg) {{
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      try {{
        document.execCommand('copy');
        showToast(successMsg);
      }} catch (err) {{
        alert('Failed to copy: ' + err);
      }}
      document.body.removeChild(ta);
    }}

    function copyCliCommand() {{
      const cmd = "research_strategy.bat -Symbol ALL -Timeframe 15m";
      copyToClipboard(cmd, 'CLI Command copied to clipboard!');
    }}

    function copyJsonPayload() {{
      copyToClipboard(JSON.stringify(RAW_PAYLOAD, null, 2), 'JSON payload copied to clipboard!');
    }}

    function showToast(msg) {{
      const toast = document.getElementById('toast');
      toast.innerText = msg;
      toast.style.display = 'block';
      setTimeout(() => {{ toast.style.display = 'none'; }}, 2500);
    }}
  </script>
</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    latest_path = os.path.join(REPORTS_DIR, "latest_research_report.html")
    with open(latest_path, "w", encoding="utf-8") as f:
        f.write(html)

    return output_path


# -----------------------------------------------------------------------------
# Main CLI Entry Point
# -----------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="SMM Trading Platform — Multi-Strategy Historical Outcome Resolution CLI"
    )
    parser.add_argument("--symbols", "--symbol", "-symbols", "-symbol", "-s", default="INFY", help="Instrument symbol, list of symbols, or ALL (e.g. INFY or ALL or INFY,TCS)")
    parser.add_argument("--timeframes", "--timeframe", "-timeframes", "-timeframe", "-t", default="15m", help="Candle timeframe, list of timeframes, or ALL (e.g. 15m or ALL or 1m,15m,1h)")
    parser.add_argument("--strategies", "--strategy", "-strategies", "-strategy", default="ALL", help="Comma-separated strategy IDs (Default: ALL. SMM implemented; PAPA, FOME, GUE, SMC on roadmap)")
    parser.add_argument("--start-date", "--start_date", "-startdate", "-start_date", "-sd", default="2017-07-03", help="Evaluation start date (YYYY-MM-DD, Default: 2017-07-03)")
    parser.add_argument("--end-date", "--end_date", "-enddate", "-end_date", "-ed", default=None, help="Evaluation end date (YYYY-MM-DD)")
    parser.add_argument("--start-time", "--start_time", "-starttime", "-start_time", "-st", default="09:30", help="Evaluation start time in IST (HH:MM or HH:MM:SS, Default: 09:30)")
    parser.add_argument("--lookback", "-lookback", "-l", type=int, default=50, help="Lookback candles count (<= T)")
    parser.add_argument("--future-count", "--future_count", "-futurecount", "-future_count", "-f", type=int, default=20, help="Subsequent future candles count (> T)")
    parser.add_argument("--db-path", "--db_path", "-dbpath", "-db_path", default=DEFAULT_DB_PATH, help="Path to SQLite database smm_trading.db")
    parser.add_argument("--export-html", "--export_html", "-exporthtml", nargs="?", const="", default=None, help="Generate interactive HTML report (optional path)")
    parser.add_argument("--no-html", "--no_html", "-nohtml", action="store_true", help="Disable HTML report generation")
    parser.add_argument("--open", "-open", action="store_true", help="Automatically open HTML report in default browser")
    parser.add_argument("--export-json", "--export_json", "-exportjson", nargs="?", const="", default=None, help="Export raw evaluation JSON payload")
    parser.add_argument("--tide", "--tide-timeframe", "--tide_timeframe", "-tide", "-Tide", default=None, help="Custom SMM TIDE higher timeframe override (e.g. 1D, 1h, 30m, 1W)")
    parser.add_argument("--wave", "--wave-timeframe", "--wave_timeframe", "-wave", "-Wave", default=None, help="Custom SMM WAVE intermediate timeframe override (e.g. 1h, 15m, 10m, 5m)")
    parser.add_argument("--preset", "-preset", default=None, help="Run preset verification scenario (e.g. TARGET_FIRST, SL_FIRST, AMBIGUOUS)")

    args = parser.parse_args()

    # Parse Strategies
    strat_list = [s.strip().upper() for s in args.strategies.split(",") if s.strip()]
    if not strat_list or "ALL" in strat_list:
        strat_list = ALL_KNOWN_STRATEGIES

    # Parse Symbols
    sym_input = args.symbols.strip()
    if sym_input.upper() == "ALL":
        symbols_list = ["ALL"]
    else:
        symbols_list = [s.strip().upper() for s in sym_input.split(",") if s.strip()]

    # Parse Timeframes
    tf_input = args.timeframes.strip()
    if tf_input.upper() == "ALL":
        timeframes_list = ["ALL"]
    else:
        timeframes_list = [t.strip().lower() for t in tf_input.split(",") if t.strip()]

    try:
        # Multi-Pair / Multi-Candle Research Evaluation
        payload = run_universe_research_evaluation(
            symbols=symbols_list,
            timeframes=timeframes_list,
            strategies=strat_list,
            start_date=args.start_date,
            start_time=args.start_time,
            end_date=args.end_date,
            lookback_candles=args.lookback,
            future_candles_count=args.future_count,
            db_path=args.db_path,
            scenario_id=args.preset,
            custom_tide=args.tide,
            custom_wave=args.wave,
        )
        # Terminal Table
        print_terminal_universe_report(payload)

        # Generate HTML Report
        if not args.no_html:
            os.makedirs(REPORTS_DIR, exist_ok=True)
            ts_suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
            sym_tag = "ALL" if "ALL" in symbols_list else "_".join(symbols_list[:3])
            tf_tag = "ALL" if "ALL" in timeframes_list else "_".join(timeframes_list[:3])
            
            if args.export_html and args.export_html.strip():
                html_file = args.export_html.strip()
            else:
                html_file = os.path.join(REPORTS_DIR, f"research_strategy_{sym_tag}_{tf_tag}_{ts_suffix}.html")

            saved_html = generate_html_research_report(payload, html_file)
            print(f"{Term.GREEN}✔ Interactive HTML Report saved to:{Term.RESET} {saved_html}")
            print(f"{Term.GREEN}✔ Latest Report link updated:{Term.RESET} {os.path.join(REPORTS_DIR, 'latest_research_report.html')}")

            if args.open:
                print(f"{Term.CYAN}Opening report in browser...{Term.RESET}")
                webbrowser.open(f"file://{os.path.abspath(saved_html)}")

        # Optional JSON Export
        if args.export_json is not None:
            if args.export_json.strip():
                json_file = args.export_json.strip()
            else:
                ts_suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
                json_file = os.path.join(REPORTS_DIR, f"research_strategy_{sym_tag}_{tf_tag}_{ts_suffix}.json")
            with open(json_file, "w", encoding="utf-8") as jf:
                json.dump(payload, jf, indent=2, default=str)
            print(f"{Term.GREEN}✔ Evaluation JSON exported to:{Term.RESET} {json_file}")

    except Exception as ex:
        print(f"\n{Term.RED}{Term.BOLD}[RESEARCH EVALUATION ERROR]{Term.RESET} {ex}\n", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
