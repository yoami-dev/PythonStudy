#!/usr/bin/env python3
"""
===============================================================================
 KRAKEN STANDALONE LIVE FYERS POLLER & ALERT SCANNER [PRO LIFECYCLE]
===============================================================================
 Location: D:\\Milind\\MyTradingPlatform\\script\\scan_kraken_fyers_live.py

 Directly polls the FYERS API v3 in real-time for live 5-minute candles.
 Tracks both:
   1. Real-time alerts on the latest candle.
   2. Full Intraday Trade Lifecycle of all trades triggered today:
      - ACTIVE WORKING TRADES (still open & running)
      - PROTECTED TRADES (T1 +1.2R reached, SL moved to Breakeven)
      - TARGET 2 ACHIEVED (Full +3.0R Runner Hit)
      - EXITED AT BREAKEVEN / STOP LOSS

 Usage:
   python script/scan_kraken_fyers_live.py --loop --interval 60
   python script/scan_kraken_fyers_live.py --rr 3.0 --t1 1.2
===============================================================================
"""

import os
import sys
import time
import sqlite3
import argparse
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any, Optional

# Ensure UTF-8 output and ANSI virtual terminal processing on Windows consoles
if sys.platform == "win32":
    try:
        os.system("")
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


class C:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    
    RED = "\033[1;31m"
    GREEN = "\033[1;32m"
    YELLOW = "\033[1;33m"
    BLUE = "\033[1;34m"
    MAGENTA = "\033[1;35m"
    CYAN = "\033[1;36m"
    WHITE = "\033[1;37m"
    GRAY = "\033[0;90m"

    # High-contrast background badges
    BG_GREEN = "\033[42;1;30m"
    BG_RED = "\033[41;1;37m"
    BG_CYAN = "\033[46;1;30m"
    BG_YELLOW = "\033[43;1;30m"
    BG_BLUE = "\033[44;1;37m"
    BG_MAGENTA = "\033[45;1;37m"


# Ensure project root is on sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from app.config import settings
from app.strategies.impl.kraken_strategy import KrakenStrategyEngine, IST_TZ


try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    HAS_WINSOUND = False

try:
    from fyers_apiv3 import fyersModel
    HAS_FYERS = True
except ImportError:
    HAS_FYERS = False

DB_PATH = os.path.join(PROJECT_ROOT, "smm_trading.db")

# Top Liquid Nifty 50 Instruments
NIFTY_SYMBOLS = [
    "SUNPHARMA", "SBIN", "MARUTI", "BRITANNIA", "WIPRO",
    "BAJAJ-AUTO", "BAJAJFINSV", "BAJFINANCE", "BHARTIARTL", "BPCL",
    "CIPLA", "COALINDIA", "DRREDDY", "EICHERMOT", "GRASIM",
    "HCLTECH", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO", "HINDALCO",
    "HINDUNILVR", "ICICIBANK", "INDUSINDBK", "INFY", "ITC",
    "JSWSTEEL", "KOTAKBANK", "LT", "M&M", "NESTLEIND",
    "NTPC", "ONGC", "POWERGRID", "RELIANCE", "SBILIFE",
    "SHRIRAMFIN", "TATACONSUM", "TATASTEEL", "TCS", "TECHM",
    "TITAN", "TRENT", "ULTRACEMCO"
]


def play_alert_chime():
    if HAS_WINSOUND:
        try:
            winsound.Beep(1200, 150)
            winsound.Beep(1600, 250)
        except Exception:
            pass


def get_token_from_db() -> Optional[str]:
    if not os.path.exists(DB_PATH):
        return None
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT access_token, status FROM fyers_tokens ORDER BY id DESC LIMIT 1")
        row = c.fetchone()
        conn.close()
        if row and row[0]:
            return row[0]
    except Exception:
        pass
    return None


def fetch_symbol_candles(fyers: Any, symbol: str, from_date: str, to_date: str) -> Optional[List[Dict[str, Any]]]:
    canonical_sym = f"NSE:{symbol}-EQ"
    data = {
        "symbol": canonical_sym,
        "resolution": "5",
        "date_format": "1",
        "range_from": from_date,
        "range_to": to_date,
        "cont_flag": "1"
    }

    try:
        res = fyers.history(data=data)
        if not isinstance(res, dict) or res.get("s") != "ok":
            return None
        raw_candles = res.get("candles", [])
        if not raw_candles:
            return None

        candles = []
        for c in raw_candles:
            dt = datetime.fromtimestamp(c[0], tz=timezone.utc)
            candles.append({
                "candle_timestamp": dt,
                "open": float(c[1]),
                "high": float(c[2]),
                "low": float(c[3]),
                "close": float(c[4]),
                "volume": float(c[5])
            })
        return candles
    except Exception:
        return None


def fetch_nifty_index_state(fyers: Any, from_date: str, to_date: str) -> Dict[str, Any]:
    """
    Fetches Nifty 50 Index 5m candles, computes Session VWAP, and determines Macro Market Regime & Directional Bias.
    """
    data = {
        "symbol": "NSE:NIFTY50-INDEX",
        "resolution": "5",
        "date_format": "1",
        "range_from": from_date,
        "range_to": to_date,
        "cont_flag": "1"
    }
    default_state = {
        "bias_map": {},
        "current_bias": "NEUTRAL",
        "current_price": 0.0,
        "current_vwap": 0.0,
        "diff": 0.0,
        "regime": "TRENDING",
        "day_range_pct": 1.0,
        "target_rr": 3.0
    }
    try:
        res = fyers.history(data=data)
        if not isinstance(res, dict) or res.get("s") != "ok":
            return default_state
        raw = res.get("candles", [])
        if not raw:
            return default_state

        now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
        today = now_ist.date()

        cum_pv = 0.0
        cum_vol = 0.0
        curr_date = None
        bias_map = {}
        highs, lows, opens = [], [], []

        for c in raw:
            dt = datetime.fromtimestamp(c[0], tz=timezone.utc).astimezone(IST_TZ)
            d = dt.date()
            if d != today:
                continue

            open_p = float(c[1])
            high_p = float(c[2])
            low_p = float(c[3])
            close_p = float(c[4])
            vol_p = float(c[5]) if float(c[5]) > 0 else 1.0

            if curr_date != d:
                curr_date = d
                cum_pv = 0.0
                cum_vol = 0.0

            tp = (high_p + low_p + close_p) / 3.0
            cum_pv += tp * vol_p
            cum_vol += vol_p
            vwap_val = cum_pv / cum_vol

            diff = close_p - vwap_val
            pct_diff = diff / vwap_val

            # Neutral zone within +-0.03% (+-7 pts) signals choppy consolidation
            if abs(pct_diff) <= 0.0003:
                c_bias = "NEUTRAL"
            elif diff > 0:
                c_bias = "BULLISH"
            else:
                c_bias = "BEARISH"



            t_key = dt.strftime("%Y-%m-%d %H:%M")
            bias_map[t_key] = {
                "bias": c_bias,
                "price": close_p,
                "vwap": vwap_val,
                "diff": diff
            }
            highs.append(high_p)
            lows.append(low_p)
            opens.append(open_p)

        if not highs or not opens:
            return default_state

        day_range_pct = ((max(highs) - min(lows)) / opens[0]) * 100.0
        regime = "RANGEBOUND" if day_range_pct < 0.85 else "TRENDING"
        latest_c = raw[-1]
        latest_dt = datetime.fromtimestamp(latest_c[0], tz=timezone.utc).astimezone(IST_TZ)
        latest_key = latest_dt.strftime("%Y-%m-%d %H:%M")
        latest_info = bias_map.get(latest_key, {
            "bias": "NEUTRAL",
            "price": float(latest_c[4]),
            "vwap": float(latest_c[4]),
            "diff": 0.0
        })

        # Market Mood Matrix based on Directional Bias and Volatility Regime
        curr_b = latest_info["bias"]
        if curr_b == "BEARISH":
            if regime == "TRENDING":
                mood_tag = "🔴 EXTREME BEARISH / RISK-OFF"
                mood_desc = "Broad Distribution & Institutional Selling"
                action_plan = "Aggressive Shorts Favored | Longs Strictly Forbidden"
            else:
                mood_tag = "🔴 CAUTIOUSLY BEARISH / SLOW BLEED"
                mood_desc = "Dull Rangebound Distribution & Choppy Down-Drift"
                action_plan = "Defensive Shorts Only | Quick Target Harvest (+2.0R)"
        elif curr_b == "BULLISH":
            if regime == "TRENDING":
                mood_tag = "🟢 AGGRESSIVELY BULLISH / RISK-ON"
                mood_desc = "Broad Institutional Accumulation & Trend Expansion"
                action_plan = "Aggressive Longs Favored | Hold Full Runners (+3.0R)"
            else:
                mood_tag = "🟢 MILDLY BULLISH / BUY-ON-DIPS"
                mood_desc = "Selective Sector Rotation & Rangebound Accumulation"
                action_plan = "Defensive Longs Only | Quick Target Harvest (+2.0R)"
        else:
            if regime == "RANGEBOUND":
                mood_tag = "🟡 CHOPPY / INDECISIVE (SIDEWAYS)"
                mood_desc = "Tight Volatility Squeeze & Sideways Chop"
                action_plan = "Extreme Caution | Scalp Only (RVOL >= 1.55x Required)"
            else:
                mood_tag = "🟡 EQUILIBRIUM CONSOLIDATION"
                mood_desc = "Balancing at VWAP / Momentum Breakout Imminent"
                action_plan = "Wait for Confirmed Range Breakout"

        return {
            "bias_map": bias_map,
            "current_bias": latest_info["bias"],
            "current_price": latest_info["price"],
            "current_vwap": latest_info["vwap"],
            "diff": latest_info["diff"],
            "regime": regime,
            "day_range_pct": day_range_pct,
            "target_rr": 2.0 if regime == "RANGEBOUND" else 3.0,
            "mood_tag": mood_tag,
            "mood_desc": mood_desc,
            "action_plan": action_plan,
        }
    except Exception:
        return default_state


def evaluate_today_lifecycle(engine: KrakenStrategyEngine, sym: str, candles: List[Dict[str, Any]], nifty_state: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Replays today's 5-minute session with historical Nifty 50 Index bias alignment.
    """
    if len(candles) < 30:
        return []

    now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
    today_date = now_ist.date()

    captured_trades = []
    active_trade = None

    bias_map = nifty_state.get("bias_map", {})
    fallback_bias = nifty_state.get("current_bias", "NEUTRAL")
    regime = nifty_state.get("regime", "TRENDING")

    for idx in range(30, len(candles)):
        c_curr = candles[idx]
        c_dt = c_curr["candle_timestamp"].astimezone(IST_TZ)

        # Only look for triggers that occurred today
        if c_dt.date() != today_date:
            continue

        # Look up broader Nifty 50 bias at this exact 5-minute bar
        t_key = c_dt.strftime("%Y-%m-%d %H:%M")
        bar_bias = bias_map.get(t_key, {}).get("bias", fallback_bias)

        # If no active trade on this symbol, check for fresh entry aligned with macro index
        if active_trade is None:
            res = engine.evaluate(
                symbol=sym,
                instrument="NSE_EQ",
                current_price=float(c_curr["close"]),
                candles=candles[:idx + 1],
                timeframe="5m",
                index_bias=bar_bias,
                market_regime=regime
            )

            if res.get("status") == "VALID":
                active_trade = {
                    "symbol": sym,
                    "direction": res["direction"],
                    "entry_price": float(res["entry_price"]),
                    "stop_loss_price": float(res["stop_loss_price"]),
                    "initial_sl": float(res["stop_loss_price"]),
                    "t1_target_price": float(res["t1_target_price"]),
                    "target_price": float(res["target_price"]),
                    "trigger_time": c_dt.strftime("%H:%M IST"),
                    "trigger_idx": idx,
                    "status": f"[{res['direction']} ACTIVE]",
                    "t1_hit": False,
                    "closed": False,
                    "explanation": res.get("explanation", ""),
                    "is_fresh": (idx == len(candles) - 1)
                }
        else:
            # Update ongoing trade with the current candle's price action
            high = float(c_curr["high"])
            low = float(c_curr["low"])

            if active_trade["direction"] == "LONG":
                # Check Target 1 & Breakeven Shield
                if not active_trade["t1_hit"] and high >= active_trade["t1_target_price"]:
                    active_trade["t1_hit"] = True
                    active_trade["stop_loss_price"] = active_trade["entry_price"]
                    active_trade["status"] = "[BUY T1 (BE)]"

                # Check Target 2 Runner
                if high >= active_trade["target_price"]:
                    active_trade["status"] = f"[TARGET 2 HIT (+{active_trade.get('target_rr', 3.0):.1f}R)]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None
                elif low <= active_trade["stop_loss_price"]:
                    active_trade["status"] = "[EXITED (AT BREAKEVEN)]" if active_trade["t1_hit"] else "[STOP LOSS HIT]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None

            elif active_trade["direction"] == "SHORT":
                # Check Target 1 & Breakeven Shield
                if not active_trade["t1_hit"] and low <= active_trade["t1_target_price"]:
                    active_trade["t1_hit"] = True
                    active_trade["stop_loss_price"] = active_trade["entry_price"]
                    active_trade["status"] = "[SELL T1 (BE)]"

                # Check Target 2 Runner
                if low <= active_trade["target_price"]:
                    active_trade["status"] = f"[TARGET 2 HIT (+{active_trade.get('target_rr', 3.0):.1f}R)]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None
                elif high >= active_trade["stop_loss_price"]:
                    active_trade["status"] = "[EXITED (AT BREAKEVEN)]" if active_trade["t1_hit"] else "[STOP LOSS HIT]"
                    active_trade["closed"] = True
                    captured_trades.append(active_trade)
                    active_trade = None

    if active_trade is not None:
        captured_trades.append(active_trade)

    return captured_trades


def scan_live_market(fyers: Any, engine: KrakenStrategyEngine, symbols: List[str]):
    now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
    from_date = (now_ist - timedelta(days=7)).strftime("%Y-%m-%d")
    to_date = now_ist.strftime("%Y-%m-%d")

    # 1. Fetch broader Nifty 50 Index state and Macro Bias first
    nifty_state = fetch_nifty_index_state(fyers, from_date, to_date)

    print(f"\n[{now_ist.strftime('%Y-%m-%d %H:%M:%S IST')}] Polling FYERS Live API for {len(symbols)} instruments...")

    all_captured_trades = []
    latest_prices = {}
    success_count = 0
    new_signals = []

    for sym in symbols:
        candles = fetch_symbol_candles(fyers, sym, from_date, to_date)
        if candles and len(candles) >= 30:
            success_count += 1
            curr_close = float(candles[-1]["close"])
            latest_prices[sym] = curr_close

            trades = evaluate_today_lifecycle(engine, sym, candles, nifty_state)
            for t in trades:
                t["curr_price"] = curr_close
                all_captured_trades.append(t)
                if t.get("is_fresh"):
                    new_signals.append(t)

        time.sleep(0.12)  # Respects FYERS API rate limits (8 req/sec)

    # 2. Prominent Nifty 50 Macro Regime & Filter Bar
    bias_tag = nifty_state.get("current_bias", "NEUTRAL")
    regime_tag = nifty_state.get("regime", "TRENDING")
    nifty_p = nifty_state.get("current_price", 0.0)
    nifty_vw = nifty_state.get("current_vwap", 0.0)
    diff_pts = nifty_state.get("diff", 0.0)
    day_rng = nifty_state.get("day_range_pct", 0.0)
    tgt2 = nifty_state.get("target_rr", 3.0)

    mood_tag = nifty_state.get("mood_tag", "UNKNOWN")
    mood_desc = nifty_state.get("mood_desc", "")
    action_plan = nifty_state.get("action_plan", "")

    if bias_tag == "BEARISH":
        bias_badge = f"{C.BG_RED} 🔴 BEARISH {C.RESET}"
    elif bias_tag == "BULLISH":
        bias_badge = f"{C.BG_GREEN} 🟢 BULLISH {C.RESET}"
    else:
        bias_badge = f"{C.BG_YELLOW} 🟡 NEUTRAL {C.RESET}"

    print("\n" + f"{C.BOLD}{C.BLUE}" + "=" * 125 + f"{C.RESET}")
    print(f" {C.BOLD}{C.WHITE}📊 NIFTY 50 REGIME{C.RESET}: {C.YELLOW}{regime_tag}{C.RESET} (Range: {day_rng:.2f}%) | {bias_badge} (Nifty: {C.BOLD}{C.WHITE}{nifty_p:.2f}{C.RESET} vs VWAP: {nifty_vw:.2f} [{diff_pts:+.2f} pts])")
    print(f" MARKET MOOD : {mood_tag} ({mood_desc})")
    print(f" ACTION PLAN : {C.BOLD}{action_plan}{C.RESET} | ADAPTIVE RUNNER TARGET 2: {C.GREEN}+{tgt2:.1f}R{C.RESET}")
    print(f"{C.BOLD}{C.BLUE}" + "=" * 125 + f"{C.RESET}")

    # Audio chime & alert on new signal
    if new_signals:
        play_alert_chime()
        is_short_alert = any(t["direction"] == "SHORT" for t in new_signals)
        header_bg = C.BG_RED if is_short_alert else C.BG_GREEN
        print("\n" + f"{header_bg} 🚨 FRESH KRAKEN TRADE TRIGGERED ON THE LATEST 5-MIN CANDLE ({len(new_signals)} SETUPS) 🚨 {C.RESET}")
        print("=" * 115)
        for t in new_signals:
            if t["direction"] == "LONG":
                dir_tag = f"🟢 {C.BOLD}{C.GREEN}[LONG]{C.RESET}"
            else:
                dir_tag = f"🔴 {C.BOLD}{C.RED}[SHORT]{C.RESET}"
            sym_str = f"{C.BOLD}{C.WHITE}{t['symbol']:<12}{C.RESET}"
            print(f" * {dir_tag} {sym_str} | Entry: {t['entry_price']:.2f} | "
                  f"SL: {C.RED}{t['stop_loss_price']:.2f}{C.RESET} | T1 (+1.2R): {C.CYAN}{t['t1_target_price']:.2f}{C.RESET} | "
                  f"T2 (+{tgt2:.1f}R): {C.GREEN}{t['target_price']:.2f}{C.RESET}")
            print(f"   Reason: {t.get('explanation')}")
        print("=" * 115 + "\n")

    # Split into Working Trades vs Completed Trades
    working_trades = [t for t in all_captured_trades if not t.get("closed", False)]
    completed_trades = [t for t in all_captured_trades if t.get("closed", False)]

    # 1. Display ACTIVE WORKING TRADES
    print("\n" + f"{C.BOLD}{C.CYAN}" + "=" * 125 + f"{C.RESET}")
    print(f" {C.BOLD}{C.CYAN}🔥 [ACTIVE WORKING TRADES] IN PROGRESS RIGHT NOW{C.RESET} (Polled: {success_count}/{len(symbols)} symbols)")
    print(f"{C.BOLD}{C.CYAN}" + "=" * 125 + f"{C.RESET}")
    if working_trades:
        print(f" {'SYMBOL':<12} {'DIR':<6} {'TRIGGER':<10} {'ENTRY':<10} {'CURRENT':<10} {'P&L (PTS)':<12} {'CURR R':<10} {'STOP LOSS':<14} {'T1 (+1.2R)':<12} {'T2 (RUNNER)':<12} {'STATUS':<20}")
        print("-" * 125)
        for t in working_trades:
            cur_p = t.get("curr_price", t["entry_price"])
            init_risk = abs(t["entry_price"] - t["initial_sl"])
            sym_col = f"{C.BOLD}{C.WHITE}{t['symbol']:<12}{C.RESET}"

            if t["direction"] == "LONG":
                pnl_pts = cur_p - t["entry_price"]
                cur_r = pnl_pts / init_risk if init_risk > 0 else 0.0
                dir_col = f"{C.BOLD}{C.GREEN}{'LONG':<6}{C.RESET}"
            else:
                pnl_pts = t["entry_price"] - cur_p
                cur_r = pnl_pts / init_risk if init_risk > 0 else 0.0
                dir_col = f"{C.BOLD}{C.RED}{'SHORT':<6}{C.RESET}"

            pnl_str = f"{pnl_pts:+.2f} pts"
            r_str = f"{cur_r:+.2f}R"
            if pnl_pts > 0.001:
                pnl_col = f"{C.BOLD}{C.GREEN}{pnl_str:<12}{C.RESET}"
                r_col = f"{C.BOLD}{C.GREEN}{r_str:<10}{C.RESET}"
            elif pnl_pts < -0.001:
                pnl_col = f"{C.BOLD}{C.RED}{pnl_str:<12}{C.RESET}"
                r_col = f"{C.BOLD}{C.RED}{r_str:<10}{C.RESET}"
            else:
                pnl_col = f"{pnl_str:<12}"
                r_col = f"{r_str:<10}"

            sl_display = f"{t['stop_loss_price']:.2f}" + (" (BE)" if t["t1_hit"] else "")
            sl_col = f"{C.RED}{sl_display:<14}{C.RESET}"
            t1_col = f"{C.CYAN}{t['t1_target_price']:<12.2f}{C.RESET}"
            t2_col = f"{C.GREEN}{t['target_price']:<12.2f}{C.RESET}"

            if "T1" in t["status"]:
                st_col = f"🛡️ {C.BOLD}{C.CYAN}{t['status']:<16}{C.RESET}"
            elif t["direction"] == "LONG":
                st_col = f"🟢 {C.BOLD}{C.GREEN}{t['status']:<16}{C.RESET}"
            else:
                st_col = f"🔴 {C.BOLD}{C.RED}{t['status']:<16}{C.RESET}"

            print(f" {sym_col} {dir_col} {t['trigger_time']:<10} {t['entry_price']:<10.2f} "
                  f"{C.BOLD}{cur_p:<10.2f}{C.RESET} {pnl_col} {r_col} {sl_col} {t1_col} "
                  f"{t2_col} {st_col}")
    else:
        print(f" {'No active open trades at this moment. Waiting for new setups to trigger...':^120}")

    # 2. Display COMPLETED TRADES TODAY
    print("\n" + f"{C.BOLD}{C.MAGENTA}" + "=" * 125 + f"{C.RESET}")
    print(f" {C.BOLD}{C.MAGENTA}🏁 [COMPLETED TRADES TODAY] PREVIOUS TRADES CAPTURED EARLIER THIS SESSION{C.RESET}")
    print(f"{C.BOLD}{C.MAGENTA}" + "=" * 125 + f"{C.RESET}")
    if completed_trades:
        print(f" {'SYMBOL':<12} {'DIR':<6} {'TRIGGER':<10} {'ENTRY':<10} {'CURRENT':<10} {'STOP LOSS':<14} {'T1 (+1.2R)':<12} {'T2 (RUNNER)':<12} {'OUTCOME':<26}")
        print("-" * 125)
        for t in completed_trades:
            cur_p = t.get("curr_price", t["entry_price"])
            sym_col = f"{C.BOLD}{C.WHITE}{t['symbol']:<12}{C.RESET}"

            if t["direction"] == "LONG":
                dir_col = f"{C.BOLD}{C.GREEN}{'LONG':<6}{C.RESET}"
            else:
                dir_col = f"{C.BOLD}{C.RED}{'SHORT':<6}{C.RESET}"

            sl_display = f"{t['stop_loss_price']:.2f}" + (" (BE)" if t["t1_hit"] else "")
            sl_col = f"{C.RED}{sl_display:<14}{C.RESET}"
            t1_col = f"{C.CYAN}{t['t1_target_price']:<12.2f}{C.RESET}"
            t2_col = f"{C.GREEN}{t['target_price']:<12.2f}{C.RESET}"

            st = t["status"]
            # Check STOP LOSS before the generic "HIT" check.
            # "[STOP LOSS HIT]" contains the word "HIT", so the previous
            # ordering incorrectly colored it green.
            if "STOP LOSS" in st or "STOPPED" in st or "SL" in st:
                outcome_col = f"❌ {C.BOLD}{C.RED}{st:<22}{C.RESET}"
            elif "BREAKEVEN" in st or "(BE)" in st:
                outcome_col = f"🛡️ {C.BOLD}{C.CYAN}{st:<22}{C.RESET}"
            elif "TARGET" in st or "HIT" in st:
                outcome_col = f"🎯 {C.BOLD}{C.GREEN}{st:<22}{C.RESET}"
            else:
                outcome_col = f"{st:<24}"

            print(f" {sym_col} {dir_col} {t['trigger_time']:<10} {t['entry_price']:<10.2f} "
                  f"{cur_p:<10.2f} {sl_col} {t1_col} {t2_col} {outcome_col}")
    else:
        print(f" {'No completed trades recorded yet today.':^120}")

    print(f"{C.BOLD}{C.MAGENTA}" + "=" * 125 + f"{C.RESET}\n")



def main():
    parser = argparse.ArgumentParser(description="KRAKEN Live FYERS Poller & Alert Engine")
    parser.add_argument("--token", type=str, default=None, help="FYERS API v3 access token")
    parser.add_argument("--rr", type=float, default=3.0, help="T2 Risk-to-Reward (default: 3.0)")
    parser.add_argument("--t1", type=float, default=1.2, help="T1 Lock-in R:R (default: 1.2)")
    parser.add_argument("--loop", action="store_true", help="Run continuously in a loop")
    parser.add_argument("--interval", type=int, default=60, help="Poll interval in seconds (default: 60)")
    args = parser.parse_args()

    if not HAS_FYERS:
        print("[ERROR] 'fyers_apiv3' package is required. Run: pip install fyers-apiv3")
        sys.exit(1)

    token = args.token or os.environ.get("FYERS_ACCESS_TOKEN") or get_token_from_db()
    client_id = settings.FYERS_CLIENT_ID

    while True:
        if token:
            fyers = fyersModel.FyersModel(
                token=token,
                is_async=False,
                client_id=client_id,
                log_path=os.path.join(PROJECT_ROOT, "temp")
            )
            try:
                profile = fyers.get_profile()
                if isinstance(profile, dict) and profile.get("s") == "ok":
                    user_name = profile.get("data", {}).get("name", "Trader")
                    print(f"\n[AUTH OK] Connected to FYERS account: {user_name}")
                    break
                else:
                    err_msg = profile.get("message", "Invalid or expired access token")
                    print(f"\n[AUTH EXPIRED] FYERS Token Status: {err_msg}")
            except Exception as e:
                print(f"[AUTH ERROR] Token verification failed: {e}")

        print("\n" + "=" * 80)
        print(" [ACTION REQUIRED] FYERS Authentication Needed")
        print("=" * 80)
        print(" Choose an authentication option:")
        print("   [1] Automatic Browser Login (Opens FYERS login page & handles callback)")
        print("   [2] Paste Token Manually")
        print("   [3] Exit")
        print("=" * 80)

        choice = input("Select option [1/2/3] (Default 1): ").strip()
        if choice in ("", "1"):
            from script.fyers_login_helper import run_oauth_flow
            token = run_oauth_flow()
            if not token:
                print("[ERROR] Browser login did not complete.")
                sys.exit(1)
        elif choice == "2":
            token = input("Please paste your fresh FYERS Access Token: ").strip()
            if not token:
                print("[INFO] Exiting.")
                sys.exit(0)
        else:
            print("[INFO] Exiting.")
            sys.exit(0)

    engine = KrakenStrategyEngine(target_rr=args.rr, t1_rr=args.t1)

    print("===============================================================================")
    print(" KRAKEN STANDALONE LIVE FYERS POLLER DAEMON")
    print(f" Timeframe: 5m | Target 1: +{args.t1:.1f}R | Target 2: +{args.rr:.1f}R | Interval: {args.interval}s")
    print(f" Universe: {len(NIFTY_SYMBOLS)} Liquid Nifty 50 Instruments")
    print("===============================================================================")

    if args.loop:
        print(f"[INFO] Running live polling loop every {args.interval}s. Press Ctrl+C to exit.")
        try:
            while True:
                scan_live_market(fyers, engine, NIFTY_SYMBOLS)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n[INFO] Poller stopped by user.")
    else:
        scan_live_market(fyers, engine, NIFTY_SYMBOLS)


if __name__ == "__main__":
    main()